#!/usr/bin/env bash
set -euo pipefail
APP_NAME="${1:-globalsupplements-broker}"
fly apps create "$APP_NAME" || true
fly volumes create data --region gru --size 1 || true
echo "Set secrets: fly secrets set SENDGRID_API_KEY=... PUBLIC_BASE_URL=https://$APP_NAME.fly.dev SECRET_KEY=$(openssl rand -hex 32)"
echo "Deploy: fly deploy"
