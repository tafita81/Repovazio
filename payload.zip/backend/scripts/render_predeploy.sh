#!/usr/bin/env bash
set -euo pipefail
echo ">> One-shot bootstrap (branding + i18n + coleta + auditoria + 1º ciclo)"
python /app/scripts/one_shot_bootstrap.py || true
echo ">> One-shot concluído"
