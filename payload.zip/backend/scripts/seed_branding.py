#!/usr/bin/env python3
import os
from app.db import SessionLocal
from app.models import GlobalCredential
from app.services.branding import set_brand

def upsert_cred(db, service, key, value):
    row = db.query(GlobalCredential).filter(GlobalCredential.service==service, GlobalCredential.key_name==key).first()
    if row: row.value = value
    else:
        db.add(GlobalCredential(service=service, key_name=key, value=value))

def main():
    db = SessionLocal()
    # Branding a partir de variáveis de ambiente
    brand = {
        "BRAND_NAME": os.getenv("BRAND_NAME","Global Supplements"),
        "BRAND_DOMAIN": os.getenv("BRAND_DOMAIN","globalsupplements.site"),
        "BRAND_FROM_EMAIL": os.getenv("BRAND_FROM_EMAIL","contact@globalsupplements.site"),
        "BRAND_FROM_NAME": os.getenv("BRAND_FROM_NAME","Global Supplements — RFQ Desk"),
        "BRAND_LOGO_URL": os.getenv("BRAND_LOGO_URL",""),
        "DEFAULT_LANG": os.getenv("DEFAULT_LANG","en"),
        "SUPPORTED_LANGS": os.getenv("SUPPORTED_LANGS","en,pt,es,fr,de,it,ja,ko,zh_cn,zh_tw,ar,ru,hi,tr")
    }
    set_brand(db, brand)

    # SendGrid sender (para o serviço de e-mail)
    sg = os.getenv("SENDGRID_API_KEY","")
    if sg:
        upsert_cred(db, "sendgrid", "api_key", sg)

    # Idiomas suportados (duplicado em branding e como preferência app-level)
    upsert_cred(db, "i18n", "default_lang", brand["DEFAULT_LANG"])
    upsert_cred(db, "i18n", "supported_langs", brand["SUPPORTED_LANGS"])

    db.commit()
    db.close()
    print("Seed concluído. Branding + SendGrid + i18n configurados.")

if __name__ == "__main__":
    main()
