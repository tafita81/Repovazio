#!/usr/bin/env python3
import os, time, json
from app.db import SessionLocal
from app.models import GlobalCredential
from app.services.branding import set_brand, get_brand

def try_imports():
    mods = {}
    try:
        from app.services.buyers_harvester import harvest_enabled_sources
        mods["harvest_enabled_sources"] = harvest_enabled_sources
    except Exception: pass
    try:
        from app.services.scraper_engine import harvest_active_week
        mods["harvest_active_week"] = harvest_active_week
    except Exception: pass
    try:
        from app.services.strategy_auditor import audit
        mods["audit"] = audit
    except Exception: pass
    try:
        from app.services.autopilot import Autopilot
        mods["Autopilot"] = Autopilot
    except Exception: pass
    return mods

def upsert(db, service, key, value):
    row = db.query(GlobalCredential).filter(GlobalCredential.service==service, GlobalCredential.key_name==key).first()
    if row: row.value = str(value)
    else: db.add(GlobalCredential(service=service, key_name=key, value=str(value)))

def main():
    db = SessionLocal()

    brand = {
        "BRAND_NAME": os.getenv("BRAND_NAME","Global Supplements"),
        "BRAND_DOMAIN": os.getenv("BRAND_DOMAIN","globalsupplements.site"),
        "BRAND_FROM_EMAIL": os.getenv("BRAND_FROM_EMAIL","contact@globalsupplements.site"),
        "BRAND_FROM_NAME": os.getenv("BRAND_FROM_NAME","Global Supplements — RFQ Desk"),
        "BRAND_LOGO_URL": os.getenv("BRAND_LOGO_URL",""),
        "DEFAULT_LANG": os.getenv("DEFAULT_LANG","en"),
        "SUPPORTED_LANGS": os.getenv("SUPPORTED_LANGS","en,pt,es,fr,de,it,ja,ko,zh_cn,zh_tw,ar,ru,hi,tr"),
    }
    set_brand(db, brand)
    upsert(db, "i18n", "default_lang", brand["DEFAULT_LANG"])
    upsert(db, "i18n", "supported_langs", brand["SUPPORTED_LANGS"])

    sg = os.getenv("SENDGRID_API_KEY","")
    if sg: upsert(db, "sendgrid", "api_key", sg)

    upsert(db, "buyer_prefs", "countries", "US,AE,BR,JP,KR,SG,MY,MX,CL,AR,DE,FR,ES,IT,GB,NL,CA,AU")
    upsert(db, "buyer_prefs", "categories", "EV,BESS,HVAC,Robótica,Lasers,Óptica,Perfumaria,Suplementos,Eletrônicos")
    upsert(db, "buyer_prefs", "min_ticket_usd", "0")
    upsert(db, "collector", "prefer_apis", "true")
    upsert(db, "collector", "allow_scraping", "true")
    upsert(db, "collector", "screenshot_on_scrape", "false")
    upsert(db, "autopilot", "enabled", "true")
    db.commit()

    mods = try_imports()
    inserted = 0
    if "harvest_enabled_sources" in mods:
        try: inserted += int(mods["harvest_enabled_sources"](db, limit_per_source=50))
        except Exception: pass
    if "harvest_active_week" in mods:
        try: inserted += int(mods["harvest_active_week"](db, limit_per_bp=50))
        except Exception: pass

    audit_res = {}
    if "audit" in mods:
        try: audit_res = mods["audit"](db)
        except Exception: pass

    started = False
    if "Autopilot" in mods:
        try:
            ap = mods["Autopilot"]()
            ap.cycle()
            started = True
        except Exception:
            started = False

    print(json.dumps({
        "branding": get_brand(db),
        "rfqs_inserted": inserted,
        "audit": audit_res or "no_audit_module",
        "autopilot_cycle_ran": started
    }, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
