import os, requests
from typing import List, Dict

SEARCHAPI = "https://www.searchapi.io/api/v1/search"

PROGRAM_KEYWORDS = [
    "partner program", "partners", "distributors", "resellers", "where to buy",
    "drop ship", "dropship", "blind shipping", "fulfillment", "direct to customer"
]

DOMAINS = [
    "thomasnet.com","globalspec.com","mfg.com","coherent.com","mks.com","newport.com",
    "ipgphotonics.com","edmundoptics.com","optosigma.com","oceaninsight.com",
    "aerotech.com","montana-instruments.com","cryomech.com","techmfg.com","kineticsystems.com",
    "rohde-schwarz.com","anritsu.com","flir.com","arrow.com","avnet.com","futureelectronics.com","digikey.com","mouser.com"
]

def harvest_global_strict(target: int = 99, exclude_country: str | None = "IN", evidence_min: float = 0.6,
                          domains_override: List[str] | None = None, keywords: List[str] | None = None, api_key_override: str | None = None) -> List[Dict]:
    key = api_key_override or os.getenv("SEARCHAPI_IO_KEY")
    if not key:
        return []
    doms = domains_override if domains_override else DOMAINS
    kws = keywords if keywords else PROGRAM_KEYWORDS
    results = []
    for d in doms:
        for kw in kws[:5]:
            q = f"site:{d} {kw}"
            r = requests.get(SEARCHAPI, params={"engine":"google","q":q,"api_key":key}, timeout=30)
            data = r.json()
            for item in (data.get("organic_results") or [])[:3]:
                url = item.get("link")
                title = item.get("title","")
                snippet = item.get("snippet","")
                program_type = "partner" if "partner" in (title+snippet).lower() else "distributor"
                ev = 0.8 if any(k in (title+snippet).lower() for k in ["partner","distributor","where to buy","dropship","fulfillment"]) else 0.5
                if ev < evidence_min: 
                    continue
                results.append({
                    "name": title[:120],
                    "country_region": "Global",
                    "category": "Auto-harvest",
                    "program_type": program_type,
                    "website": url,
                    "program_url": url,
                    "evidence": url,
                    "indiamart_experience": "sem_evidencia_publica",
                    "notes": f"harvested from {d} using '{kw}'",
                    "evidence_score": ev
                })
        if len(results) >= target:
            break
    return results[:target]
