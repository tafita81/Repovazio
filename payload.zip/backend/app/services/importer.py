import io, pandas as pd
from sqlalchemy.orm import Session
from ..models import Supplier, RFQ
from .utils import compute_evidence_score

def import_suppliers_csv(db: Session, content: bytes, evidence_min: float = 0.6) -> dict:
    df = pd.read_csv(io.BytesIO(content))
    added, skipped = 0, 0
    for _, r in df.iterrows():
        name = str(r.get("name") or r.get("Fornecedor") or "").strip()
        if not name: 
            skipped += 1
            continue
        program_type = str(r.get("program_type") or r.get("Tipo de Programa") or "").strip()
        website = str(r.get("website") or "").strip() or None
        program_url = str(r.get("program_url") or "").strip() or None
        evidence = str(r.get("evidence") or "").strip() or None

        evidence_score = r.get("evidence_score")
        if pd.isna(evidence_score) or evidence_score is None:
            evidence_score = compute_evidence_score(website, program_url, evidence, program_type)

        if evidence_score < evidence_min:
            skipped += 1
            continue

        sup = Supplier(
            name=name,
            country_region=str(r.get("country_region") or r.get("País/Região") or "").strip(),
            category=str(r.get("category") or r.get("Segmento") or "").strip(),
            program_type=program_type,
            website=website,
            program_url=program_url,
            evidence=evidence,
            indiamart_experience=str(r.get("indiamart_experience") or r.get("IndiaMART") or "sem_evidencia_publica").strip(),
            notes=str(r.get("notes") or "").strip(),
            evidence_score=float(evidence_score or 0.0)
        )
        exists = db.query(Supplier).filter(Supplier.name==sup.name, Supplier.website==sup.website).first()
        if exists:
            exists.program_type = sup.program_type or exists.program_type
            exists.program_url = sup.program_url or exists.program_url
            exists.evidence = sup.evidence or exists.evidence
            exists.evidence_score = max(exists.evidence_score or 0.0, sup.evidence_score or 0.0)
        else:
            db.add(sup)
            added += 1
    db.commit()
    return {"added": added, "skipped": skipped}

def import_rfqs_csv(db: Session, content: bytes) -> dict:
    df = pd.read_csv(io.BytesIO(content))
    added, skipped = 0, 0
    for _, r in df.iterrows():
        rfq_id = str(r.get("rfq_id") or "").strip()
        if not rfq_id:
            skipped += 1
            continue
        from ..models import RFQ
        exists = db.query(RFQ).filter(RFQ.rfq_id==rfq_id).first()
        if exists:
            skipped += 1
            continue
        item = RFQ(
            rfq_id=rfq_id,
            title=str(r.get("title") or ""),
            category=str(r.get("category") or ""),
            hs_code=str(r.get("hs_code") or ""),
            quantity=str(r.get("quantity") or ""),
            uom=str(r.get("uom") or ""),
            target_price=float(r.get("target_price") or 0.0) if str(r.get("target_price") or "").strip()!="" else None,
            currency=str(r.get("currency") or ""),
            incoterm=str(r.get("incoterm") or ""),
            destination_country=str(r.get("destination_country") or ""),
            buyer_company=str(r.get("buyer_company") or ""),
            buyer_country=str(r.get("buyer_country") or ""),
            deadline_date=str(r.get("deadline_date") or ""),
            urgency=str(r.get("urgency") or ""),
            compliance_requirements=str(r.get("compliance_requirements") or ""),
            shipping_terms=str(r.get("shipping_terms") or ""),
            lead_time_required_days=str(r.get("lead_time_required_days") or ""),
            notes=str(r.get("notes") or ""),
        )
        db.add(item)
        added += 1
    db.commit()
    return {"added": added, "skipped": skipped}
