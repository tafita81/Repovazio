
import re

COUNTRY_LANG = {
    "BR": "pt","PT":"pt",
    "ES":"es","MX":"es","AR":"es","CL":"es","CO":"es","PE":"es","UY":"es","PY":"es","BO":"es","EC":"es","VE":"es","CR":"es","PA":"es","GT":"es","SV":"es","HN":"es","NI":"es","DO":"es","PR":"es",
    "US":"en","CA":"en","GB":"en","UK":"en","AU":"en","IE":"en","NZ":"en","ZA":"en","SG":"en","AE":"en","SA":"en","QA":"en","KW":"en",
    "FR":"fr","DE":"de","IT":"it","NL":"nl","SE":"sv","FI":"fi"
}

TLD_LANG = {
    "br":"pt","pt":"pt",
    "es":"es","mx":"es","ar":"es","cl":"es","co":"es","pe":"es","uy":"es","py":"es","bo":"es","ec":"es","ve":"es","cr":"es","pa":"es","gt":"es","sv":"es","hn":"es","ni":"es","do":"es","pr":"es",
    "uk":"en","us":"en","ca":"en","au":"en","sg":"en","ae":"en","sa":"en","qa":"en","kw":"en"
}

def detect_from_email(email: str | None) -> str | None:
    if not email or "@" not in email: 
        return None
    domain = email.split("@")[-1].lower()
    # pega tld
    tld = domain.split(".")[-1]
    return TLD_LANG.get(tld)

def detect_from_country(country: str | None) -> str | None:
    if not country: return None
    c = country.strip().upper()
    return COUNTRY_LANG.get(c)

def pick_lang(buyer_email: str | None, buyer_country: str | None) -> str:
    lang = detect_from_country(buyer_country)
    if not lang:
        lang = detect_from_email(buyer_email)
    return lang or "en"
