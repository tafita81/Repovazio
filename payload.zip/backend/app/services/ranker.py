from sqlalchemy.orm import Session
from ..models import RFQ, Assignment

def rfq_score(r: RFQ) -> float:
    try:
        urgency = float(r.urgency or 0.0)
    except Exception:
        urgency = 0.0
    # ticket estimate
    try:
        qty = float(r.quantity or 0)
        tgt = float(r.target_price or 0.0)
        ticket = qty*tgt
    except Exception:
        ticket = 0.0
    if ticket <= 0:
        ticket = 5000.0
    t_norm = min(1.0, ticket / 100000.0)
    u_norm = min(1.0, urgency / 5.0)
    return 0.5*t_norm + 0.2*u_norm + 0.3*0.6

def rank_by_value(db: Session):
    data = []
    for r in db.query(RFQ).all():
        data.append({"rfq_id": r.rfq_id, "title": r.title, "score": rfq_score(r)})
    data.sort(key=lambda x: x["score"], reverse=True)
    return data

def rank_by_revenue(db: Session):
    agg = {}
    for a in db.query(Assignment).all():
        agg.setdefault(a.rfq_id, 0.0)
        agg[a.rfq_id] += float(a.broker_revenue_est_usd or 0.0)
    out = [{"rfq_id": k, "broker_revenue_est_total": v} for k,v in agg.items()]
    out.sort(key=lambda x: x["broker_revenue_est_total"], reverse=True)
    return out
