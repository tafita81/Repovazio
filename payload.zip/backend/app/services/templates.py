
import os
from jinja2 import Template

BASE = os.path.join(os.path.dirname(__file__), "..", "templates")

def load(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def resolve(type_key: str, lang: str):
    lang = (lang or "en").lower()
    # paths custom > default
    candidates = [
        os.path.join(BASE, "custom", f"{type_key}_{lang}.txt"),
        os.path.join(BASE, f"{type_key}_{lang}.txt"),
    ]
    # fallback to EN
    candidates += [
        os.path.join(BASE, "custom", f"{type_key}_en.txt"),
        os.path.join(BASE, f"{type_key}_en.txt"),
    ]
    for p in candidates:
        if os.path.exists(p):
            return load(p)
    raise FileNotFoundError(f"Template {type_key} not found for {lang} or EN fallback.")

def render(tmpl_str: str, ctx: dict) -> str:
    return Template(tmpl_str).render(**(ctx or {}))


def resolve_with_fallback(type_key: str, lang: str, fallbacks=None):
    # tenta lang, depois fallback(s), sempre incluindo 'en' por último
    chain = [ (lang or 'en').lower() ]
    if fallbacks:
        chain += [l.lower() for l in fallbacks if l]
    if 'en' not in chain:
        chain.append('en')
    for L in chain:
        try:
            return resolve(type_key, L)
        except Exception:
            continue
    # como último recurso, tenta EN direto
    return resolve(type_key, 'en')
