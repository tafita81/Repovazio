
import os, json, time, traceback
from apscheduler.schedulers.background import BackgroundScheduler
from sqlalchemy.orm import Session
from ..db import SessionLocal
from ..models import OutboundLog
from .matcher import match_and_assign
from .ranker import rank_by_revenue
from .pdf import render_quote_pdf
from .mailer import send_via_provider
from .lang import pick_lang
from .templates import resolve_with_fallback, render as render_tpl
from .monitoring import get_cred as mon_get, ping as mon_ping, alert_email as mon_alert
from .scraper_engine import harvest_active_week
from .buyers_harvester import harvest_enabled_sources
from .strategy import apply_zero_capex_strategy

CFG_PATH = os.path.join(os.path.dirname(__file__), "..", "autopilot_config.json")

class AutoPilot:
    def __init__(self):
        self.scheduler = BackgroundScheduler()
        self.log = []

    def load_cfg(self):
        with open(CFG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)

    def append_log(self, txt):
        self.log.append({"t": time.time(), "msg": txt})

    def _buyer_email_from_notes(self, notes: str | None):
        if not notes:
            return None
        # pega primeiro token com '@'
        for tok in notes.replace(",", " ").split():
            if "@" in tok and "." in tok:
                return tok.strip("<>;, ")
        return None

    def _email_context(self, db: Session, rfq_id: str):
        from ..models import RFQ, Assignment
        r = db.query(RFQ).filter(RFQ.rfq_id==rfq_id).first()
        if not r:
            return None, None, None
        assigns = db.query(Assignment).filter(Assignment.rfq_id==rfq_id).all()
        assigns.sort(key=lambda a: float(a.broker_revenue_est_usd or 0.0), reverse=True)
        total_rev = sum(float(a.broker_revenue_est_usd or 0.0) for a in assigns[:5])
        top = assigns[0] if assigns else None
        ctx = {
            "rfq_id": r.rfq_id,
            "buyer_name": r.buyer_company or "Customer",
            "from_email": self.cfg.get("email",{}).get("from_email") or "noreply@example.com",
            "from_name": self.cfg.get("email",{}).get("from_name") or "Broker AutoPilot",
            "incoterm": (r.incoterm or "DAP"),
            "lead_time_days": (r.lead_time_required_days or ""),
            "estimated_value_usd": (float((top.ticket_val_usd if top else 0.0))),
            "estimated_broker_revenue_usd": float(total_rev),
        }
        buyer_email = self._buyer_email_from_notes(r.notes) or None
        lang = pick_lang(buyer_email, r.buyer_country)
        return r, ctx, lang

    def cycle(self):
        db: Session = SessionLocal()
        try:
            self.cfg = self.load_cfg()
            if not self.cfg.get("enabled", False):
                self.append_log("AutoPilot desabilitado.")
                return
            # 0) Harvest de compradores habilitados
            # collector policy
            try:
                from ..models import GlobalCredential
                def _get(k, d):
                    r = db.query(GlobalCredential).filter(GlobalCredential.service=="collector", GlobalCredential.key_name==k).first()
                    return (r.value if r else d)
                prefer_apis = (_get("prefer_apis","true") == "true")
                allow_scraping = (_get("allow_scraping","true") == "true")
            except Exception:
                prefer_apis = True; allow_scraping = True
            
            self.append_log('Coletando RFQs de fontes habilitadas...')
            try:
                newn = harvest_enabled_sources(db)
                self.append_log(f'RFQs coletados: {newn}')
            except Exception as e:
                self.append_log('Harvest falhou: '+str(e))
            # 1) Matching
            match_and_assign(db, policy=None, max_suppliers=self.cfg.get("max_suppliers_per_rfq",5))
            # 1.5) Estratégia zero-CAPEX
            try:
                from ..models import Assignment
                for (rid,) in db.query(Assignment.rfq_id).distinct().all():
                    apply_zero_capex_strategy(db, rid)
            except Exception as e:
                self.append_log('Falha strategy: '+str(e))
            # 2) Ranking e Top-N
            ranked = rank_by_revenue(db)[:self.cfg.get("max_rfqs_per_cycle",100)]
            sent = 0
            for item in ranked:
                rfq_id = item["rfq_id"]
                r, ctx, lang = self._email_context(db, rfq_id)
                if not r:
                    continue
                # precisa de email do comprador nas notas ou cadastro
                buyer_email = self._buyer_email_from_notes(r.notes) or None
                if not buyer_email:
                    continue
                # 3) PDF buyer-safe
                brand = self.cfg.get("pdf_brand",{}).get("brand_name","")
                out = f"/tmp/quote_bsafe_{rfq_id}.pdf"
                render_quote_pdf(db, rfq_id, out, top_k=3, buyer_safe=True, brand=brand)
                # 4) Templates multilíngues com fallback (lang -> en)
                subj_tmpl = resolve_with_fallback("email_quote_subject", lang, fallbacks=None)
                body_tmpl = resolve_with_fallback("email_quote", lang, fallbacks=None)
                subject = render_tpl(subj_tmpl, ctx)
                body    = render_tpl(body_tmpl, ctx)
                # 5) Envio
                em = self.cfg["email"]
                ctx["message_id"] = f"rfq-{rfq_id}-{int(time.time())}"
                try:
                    send_via_provider(em.get("provider","sendgrid_api"), em, buyer_email,
                                      subject, body, ctx,
                                      attachments=[{"path": out, "filename": f"Proposal_{rfq_id}.pdf"}])
                    # log outbound
                    row = OutboundLog(rfq_id=rfq_id, buyer_email=buyer_email, subject=subject, lang=lang,
                                      sent_at=str(int(time.time())), message_id=ctx["message_id"]) 
                    db.add(row); db.commit()
                    sent += 1
                    self.append_log(f"[{lang}] Enviado RFQ {rfq_id} para {buyer_email}.")
                except Exception as e:
                    self.append_log(f"Falha email RFQ {rfq_id}: {e}")
            self.append_log(f"Ciclo concluído. Emails enviados: {sent}")
            # 6) Reenvio automático 48h
            self.resend_after_48h(db)
            # Monitoring ping (success)
            try:
                url = mon_get(db, "hc_ping_url") or mon_get(db, "kuma_push_url")
                if url: mon_ping(url)
            except Exception:
                pass
        except Exception as e:
            self.append_log("Erro no ciclo: " + str(e) + "\n" + traceback.format_exc())
            try:
                urlf = mon_get(db, "hc_fail_url")
                if urlf: mon_ping(urlf)
                mon_alert(db, "AutoPilot Error", f"Falha no ciclo: {str(e)}")
            except Exception:
                pass
        finally:
            db.close()

    def start(self):
        interval = int(self.load_cfg().get("interval_minutes", 15))
        self.scheduler.add_job(self.cycle, "interval", minutes=interval, id="autopilot_cycle", replace_existing=True)
        self.scheduler.start()
        self.append_log(f"AutoPilot iniciado (intervalo {interval} min).")

AP = AutoPilot()


    def resend_after_48h(self, db: Session):
        # reenvia propostas sem 'open' ou 'click' após 48h do envio
        now = int(time.time())
        cutoff = now - 48*3600
        rows = db.query(OutboundLog).all()
        resent = 0
        for r in rows:
            try:
                sent_ts = int(r.sent_at or "0")
            except Exception:
                sent_ts = 0
            if sent_ts and sent_ts < cutoff and not (r.opened_at or r.clicked_at):
                # gerar novo message_id e subject "Reminder"
                new_mid = f"{r.message_id}-reminder-{now}"
                # carregar contexto mínimo
                ctx = {"rfq_id": r.rfq_id, "buyer_name": "Customer", "from_email": self.cfg.get("email",{}).get("from_email","noreply@example.com"),
                       "from_name": self.cfg.get(\"email\",{}).get(\"from_name\",\"Broker AutoPilot\"), "message_id": new_mid}
                # templates de lembrete
                subj_tmpl = resolve_with_fallback("email_quote_subject_reminder", r.lang, fallbacks=None)
                body_tmpl = resolve_with_fallback("email_quote_reminder", r.lang, fallbacks=None)
                subject = render_tpl(subj_tmpl, ctx)
                body    = render_tpl(body_tmpl, ctx)
                # anexar o último PDF se existir (opcional: re-gerar)
                pdf_path = f"/tmp/quote_bsafe_{r.rfq_id}.pdf"
                try:
                    send_via_provider(self.cfg.get("email",{}).get("provider","sendgrid_api"), self.cfg.get("email",{}), r.buyer_email,
                                      subject, body, ctx, attachments=[{"path": pdf_path, "filename": f"Proposal_{r.rfq_id}.pdf"}])
                    r.sent_at = str(now); r.message_id = new_mid
                    db.commit(); resent += 1
                    self.append_log(f"Reminder enviado para RFQ {r.rfq_id} → {r.buyer_email}.")
                except Exception as e:
                    self.append_log(f"Falha no reminder RFQ {r.rfq_id}: {e}")
        if resent:
            self.append_log(f"Total reminders enviados: {resent}")
