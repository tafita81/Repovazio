from typing import Dict
from sqlalchemy.orm import Session
from ..models import GlobalCredential

KEYS = ["BRAND_NAME","BRAND_DOMAIN","BRAND_FROM_EMAIL","BRAND_FROM_NAME","BRAND_LOGO_URL","DEFAULT_LANG","SUPPORTED_LANGS"]

def get_brand(db: Session) -> Dict:
    out = {}
    for k in KEYS:
        r = db.query(GlobalCredential).filter(GlobalCredential.service=="branding", GlobalCredential.key_name==k).first()
        out[k] = r.value if r else None
    return out

def set_brand(db: Session, payload: Dict):
    for k,v in (payload or {}).items():
        if k not in KEYS: 
            continue
        row = db.query(GlobalCredential).filter(GlobalCredential.service=="branding", GlobalCredential.key_name==k).first()
        if row: row.value = str(v)
        else: db.add(GlobalCredential(service="branding", key_name=k, value=str(v)))
    db.commit()
    return True
