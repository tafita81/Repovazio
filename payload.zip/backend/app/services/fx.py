import os, json, time, requests
from typing import Dict

CACHE = os.path.join(os.path.dirname(__file__), "..", "data", "fx_cache.json")
os.makedirs(os.path.dirname(CACHE), exist_ok=True)

DEFAULTS = {"USD": 1.0, "EUR": 0.92, "BRL": 5.1, "CNY": 7.1, "JPY": 150.0, "AED": 3.67, "GBP": 0.78}

def _load_cache() -> Dict:
    if os.path.exists(CACHE):
        try:
            with open(CACHE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"ts": 0, "rates": DEFAULTS}

def _save_cache(obj: Dict):
    try:
        with open(CACHE, "w", encoding="utf-8") as f:
            json.dump(obj, f)
    except Exception:
        pass

def refresh() -> Dict:
    try:
        r = requests.get("https://api.exchangerate.host/latest?base=USD", timeout=10)
        js = r.json(); rates = js.get("rates") or {}
        rates["USD"] = 1.0
        out = {"ts": int(time.time()), "rates": rates}
        _save_cache(out)
        return out
    except Exception:
        return _load_cache()

def get_rates() -> Dict:
    cache = _load_cache()
    if int(time.time()) - int(cache.get("ts", 0)) > 86400:
        try:
            return refresh()
        except Exception:
            return cache
    return cache

def to_usd(amount: float, currency: str) -> float:
    if amount is None: return 0.0
    cur = (currency or "USD").upper()
    rates = get_rates().get("rates", {})
    r = rates.get(cur) or 1.0
    try:
        return float(amount) * (1.0/float(r))
    except Exception:
        return float(amount)
