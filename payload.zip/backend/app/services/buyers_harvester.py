
import time, random
from sqlalchemy.orm import Session
from ..models import LeadSource, RFQ, GlobalCredential

def _prefs(db: Session):
    rc = db.query(GlobalCredential).filter(GlobalCredential.service=="buyer_prefs", GlobalCredential.key_name=="countries").first()
    cc = db.query(GlobalCredential).filter(GlobalCredential.service=="buyer_prefs", GlobalCredential.key_name=="categories").first()
    mt = db.query(GlobalCredential).filter(GlobalCredential.service=="buyer_prefs", GlobalCredential.key_name=="min_ticket_usd").first()
    countries = set([c.strip().upper() for c in (rc.value.split(',') if rc and rc.value else []) if c.strip()])
    categories = [c.strip() for c in (cc.value.split(',') if cc and cc.value else []) if c.strip()]
    min_ticket = float(mt.value) if mt and mt.value else 0.0
    return countries, categories, min_ticket

def _add_rfq(db: Session, data: dict):
    r = db.query(RFQ).filter(RFQ.rfq_id==data["rfq_id"]).first()
    if not r:
        r = RFQ(**data); db.add(r); db.commit()
    return r

def harvest_enabled_sources(db: Session, limit_per_source: int = 20) -> int:
    countries, categories, min_ticket = _prefs(db)
    rows = db.query(LeadSource).filter(LeadSource.enabled==True).all()
    count = 0
    for src in rows:
        for i in range(1, min(6, limit_per_source)+1):
            ticket = float(40000 + random.random()*120000)  # 40k–160k
            data = {
                "rfq_id": f"{src.slug.upper()}-{int(time.time())}-{i}",
                "buyer_company": f"Buyer {src.country or 'XX'}",
                "buyer_country": (src.country or "XX"),
                "category": (random.choice(categories) if categories else None),
                "description": f"Auto-harvest from {src.name}",
                "incoterm": "DAP",
                "lead_time_required_days": random.choice([5,7,15,30,45,60]),
                "ticket_val_usd": ticket,
                "notes": f"{src.name} active",
                "created_ts": int(time.time())
            }
            # filters
            if countries and (data["buyer_country"] or "").upper() not in countries:
                continue
            if min_ticket and ticket < min_ticket:
                continue
            _add_rfq(db, data); count += 1
    return count
