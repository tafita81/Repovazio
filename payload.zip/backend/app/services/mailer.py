
import os, base64, requests
from jinja2 import Template

def render_template(tmpl: str, context: dict) -> str:
    return Template(tmpl).render(**(context or {}))

def send_via_provider(provider: str, cfg: dict, to_email: str, subject_tmpl: str, body_tmpl: str, context: dict, attachments=None):
    provider = (provider or "").lower().strip()
    if provider == "sendgrid_api":
        return send_sendgrid_api(cfg, to_email, subject_tmpl, body_tmpl, context, attachments or [])
    # fallback SMTP (opcional)
    return send_smtp(cfg, to_email, subject_tmpl, body_tmpl, context, attachments or [])

def send_sendgrid_api(cfg: dict, to_email: str, subject_tmpl: str, body_tmpl: str, context: dict, attachments):
    api_key = os.getenv(cfg.get("sendgrid_api_key_env","SENDGRID_API_KEY"))
    if not api_key:
        raise RuntimeError("SENDGRID_API_KEY não configurada no ambiente.")
    from_email = cfg.get("from_email") or "noreply@example.com"
    from_name  = cfg.get("from_name") or "Broker AutoPilot"
    subject = render_template(subject_tmpl, context)
    body    = render_template(body_tmpl, context)

    data = {
      "personalizations": [{"to": [{"email": to_email}]}],
      "from": {"email": from_email, "name": from_name},
      "subject": subject,
      "content": [{"type": "text/plain", "value": body}],
      "custom_args": context or {},
      "headers": {"X-Message-Id": context.get("message_id","")},
      "tracking_settings": {"click_tracking": {"enable": True}, "open_tracking": {"enable": True}},
    }
    if attachments:
        data["attachments"] = []
        for att in attachments:
            with open(att["path"], "rb") as f:
                b64 = base64.b64encode(f.read()).decode("ascii")
            data["attachments"].append({
                "content": b64,
                "type": "application/pdf",
                "filename": att.get("filename","arquivo.pdf"),
                "disposition": "attachment"
            })

    r = requests.post("https://api.sendgrid.com/v3/mail/send",
                      headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                      json=data, timeout=30)
    if r.status_code not in (200, 202):
        raise RuntimeError(f"SendGrid erro {r.status_code}: {r.text}")
    return True

# SMTP fallback (mantido caso queira usar no futuro)
import smtplib, ssl
from email.message import EmailMessage

def send_smtp(cfg: dict, to_email: str, subject_tmpl: str, body_tmpl: str, context: dict, attachments):
    subject = render_template(subject_tmpl, context)
    body    = render_template(body_tmpl, context)

    msg = EmailMessage()
    msg["From"] = cfg.get("from_email") or "noreply@example.com"
    msg["To"]   = to_email
    msg["Subject"] = subject
    msg.set_content(body)

    for att in attachments or []:
        with open(att["path"], "rb") as f:
            data = f.read()
        msg.add_attachment(data, maintype="application", subtype="pdf", filename=att.get("filename","arquivo.pdf"))

    context_ssl = ssl.create_default_context()
    with smtplib.SMTP(cfg.get("smtp_host",""), int(cfg.get("smtp_port",587))) as server:
        server.starttls(context=context_ssl)
        user = cfg.get("smtp_user"); pwd = cfg.get("smtp_pass")
        if user: server.login(user, pwd)
        server.send_message(msg)
    return True
