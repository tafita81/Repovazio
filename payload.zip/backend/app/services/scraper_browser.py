import os, time
from playwright.sync_api import sync_playwright

SHOT_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "scraper_shots")
os.makedirs(SHOT_DIR, exist_ok=True)

def get_html(url: str, screenshot: bool=False, slug: str="page") -> str:
    with sync_playwright() as p:
        br = p.chromium.launch(headless=True)
        ctx = br.new_context()
        page = ctx.new_page()
        page.set_default_timeout(20000)
        page.goto(url, wait_until="load")
        html = page.content()
        if screenshot:
            ts = int(time.time())
            fp = os.path.join(SHOT_DIR, f"{slug}-{ts}.png")
            try:
                page.screenshot(path=fp, full_page=True)
            except Exception:
                pass
        br.close()
        return html
