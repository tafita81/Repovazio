import time, json, hashlib, urllib.robotparser
from typing import Dict, List, Any
import requests
from bs4 import BeautifulSoup
from sqlalchemy.orm import Session
from urllib.parse import urlparse
from ..models import ScraperBlueprint, RFQ
from .scraper_browser import get_html

UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"

def _robots_allowed(start_url: str) -> bool:
    try:
        u = urlparse(start_url)
        robots = f"{u.scheme}://{u.netloc}/robots.txt"
        rp = urllib.robotparser.RobotFileParser()
        rp.set_url(robots); rp.read()
        return rp.can_fetch(UA, start_url)
    except Exception:
        return False

def _http_get(url: str) -> str:
    r = requests.get(url, headers={"User-Agent": UA, "Accept-Language":"en-US,en;q=0.8"}, timeout=20)
    r.raise_for_status(); return r.text

def _hash(s: str) -> str: return hashlib.md5(s.encode("utf-8")).hexdigest()[:10]

def _parse_items(html: str, cfg: Dict[str, Any]) -> List[Dict[str, Any]]:
    soup = BeautifulSoup(html, "html.parser")
    items_sel = cfg.get("selectors",{}).get("item")
    if not items_sel: return []
    out = []
    for node in soup.select(items_sel):
        def ext(sel, attr=None):
            if not sel: return None
            el = node.select_one(sel)
            if not el: return None
            return el.get(attr) if attr else el.get_text(strip=True)
        item = {
            "rfq_id": ext(cfg["selectors"].get("rfq_id")) or _hash(ext(cfg["selectors"].get("title") or "") or str(time.time())),
            "title": ext(cfg["selectors"].get("title")),
            "buyer_company": ext(cfg["selectors"].get("buyer_company")),
            "buyer_country": ext(cfg["selectors"].get("buyer_country")),
            "category": ext(cfg["selectors"].get("category")),
            "ticket_val_usd": None, "incoterm": "DAP", "lead_time_required_days": 30,
            "description": ext(cfg["selectors"].get("description")),
            "created_ts": int(time.time()), "notes": f"scraped:{cfg.get('name','source')}"
        }
        link_sel = cfg["selectors"].get("link")
        href = ext(link_sel, "href") if link_sel else None
        if href: item["notes"] += f" | link:{href}"
        out.append(item)
    return out

def run_blueprint(db: Session, bp: ScraperBlueprint, dry_run: bool=False, limit: int=50):
    try:
        cfg = json.loads(bp.config_json or "{}")
    except Exception:
        cfg = {}
    start_urls = cfg.get("start_urls") or []
    collected = []
    for u in start_urls[:5]:
        if not _robots_allowed(u):
            return {"ok": False, "error": "blocked_by_robots", "url": u}
        html = _http_get(u) if (bp.method or "http")=="http" else get_html(u, screenshot=bool(cfg.get("screenshot", False)), slug=bp.slug)
        items = _parse_items(html, cfg)[:limit]
        collected.extend(items)
    inserted = 0
    if not dry_run:
        for data in collected:
            exist = db.query(RFQ).filter(RFQ.rfq_id==data["rfq_id"]).first()
            if not exist:
                db.add(RFQ(**data)); inserted += 1
        db.commit()
    bp.last_run_ts=int(time.time()); bp.last_ok=True; bp.last_msg=f"coletados={len(collected)} inseridos={inserted}"
    db.commit()
    return {"ok": True, "collected": len(collected), "inserted": inserted}

def harvest_active_week(db: Session, limit_per_bp: int=50) -> int:
    cnt=0
    rows = db.query(ScraperBlueprint).filter(ScraperBlueprint.enabled==True).all()
    for bp in rows:
        try:
            res = run_blueprint(db, bp, dry_run=False, limit=limit_per_bp)
            if res.get("ok"): cnt += int(res.get("inserted",0))
        except Exception:
            pass
    return cnt
