
import json, os
from typing import List
from ..models import RFQ

RULES_PATH = os.path.join(os.path.dirname(__file__), "..", "data_compliance_rules.json")

def load_rules():
    with open(RULES_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def region_code(country: str) -> str:
    c = (country or "").strip().upper()
    if c in {"US","USA","ESTADOS UNIDOS"}: return "US"
    if c in {"BR","BRA","BRASIL"}: return "BR"
    if c in {"IN","INDIA","ÍNDIA"}: return "IN"
    if c in {"EU","EUR","UE","EUROPA","DE","FR","ES","IT","PT","NL","SE","FI","PL","CZ"}: return "EU"
    return "GLOBAL"

def best_category_key(cat: str) -> str:
    keys = ["EV/DCFC","BESS/Storage","HVAC/Heat Pump","Robotics/Automation",
            "RF/Test/Imaging","Optics/Photonics/Quantum","Beauty/Perfumes",
            "Electronics/Components","General DS/Wholesale"]
    s = (cat or "").lower()
    for k in keys:
        if k.lower().split()[0] in s or any(t in s for t in k.lower().split("/")):
            return k
    return "General DS/Wholesale"

def checklist_for(destination_country: str, category: str) -> List[str]:
    rules = load_rules()
    region = region_code(destination_country)
    key = best_category_key(category)
    out = []
    out += rules.get("defaults", [])
    cat_rules = rules.get(key, {})
    if region in cat_rules:
        out += cat_rules[region]
    elif "GLOBAL" in cat_rules:
        out += cat_rules["GLOBAL"]
    return list(dict.fromkeys(out))  # dedupe preserving order
