import json
from typing import List, Dict
from sqlalchemy.orm import Session
from ..models import Supplier, RFQ, Assignment

DEFAULT_POLICY = {
  "evidence_min": 0.7,
  "max_suppliers_per_rfq": 5,
  "exclude_country": "IN",
  "category_map": {
    "EV/DCFC": ["ev", "charger", "dcfc", "energy"],
    "BESS/Storage": ["bess", "battery", "storage", "inverter"],
    "HVAC/Heat Pump": ["hvac", "heat", "pump"],
    "Robotics/Automation": ["robot", "cobot", "agv", "amr", "sensor", "vision"],
    "RF/Test/Imaging": ["rf", "microwave", "imaging", "thermal", "test"],
    "Optics/Photonics/Quantum": ["optic", "photon", "laser", "cryogen", "qkd", "qrng"],
    "Beauty/Perfumes": ["perfume", "beauty", "cosmetic"],
    "Electronics/Components": ["componente", "semicond", "distribuição ti", "electronics", "component"],
    "General DS/Wholesale": ["dropship", "wholesale", "general"]
  },
  "weights": {
    "category_match": 0.35,
    "region_proximity": 0.20,
    "program_fit": 0.20,
    "evidence_score": 0.15,
    "lead_time_signal": 0.05,
    "historical_success": 0.05
  },
  "program_priority": ["dropshipping","reseller","partner","affiliate","distributor"],
  "incoterm_defaults": {
    "EV/DCFC": "DAP",
    "BESS/Storage": "DAP",
    "HVAC/Heat Pump": "DAP",
    "Robotics/Automation": "DAP",
    "RF/Test/Imaging": "DAP",
    "Optics/Photonics/Quantum": "DAP",
    "Beauty/Perfumes": "DDP",
    "Electronics/Components": "DAP",
    "General DS/Wholesale": "DDP"
  }
}

def load_policy(policy_json: str | None) -> Dict:
    if not policy_json:
        return DEFAULT_POLICY
    try:
        return json.loads(policy_json)
    except Exception:
        return DEFAULT_POLICY

def tokens(s: str) -> List[str]:
    return [t.strip().lower() for t in (s or "").replace("/", " ").replace("&", " ").split()]

def estimate_ticket_val(r: RFQ) -> float:
    try:
        qty = float(r.quantity or 0)
        tgt = float(r.target_price or 0)
        val = qty*tgt
        return val if val>0 else 5000.0
    except Exception:
        return 5000.0

def match_and_assign(db: Session, policy: Dict | None = None, max_suppliers: int = 5) -> Dict:
    pol = policy or DEFAULT_POLICY
    weights = pol.get("weights", DEFAULT_POLICY["weights"])
    program_priority = pol.get("program_priority", DEFAULT_POLICY["program_priority"])

    suppliers = db.query(Supplier).all()
    rfqs = db.query(RFQ).all()
    db.query(Assignment).delete()

    def category_match_score(r: RFQ, s: Supplier) -> float:
        r_t = tokens(r.category or "")
        s_t = tokens((s.category or "") + " " + (s.program_type or ""))
        if any(t in s_t for t in r_t if t):
            return 1.0
        for k, words in pol.get("category_map",{}).items():
            if k.lower() in (r.category or "").lower() and any(w in " ".join(s_t) for w in words):
                return 1.0
        return 0.0

    total_links = 0
    for r in rfqs:
        ticket_val = estimate_ticket_val(r)
        cands = []
        for s in suppliers:
            if (s.evidence_score or 0.0) < pol.get("evidence_min", 0.7):
                continue
            cm = category_match_score(r, s)
            if cm <= 0: 
                continue
            reg = (s.country_region or "").lower()
            dest = (r.destination_country or "").lower()
            region = 0.5
            if dest and reg:
                if dest in reg or reg in dest:
                    region = 1.0
                elif any(x in reg for x in ["global","eu","eua","usa","latam","gcc","apac","global"]):
                    region = 0.75
            pt = (s.program_type or "").lower()
            pfit = 1.0 if any(p in pt for p in program_priority) else 0.0
            ev = float(s.evidence_score or 0.0)
            lead = 1.0 if any(x in (s.notes or "").lower() for x in ["overseas warehouse","pronta-entrega","stock","same-day"]) else 0.0

            score = (weights["category_match"]*cm + 
                     weights["region_proximity"]*region + 
                     weights["program_fit"]*pfit + 
                     weights["evidence_score"]*ev +
                     weights["lead_time_signal"]*lead +
                     weights["historical_success"]*0.0)
            cands.append((score, s))

        cands.sort(key=lambda x: x[0], reverse=True)
        top = [x for x in cands if x[0]>0][:max_suppliers]
        for sc, s in top:
            pct = 0.08
            if "drop" in (s.program_type or "").lower(): pct = 0.12
            if "affiliate" in (s.program_type or "").lower(): pct = 0.03
            broker_rev = ticket_val * pct
            a = Assignment(
                rfq_id=r.rfq_id,
                supplier_id=s.id,
                supplier_name=s.name,
                supplier_website=s.website,
                match_score=float(sc),
                ticket_val_usd=float(ticket_val),
                broker_revenue_est_usd=float(broker_rev),
                incoterm=r.incoterm or "DAP",
                lead_time_days=r.lead_time_required_days or "",
                notes="auto-assigned"
            )
            db.add(a)
            total_links += 1
    db.commit()
    return {"assigned_links": total_links, "rfqs": len(rfqs)}
