
import os, time, requests
from sqlalchemy.orm import Session
from ..models import GlobalCredential
from .mailer import send_via_provider

def get_cred(db: Session, key: str, default: str | None = None):
    row = db.query(GlobalCredential).filter(GlobalCredential.service=="monitoring", GlobalCredential.key_name==key).first()
    return row.value if row else default

def ping(url: str) -> bool:
    if not url: return False
    try:
        r = requests.get(url, timeout=10)
        return r.status_code in (200, 201, 204)
    except Exception:
        return False

def alert_email(db: Session, subject: str, body: str) -> bool:
    ops = get_cred(db, "ops_email")
    if not ops: 
        return False
    # usa SendGrid provider já configurado no autopilot_config.json
    from ..app_config import load_email_cfg
    em = load_email_cfg()
    try:
        send_via_provider(em.get("provider","sendgrid_api"), em, ops, subject, body, {"message_id": f"alert-{int(time.time())}"})
        return True
    except Exception:
        return False
