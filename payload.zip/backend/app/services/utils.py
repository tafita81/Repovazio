from urllib.parse import urlparse

def primary_domain(url: str | None) -> str | None:
    if not url: 
        return None
    u = str(url).split()[0]
    if "://" not in u:
        u = "https://" + u
    try:
        host = urlparse(u).netloc.lower().replace("www.","")
        return host or None
    except Exception:
        return None

def compute_evidence_score(website: str | None, program_url: str | None, evidence: str | None, program_type: str | None) -> float:
    score = 0.0
    if program_url and len(program_url) > 5: score += 0.4
    if evidence and len(evidence) > 5: score += 0.3
    if website and len(website) > 5: score += 0.2
    if program_type and program_type:
        if any(k in program_type.lower() for k in ["drop","resell","partner","affiliate","distrib"]):
            score += 0.1
    return min(score, 1.0)
