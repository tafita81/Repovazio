
from sqlalchemy.orm import Session
from ..models import Assignment

def adjust_weights_on_win(db: Session, policy: dict, rfq_id: str, supplier_name: str, revenue_usd: float = 0.0) -> dict:
    # Heurística: se dropship venceu com alta margem, sobe 'program_fit'; se regional venceu, sobe 'region_proximity'.
    weights = policy.get("weights", {}).copy()
    rows = db.query(Assignment).filter(Assignment.rfq_id==rfq_id, Assignment.supplier_name==supplier_name).all()
    if not rows:
        return policy
    a = rows[0]
    # Ajustes leves
    if "drop" in (a.notes or "").lower() or "drop" in supplier_name.lower():
        weights["program_fit"] = min(0.30, weights.get("program_fit",0.20) + 0.02)
    else:
        weights["category_match"] = min(0.45, weights.get("category_match",0.35) + 0.01)
    weights["region_proximity"] = min(0.30, weights.get("region_proximity",0.20) + 0.01)
    policy["weights"] = weights
    return policy
