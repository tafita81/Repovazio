
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from datetime import datetime
from sqlalchemy.orm import Session
from ..models import RFQ, Assignment
from .compliance import checklist_for

def render_quote_pdf(db: Session, rfq_id: str, path: str, top_k: int = 2, buyer_safe: bool = True, brand: str = ""):
    rfq = db.query(RFQ).filter(RFQ.rfq_id==rfq_id).first()
    if not rfq:
        raise RuntimeError("RFQ não encontrado")
    assigns = db.query(Assignment).filter(Assignment.rfq_id==rfq_id).order_by(Assignment.broker_revenue_est_usd.desc()).all()
    picks = assigns[:top_k]

    c = canvas.Canvas(path, pagesize=A4)
    W, H = A4
    y = H - 20*mm
    def line(t, fs=12):
        nonlocal y
        c.setFont("Helvetica", fs)
        c.drawString(20*mm, y, t)
        y -= (fs+4)

    # Cabeçalho
    line((brand or "") + " — COTAÇÃO A/B — RFQ " + (rfq.rfq_id or ""), 16)
    line(f"Título: {rfq.title or ''}")
    line(f"Categoria: {rfq.category or ''} | Destino: {rfq.destination_country or ''}")
    line(f"Incoterm: {rfq.incoterm or 'DAP'} | Prazo: {rfq.lead_time_required_days or '—'} dias")
    line(f"Data: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}")
    y -= 6

    # Opções
    for i, a in enumerate(picks, 1):
        y -= 6
        line(f"Opção {i}: " + (f"Fornecedor {chr(64+i)}" if buyer_safe else a.supplier_name), 14)
        line("Site: " + ("—" if buyer_safe else (a.supplier_website or "")))
        line(f"Ticket estimado: US$ {a.ticket_val_usd:,.2f} | Receita broker: US$ {a.broker_revenue_est_usd:,.2f}")
        line(f"Match Score: {a.match_score:.2f} | Incoterm: {a.incoterm or 'DAP'} | Lead time: {a.lead_time_days or '—'}")

    # Checklist de compliance
    y -= 6
    line("Checklist de Compliance:", 14)
    items = checklist_for(rfq.destination_country or "", rfq.category or "")
    for it in items:
        line(f" - {it}")

    c.showPage()
    c.save()
    return path


def mask_notice(can_reveal_after: str) -> str:
    if can_reveal_after == "none":
        return "Identidade de fornecedores totalmente visível."
    if can_reveal_after == "ncnda":
        return "Identidade de fornecedores será revelada após assinatura de NCNDA."
    if can_reveal_after == "deposit":
        return "Identidade de fornecedores será revelada após depósito de segurança."
    return "Identidade de fornecedores será revelada após assinatura de NCNDA ou depósito de segurança."
