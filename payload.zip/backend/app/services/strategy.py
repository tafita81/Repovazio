
from sqlalchemy.orm import Session
from ..models import RFQ, Assignment, Supplier
import math

def apply_zero_capex_strategy(db: Session, rfq_id: str):
    """
    Marca a estratégia ideal p/ RFQ visando lucro alto sem investimento (zero CAPEX):
    1) Preferir dropshipping (se disponível nos suppliers casados)
    2) Se não houver, preferir reseller com prazo (net terms) ou comissão direta
    3) Ajustar Incoterm para DAP/DDP conforme categoria
    4) Incentivar bundles/alternativas equivalentes (A/B)
    """
    rows = db.query(Assignment).filter(Assignment.rfq_id==rfq_id).all()
    for a in rows:
        s: Supplier = db.query(Supplier).filter(Supplier.name==a.supplier_name).first()
        prog = (s.program_type or "").lower() if s else ""
        note = a.notes or ""
        if "drop" in prog:
            a.strategy = "dropship"
            a.notes = (note + " | prefer dropship zero-capex").strip()
        elif "reseller" in prog or "partner" in prog:
            a.strategy = "reseller_net_terms"
            a.notes = (note + " | pedir NET30/NET45").strip()
        else:
            a.strategy = "commission"
            a.notes = (note + " | comissão por indicação").strip()
    db.commit()
    return True
