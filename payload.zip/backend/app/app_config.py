
import os, json

CFG_PATH = os.path.join(os.path.dirname(__file__), "autopilot_config.json")

def load_cfg():
    with open(CFG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def load_email_cfg():
    cfg = load_cfg()
    return cfg.get("email", {})
