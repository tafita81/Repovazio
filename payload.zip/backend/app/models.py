from sqlalchemy import Column, Integer, String, Float, Text
from .db import Base

class Supplier(Base):
    __tablename__ = "suppliers"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    country_region = Column(String, index=True)
    category = Column(String, index=True)
    program_type = Column(String, index=True)
    website = Column(String)
    program_url = Column(String)
    evidence = Column(String)
    indiamart_experience = Column(String, default="sem_evidencia_publica")
    notes = Column(Text)
    evidence_score = Column(Float, default=0.0)

class RFQ(Base):
    __tablename__ = "rfqs"
    id = Column(Integer, primary_key=True, index=True)
    rfq_id = Column(String, unique=True, index=True)
    title = Column(String)
    category = Column(String, index=True)
    hs_code = Column(String, index=True)
    quantity = Column(String)
    uom = Column(String)
    target_price = Column(Float)
    currency = Column(String)
    incoterm = Column(String)
    destination_country = Column(String, index=True)
    buyer_company = Column(String)
    buyer_country = Column(String)
    deadline_date = Column(String)
    urgency = Column(String)  # 1-5 string or numeric-like
    compliance_requirements = Column(Text)
    shipping_terms = Column(String)
    lead_time_required_days = Column(String)
    notes = Column(Text)

class Assignment(Base):
    __tablename__ = "assignments"
    id = Column(Integer, primary_key=True, index=True)
    rfq_id = Column(String, index=True)
    supplier_id = Column(Integer, index=True)
    supplier_name = Column(String, index=True)
    supplier_website = Column(String)
    match_score = Column(Float, default=0.0)
    ticket_val_usd = Column(Float, default=0.0)
    broker_revenue_est_usd = Column(Float, default=0.0)
    incoterm = Column(String)
    lead_time_days = Column(String)
    notes = Column(Text)


class SupplierConnection(Base):
    __tablename__ = "supplier_connections"
    id = Column(Integer, primary_key=True, index=True)
    supplier_id = Column(Integer, index=True)
    supplier_name = Column(String, index=True)
    api_base_url = Column(String)
    api_key = Column(String)
    partner_signup_url = Column(String)
    developer_docs_url = Column(String)
    status = Column(String)  # planned, requested, approved, active
    reveal_after = Column(String, default="deposit_or_ncnda")  # none | ncnda | deposit | deposit_or_ncnda
    public_alias = Column(String, default=None)
    notes = Column(Text)


class GlobalCredential(Base):
    __tablename__ = "global_credentials"
    id = Column(Integer, primary_key=True, index=True)
    service = Column(String, index=True)   # ex.: sendgrid, searchapi, indiamart, stripe, openai, zapier
    key_name = Column(String, index=True)  # ex.: api_key, from_email, webhook_url
    value = Column(String)                  # armazenado como texto simples (pode ser cifrado futuramente)
    signup_url = Column(String, default=None)
    docs_url = Column(String, default=None)
    notes = Column(Text, default=None)


class OutboundLog(Base):
    __tablename__ = "outbound_log"
    id = Column(Integer, primary_key=True, index=True)
    rfq_id = Column(String, index=True)
    buyer_email = Column(String, index=True)
    subject = Column(String)
    lang = Column(String, default="en")
    sent_at = Column(String)
    message_id = Column(String, index=True)
    last_event = Column(String, default=None) # delivered/open/click/bounce
    opened_at = Column(String, default=None)
    clicked_at = Column(String, default=None)

class EmailEvent(Base):
    __tablename__ = "email_events"
    id = Column(Integer, primary_key=True, index=True)
    rfq_id = Column(String, index=True)
    buyer_email = Column(String, index=True)
    event = Column(String, index=True)   # processed, delivered, open, click, bounce, dropped, spamreport
    timestamp = Column(Float)
    sg_message_id = Column(String, index=True)
    raw = Column(Text)


class LeadSource(Base):
    __tablename__ = "lead_sources"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    slug = Column(String, unique=True, index=True)
    country = Column(String, index=True)
    tier = Column(String, default="T2")
    rfqs_per_day_est = Column(Integer, default=0)
    potential_month_usd = Column(Integer, default=0)
    signup_url = Column(String, default=None)
    docs_url = Column(String, default=None)
    api_fields = Column(Text, default=None)
    enabled = Column(Boolean, default=False)


class ScraperBlueprint(Base):
    __tablename__ = "scraper_blueprints"
    id = Column(Integer, primary_key=True, index=True)
    slug = Column(String, unique=True, index=True)
    domain = Column(String, index=True)          # ex.: tradeindia.com
    name = Column(String, index=True)
    method = Column(String, default="http")      # http|browser
    enabled = Column(Boolean, default=False)
    config_json = Column(Text, default=None)     # selectors, start_urls, date_window_days, fields map
    last_run_ts = Column(Integer, default=None)
    last_ok = Column(Boolean, default=None)
    last_msg = Column(Text, default=None)
