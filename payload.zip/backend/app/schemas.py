from pydantic import BaseModel
from typing import Optional, List

class SupplierIn(BaseModel):
    name: str
    country_region: Optional[str] = None
    category: Optional[str] = None
    program_type: Optional[str] = None
    website: Optional[str] = None
    program_url: Optional[str] = None
    evidence: Optional[str] = None
    indiamart_experience: Optional[str] = "sem_evidencia_publica"
    notes: Optional[str] = None
    evidence_score: Optional[float] = 0.0

class RFQIn(BaseModel):
    rfq_id: str
    title: Optional[str] = None
    category: Optional[str] = None
    hs_code: Optional[str] = None
    quantity: Optional[str] = None
    uom: Optional[str] = None
    target_price: Optional[float] = None
    currency: Optional[str] = None
    incoterm: Optional[str] = None
    destination_country: Optional[str] = None
    buyer_company: Optional[str] = None
    buyer_country: Optional[str] = None
    deadline_date: Optional[str] = None
    urgency: Optional[str] = None
    compliance_requirements: Optional[str] = None
    shipping_terms: Optional[str] = None
    lead_time_required_days: Optional[str] = None
    notes: Optional[str] = None

class StrictHarvestBody(BaseModel):
    domains: Optional[List[str]] = None
    keywords: Optional[List[str]] = None
