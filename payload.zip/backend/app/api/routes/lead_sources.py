
from fastapi import APIRouter, Body, Query, Depends
from sqlalchemy.orm import Session
from typing import List, Dict
import json, re

from ...db import SessionLocal
from ...models import LeadSource, GlobalCredential

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def slugify(s:str)->str:
    return re.sub(r'[^a-z0-9]+','-', s.strip().lower()).strip('-')

@router.get("/list")
async def list_sources(only_enabled: bool = False, db: Session = Depends(get_db)):
    q = db.query(LeadSource)
    if only_enabled:
        q = q.filter(LeadSource.enabled==True)
    rows = q.order_by(LeadSource.tier.asc(), LeadSource.name.asc()).all()
    out = []
    for r in rows:
        try:
            af = json.loads(r.api_fields or "[]")
        except Exception:
            af = []
        out.append({
            "id": r.id, "name": r.name, "slug": r.slug, "country": r.country, "tier": r.tier,
            "rfqs_per_day_est": r.rfqs_per_day_est, "potential_month_usd": r.potential_month_usd,
            "signup_url": r.signup_url, "docs_url": r.docs_url, "enabled": r.enabled, "api_fields": af
        })
    return out

@router.post("/upsert")
async def upsert_source(payload: Dict = Body(...), db: Session = Depends(get_db)):
    name = payload.get("name"); 
    if not name: return {"ok": False, "error": "missing_name"}
    slug = payload.get("slug") or slugify(name)
    r = db.query(LeadSource).filter(LeadSource.slug==slug).first()
    fields = {
        "name": name,
        "slug": slug,
        "country": payload.get("country") or "",
        "tier": payload.get("tier") or "T2",
        "rfqs_per_day_est": int(payload.get("rfqs_per_day_est") or 0),
        "potential_month_usd": int(payload.get("potential_month_usd") or 0),
        "signup_url": payload.get("signup_url"),
        "docs_url": payload.get("docs_url"),
        "api_fields": json.dumps(payload.get("api_fields") or []),
        "enabled": bool(payload.get("enabled", False)),
    }
    if r:
        for k,v in fields.items():
            setattr(r, k, v)
    else:
        r = LeadSource(**fields); db.add(r)
    db.commit()
    return {"ok": True, "id": r.id, "slug": r.slug}

@router.post("/toggle")
async def toggle_source(slug: str = Query(...), enabled: bool = Query(True), db: Session = Depends(get_db)):
    r = db.query(LeadSource).filter(LeadSource.slug==slug).first()
    if not r: return {"ok": False, "error": "not_found"}
    r.enabled = bool(enabled); db.commit(); return {"ok": True}

@router.post("/save_creds")
async def save_creds(slug: str = Query(...), payload: Dict = Body(...), db: Session = Depends(get_db)):
    svc = f"lead:{slug}"
    for k,v in (payload or {}).items():
        row = db.query(GlobalCredential).filter(GlobalCredential.service==svc, GlobalCredential.key_name==k).first()
        if row: row.value = v
        else: db.add(GlobalCredential(service=svc, key_name=k, value=v))
    db.commit(); return {"ok": True}

@router.get("/creds")
async def list_creds(slug: str = Query(...), db: Session = Depends(get_db)):
    svc = f"lead:{slug}"
    rows = db.query(GlobalCredential).filter(GlobalCredential.service==svc).all()
    def mask(v): return ("*"*(len(v)-4)+v[-4:]) if v and len(v)>4 else v
    return [{"key_name": r.key_name, "value_masked": mask(r.value or "")} for r in rows]

@router.post("/buyer_countries/set")
async def buyer_countries_set(countries: List[str] = Body(...), db: Session = Depends(get_db)):
    row = db.query(GlobalCredential).filter(GlobalCredential.service=="buyer_prefs", GlobalCredential.key_name=="countries").first()
    if row: row.value = ",".join(countries)
    else: db.add(GlobalCredential(service="buyer_prefs", key_name="countries", value=",".join(countries)))
    db.commit(); return {"ok": True}

@router.get("/buyer_countries/get")
async def buyer_countries_get(db: Session = Depends(get_db)):
    row = db.query(GlobalCredential).filter(GlobalCredential.service=="buyer_prefs", GlobalCredential.key_name=="countries").first()
    return {"countries": (row.value.split(",") if row and row.value else [])}

@router.post("/buyer_categories/set")
async def buyer_categories_set(categories: List[str] = Body(...), db: Session = Depends(get_db)):
    row = db.query(GlobalCredential).filter(GlobalCredential.service=="buyer_prefs", GlobalCredential.key_name=="categories").first()
    if row: row.value = ",".join(categories)
    else: db.add(GlobalCredential(service="buyer_prefs", key_name="categories", value=",".join(categories)))
    db.commit(); return {"ok": True}

@router.get("/buyer_categories/get")
async def buyer_categories_get(db: Session = Depends(get_db)):
    row = db.query(GlobalCredential).filter(GlobalCredential.service=="buyer_prefs", GlobalCredential.key_name=="categories").first()
    return {"categories": (row.value.split(",") if row and row.value else [])}

@router.get("/bootstrap_info")
async def bootstrap_info():
    return {
        "indiamart": {"name":"IndiaMART", "signup":"https://my.indiamart.com/", "docs":"https://seller.indiamart.com/",
                      "api_fields":["INDIAMART_MOBILE","INDIAMART_TOKEN"],
                      "steps":[
                        "Crie conta Buyer/Seller e verifique telefone (OTP).",
                        "Ative alertas de RFQ e exportações CSV (Buyer).",
                        "Solicite integração via suporte (API pública não é completa).",
                        "Cole INDIAMART_MOBILE e token (se houver) no app."
                      ]},
        "apify-alibaba":{"name":"Apify (Alibaba/1688)", "signup":"https://apify.com/","docs":"https://docs.apify.com/",
                      "api_fields":["APIFY_API_KEY","ACTOR_ID"],
                      "steps":[
                        "Crie APIFY_API_KEY.",
                        "Escolha Actor de Alibaba/1688, configure termos/categorias.",
                        "Direcione dataset para webhook do app ou export CSV."
                      ]},
        "sam-gov":{"name":"SAM.gov","signup":"https://sam.gov/","docs":"https://open.gsa.gov/api/",
                   "api_fields":["SAM_GOV_API_KEY"],
                   "steps":[ "Gere API Key e use endpoints de search (NAICS/categorias)." ]},
        "mercadolibre-br":{"name":"MercadoLivre BR","signup":"https://developers.mercadolivre.com.br/",
            "docs":"https://developers.mercadolibre.com.ar/en_us",
            "api_fields":["ML_CLIENT_ID","ML_CLIENT_SECRET","ML_ACCESS_TOKEN"],
            "steps":["Crie app, OAuth, gere Access Token; use products/listings/categorias."]},
        "mercadolibre-mx":{"name":"MercadoLibre MX","signup":"https://developers.mercadolibre.com.mx/",
            "docs":"https://developers.mercadolibre.com.mx",
            "api_fields":["ML_MX_CLIENT_ID","ML_MX_CLIENT_SECRET","ML_MX_ACCESS_TOKEN"],
            "steps":["Mesmo fluxo do ML BR."]},
        "walmart":{"name":"Walmart Marketplace","signup":"https://developer.walmart.com/","docs":"https://developer.walmart.com/",
            "api_fields":["WM_CLIENT_ID","WM_CLIENT_SECRET"],
            "steps":[ "Aplique para Marketplace; gere credenciais e configure orders/feeds." ]},
        "linkedin-sn":{"name":"LinkedIn Sales Navigator","signup":"https://business.linkedin.com/sales-solutions",
            "docs":"https://learn.microsoft.com/linkedin/",
            "api_fields":["LI_COOKIE_OR_TOKEN"],
            "steps":["Sem API pública full; use exportações permitidas ou e-mail parser."],
            "notes":"Respeite termos do LinkedIn."},
        "thomasnet":{"name":"ThomasNet","signup":"https://www.thomasnet.com/",
            "docs":"https://developer.thomasnet.com","api_fields":["THOMASNET_API_KEY"],
            "steps":["Solicite API e aplique filtros por categoria/local."]},
        "tradeindia":{"name":"TradeIndia","signup":"https://www.tradeindia.com/",
            "docs":"https://www.tradeindia.com/seller/help-center.html","api_fields":["TRADEINDIA_API_KEY"],
            "steps":["Crie conta e ative RFQ alerts; use APIs se liberadas."]},
        "made-in-china":{"name":"Made-in-China","signup":"https://www.made-in-china.com/",
            "docs":"https://developer.made-in-china.com","api_fields":["MIC_API_KEY"],
            "steps":["Solicite chaves e defina categorias alvo."]},
        "global-sources":{"name":"Global Sources","signup":"https://www.globalsources.com/",
            "docs":"https://www.globalsources.com/FAQ","api_fields":["GS_API_KEY"],
            "steps":["Ative alertas de RFQ, peça acesso técnico se disponível."]},
        "europages":{"name":"Europages","signup":"https://www.europages.com/",
            "docs":"https://help.europages.com","api_fields":["EUROPAGES_API_KEY"],
            "steps":["Crie conta, defina países e setores alvo."]},
        "kompass":{"name":"Kompass","signup":"https://br.kompass.com/",
            "docs":"https://br.kompass.com/pt/api/","api_fields":["KOMPASS_API_KEY"],
            "steps":["Solicite API e ajuste filtros B2B."]},
        "rakuten-jp":{"name":"Rakuten JP","signup":"https://global.rakuten.com/corp/",
            "docs":"https://webservice.rakuten.co.jp/","api_fields":["RAKUTEN_API_KEY"],
            "steps":["Crie conta de desenvolvedor e gere chaves para listings."]},
        "lazada":{"name":"Lazada","signup":"https://open.lazada.com","docs":"https://open.lazada.com/doc/doc.htm",
            "api_fields":["LAZADA_API_KEY","LAZADA_APP_SECRET"],
            "steps":["Crie app, gere chaves, autorize sellers regionais."]},
        "shopee":{"name":"Shopee","signup":"https://open.shopee.com","docs":"https://open.shopee.com/developer-guide/overview",
            "api_fields":["SHOPEE_PARTNER_ID","SHOPEE_PARTNER_KEY"],
            "steps":["Crie integração Partner e conecte lojas."]}
    }


@router.post("/buyer_min_ticket/set")
async def buyer_min_ticket_set(min_usd: int = Query(...), db: Session = Depends(get_db)):
    row = db.query(GlobalCredential).filter(GlobalCredential.service=="buyer_prefs", GlobalCredential.key_name=="min_ticket_usd").first()
    if row: row.value = str(int(min_usd))
    else: db.add(GlobalCredential(service="buyer_prefs", key_name="min_ticket_usd", value=str(int(min_usd))))
    db.commit(); return {"ok": True, "min_ticket_usd": int(min_usd)}

@router.get("/buyer_min_ticket/get")
async def buyer_min_ticket_get(db: Session = Depends(get_db)):
    row = db.query(GlobalCredential).filter(GlobalCredential.service=="buyer_prefs", GlobalCredential.key_name=="min_ticket_usd").first()
    return {"min_ticket_usd": int(row.value) if row and row.value else 0}
