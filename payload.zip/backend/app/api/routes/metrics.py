from fastapi import APIRouter, Query, Depends
from sqlalchemy.orm import Session
from collections import defaultdict
import time
from ...db import SessionLocal
from ...models import RFQ, Assignment, OutboundLog

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/overview")
async def overview(db: Session = Depends(get_db)):
    now = int(time.time()); day_ago = now - 86400
    rfqs = db.query(RFQ).all()
    rfqs24 = [r for r in rfqs if (r.created_ts or 0) >= day_ago]
    total = len(rfqs); total24 = len(rfqs24)
    avg_ticket = (sum(float(r.ticket_val_usd or 0.0) for r in rfqs)/total) if total else 0.0
    max_ticket = max([float(r.ticket_val_usd or 0.0) for r in rfqs], default=0.0)
    sum_ticket = sum(float(r.ticket_val_usd or 0.0) for r in rfqs)

    assigns = db.query(Assignment).all()
    per_rfq = defaultdict(int)
    for a in assigns: per_rfq[a.rfq_id]+=1
    rfq_with_3opts = sum(1 for _,v in per_rfq.items() if v>=3)
    lead_times = [int(r.lead_time_required_days or 0) for r in rfqs if r.lead_time_required_days]
    avg_lead = (sum(lead_times)/len(lead_times)) if lead_times else 0

    outs = db.query(OutboundLog).all()
    sent = len(outs); opened=sum(1 for o in outs if o.opened_at); clicked=sum(1 for o in outs if o.clicked_at)
    open_rate=(opened/sent) if sent else 0.0; click_rate=(clicked/sent) if sent else 0.0
    reminders=sum(1 for o in outs if o.message_id and "-reminder-" in o.message_id)

    cat = defaultdict(lambda: {"count":0,"sum":0.0})
    geo = defaultdict(lambda: {"count":0,"sum":0.0})
    buckets={"0-10k":0,"10-50k":0,"50-100k":0,"100-250k":0,"250k+":0}
    for r in rfqs:
        v=float(r.ticket_val_usd or 0.0)
        cat[r.category or "N/A"]["count"]+=1; cat[r.category or "N/A"]["sum"]+=v
        geo[r.buyer_country or "N/A"]["count"]+=1; geo[r.buyer_country or "N/A"]["sum"]+=v
        if v<10000: buckets["0-10k"]+=1
        elif v<50000: buckets["10-50k"]+=1
        elif v<100000: buckets["50-100k"]+=1
        elif v<250000: buckets["100-250k"]+=1
        else: buckets["250k+"]+=1

    return {
        "rfqs_total": total, "rfqs_24h": total24, "avg_ticket_usd": avg_ticket,
        "max_ticket_usd": max_ticket, "sum_ticket_usd": sum_ticket,
        "suppliers_matched": len(assigns), "rfqs_with_3_options": rfq_with_3opts,
        "avg_lead_time_days": avg_lead, "emails_sent": sent, "open_rate": open_rate,
        "click_rate": click_rate, "reminders_sent": reminders,
        "top_categories": sorted([{"category":k,"count":v["count"],"sum":v["sum"]} for k,v in cat.items()], key=lambda x: x["sum"], reverse=True)[:10],
        "top_countries": sorted([{"country":k,"count":v["count"],"sum":v["sum"]} for k,v in geo.items()], key=lambda x: x["sum"], reverse=True)[:10],
        "ticket_buckets": buckets
    }

@router.get("/timeseries")
async def timeseries(days: int = Query(30, ge=1, le=120), db: Session = Depends(get_db)):
    now = int(time.time()); start = now - days*86400
    def daykey(ts):
        d = time.gmtime(ts); return f"{d.tm_year}-{d.tm_mon:02d}-{d.tm_mday:02d}"
    keys=[]; cur=start
    for i in range(days+1):
        d=time.gmtime(cur + i*86400); keys.append(f"{d.tm_year}-{d.tm_mon:02d}-{d.tm_mday:02d}")
    rfq_day={k:0 for k in keys}; sent_day={k:0 for k in keys}; open_day={k:0 for k in keys}; click_day={k:0 for k in keys}
    from ...models import OutboundLog, RFQ
    for r in db.query(RFQ).all():
        if (r.created_ts or 0) >= start:
            rfq_day[daykey(r.created_ts)] = rfq_day.get(daykey(r.created_ts),0)+1
    for o in db.query(OutboundLog).all():
        if o.sent_at and int(o.sent_at) >= start: sent_day[daykey(int(o.sent_at))] = sent_day.get(daykey(int(o.sent_at)),0)+1
        if o.opened_at and int(o.opened_at) >= start: open_day[daykey(int(o.opened_at))] = open_day.get(daykey(int(o.opened_at)),0)+1
        if o.clicked_at and int(o.clicked_at) >= start: click_day[daykey(int(o.clicked_at))] = click_day.get(daykey(int(o.clicked_at)),0)+1
    return {"rfq": rfq_day, "sent": sent_day, "open": open_day, "click": click_day}

@router.get("/vendor_ranking")
async def vendor_ranking(category: str | None = Query(None), country: str | None = Query(None), top: int = Query(50, ge=1, le=200), db: Session = Depends(get_db)):
    rfqs = {r.rfq_id: r for r in db.query(RFQ).all()}
    assigns = db.query(Assignment).all()
    per_rfq={}
    for a in assigns: per_rfq[a.rfq_id]=per_rfq.get(a.rfq_id,0)+1
    agg={}
    for a in assigns:
        r=rfqs.get(a.rfq_id); 
        if not r: continue
        if category and (r.category or "").lower()!=category.strip().lower(): continue
        if country and (r.buyer_country or "").upper()!=country.strip().upper(): continue
        n=max(1, per_rfq.get(a.rfq_id,1)); share=float(r.ticket_val_usd or 0.0)/float(n)
        k=a.supplier_name or "N/A"; x=agg.get(k) or {"supplier_name":k,"rfqs":0,"sum_usd":0.0,"avg_ticket_usd":0.0}
        x["rfqs"]+=1; x["sum_usd"]+=share; agg[k]=x
    out=list(agg.values())
    for x in out: x["avg_ticket_usd"]=(x["sum_usd"]/x["rfqs"]) if x["rfqs"] else 0.0
    out.sort(key=lambda z:z["sum_usd"], reverse=True); return out[:top]
