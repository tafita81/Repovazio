
from fastapi import APIRouter, Request, Query, Depends
from sqlalchemy.orm import Session
import time, json
from ...db import SessionLocal
from ...models import EmailEvent, OutboundLog
import os, json

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/sendgrid")
CFG_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "autopilot_config.json")

@router.post("/sendgrid")
async def sendgrid_events(request: Request, token: str = Query(None), db: Session = Depends(get_db)):
    # Validar token (?token=XYZ) configurado na URL do webhook no SendGrid
    # Em produção, recomenda-se validar assinatura oficial da Twilio/SendGrid.
    # valida token
    try:
        with open(CFG_PATH, 'r', encoding='utf-8') as f:
            cfg = json.load(f)
        expected = cfg.get('webhook_token')
    except Exception:
        expected = None
    if expected and token != expected:
        return {"ok": False, "error": "invalid_token"}

    try:
        payload = await request.json()
    except Exception:
        payload = []
    if not isinstance(payload, list):
        payload = [payload]
    saved = 0
    for ev in payload:
        event = ev.get("event")
        email = ev.get("email")
        sgid = ev.get("sg_message_id") or ev.get("sg_event_id") or ""
        ts = float(ev.get("timestamp") or time.time())
        rfq_id = None
        ca = ev.get("custom_args") or {}
        rfq_id = ca.get("rfq_id") or rfq_id
        e = EmailEvent(rfq_id=rfq_id, buyer_email=email, event=str(event), timestamp=ts, sg_message_id=sgid, raw=json.dumps(ev)[:10000])
        db.add(e); saved += 1
        # Sync OutboundLog
        row = None
        if rfq_id and email:
            row = db.query(OutboundLog).filter(OutboundLog.rfq_id==rfq_id, OutboundLog.buyer_email==email).order_by(OutboundLog.id.desc()).first()
        if row:
            row.last_event = str(event)
            if event == "open" and not row.opened_at:
                row.opened_at = str(int(ts))
            if event == "click" and not row.clicked_at:
                row.clicked_at = str(int(ts))
    db.commit()
    return {"ok": True, "received": saved}
