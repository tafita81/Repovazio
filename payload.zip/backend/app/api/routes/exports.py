from fastapi import APIRouter, Response, Depends
from sqlalchemy.orm import Session
import csv, io
from ...db import SessionLocal
from ...models import Assignment

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/rfq_assignments.csv")
async def export_assignments(db: Session = Depends(get_db)):
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["rfq_id","supplier_name","supplier_website","match_score","ticket_val_usd","broker_revenue_est_usd","incoterm","lead_time_days","notes"])
    for a in db.query(Assignment).all():
        writer.writerow([a.rfq_id, a.supplier_name, a.supplier_website, a.match_score, a.ticket_val_usd, a.broker_revenue_est_usd, a.incoterm, a.lead_time_days, a.notes])
    csv_bytes = output.getvalue().encode("utf-8")
    return Response(content=csv_bytes, media_type="text/csv")


@router.get("/rfq_assignments_top.json")
async def rfq_assignments_top(limit: int = 100, db: Session = Depends(get_db)):
    # Group assignments by RFQ, keep up to 5 suppliers per RFQ
    from ...models import Assignment
    rows = db.query(Assignment).all()
    grouped = {}
    for a in rows:
        grouped.setdefault(a.rfq_id, [])
        if len(grouped[a.rfq_id]) < 5:
            grouped[a.rfq_id].append({
                "supplier_name": a.supplier_name,
                "supplier_website": a.supplier_website,
                "match_score": a.match_score,
                "ticket_val_usd": a.ticket_val_usd,
                "broker_revenue_est_usd": a.broker_revenue_est_usd,
                "incoterm": a.incoterm,
                "lead_time_days": a.lead_time_days,
                "notes": a.notes
            })
    # Order RFQs by total broker revenue desc
    items = []
    for rfq_id, lst in grouped.items():
        total_rev = sum([x["broker_revenue_est_usd"] or 0.0 for x in lst])
        items.append({"rfq_id": rfq_id, "total_broker_revenue_est_usd": total_rev, "suppliers": lst})
    items.sort(key=lambda x: x["total_broker_revenue_est_usd"], reverse=True)
    return items[:limit]
