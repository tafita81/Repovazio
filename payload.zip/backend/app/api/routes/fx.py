from fastapi import APIRouter
from ...services.fx import get_rates, refresh, to_usd

router = APIRouter()

@router.get("/rates")
async def rates(): return get_rates()

@router.post("/refresh")
async def do_refresh(): return refresh()

@router.get("/to_usd")
async def conv(amount: float, currency: str = "USD"): return {"usd": to_usd(amount, currency)}
