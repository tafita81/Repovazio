
from fastapi import APIRouter, Body, Query, Depends, UploadFile, File
from sqlalchemy.orm import Session
from typing import List, Dict, Optional
import os, requests

from ...db import SessionLocal
from ...models import GlobalCredential
from ...services.mailer import send_via_provider

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def mask(v: str) -> str:
    if not v: return ""
    return ("*" * max(0, len(v)-4)) + v[-4:]

@router.get("/list")
async def list_credentials(service: Optional[str] = None, db: Session = Depends(get_db)):
    q = db.query(GlobalCredential)
    if service:
        q = q.filter(GlobalCredential.service==service)
    rows = q.all()
    return [{
        "id": r.id,
        "service": r.service,
        "key_name": r.key_name,
        "value_masked": mask(r.value or ""),
        "signup_url": r.signup_url,
        "docs_url": r.docs_url,
        "notes": r.notes
    } for r in rows]

@router.post("/set")
async def set_credential(payload: Dict = Body(...), db: Session = Depends(get_db)):
    svc = payload.get("service")
    key = payload.get("key_name")
    val = payload.get("value","")
    signup = payload.get("signup_url")
    docs = payload.get("docs_url")
    notes = payload.get("notes")
    if not svc or not key:
        return {"ok": False, "error": "invalid_payload"}
    row = db.query(GlobalCredential).filter(GlobalCredential.service==svc, GlobalCredential.key_name==key).first()
    if row:
        row.value = val
        row.signup_url = signup or row.signup_url
        row.docs_url = docs or row.docs_url
        row.notes = notes or row.notes
    else:
        row = GlobalCredential(service=svc, key_name=key, value=val, signup_url=signup, docs_url=docs, notes=notes)
        db.add(row)
    db.commit()
    return {"ok": True}

def credential(db: Session, service: str, key_name: str, default: Optional[str]=None) -> Optional[str]:
    r = db.query(GlobalCredential).filter(GlobalCredential.service==service, GlobalCredential.key_name==key_name).first()
    return (r.value if r else default)

# ---- TESTES ----

@router.post("/test/sendgrid")
async def test_sendgrid(to: str = Query(...), db: Session = Depends(get_db)):
    api_key_env = "SENDGRID_API_KEY"
    api_key = credential(db, "sendgrid", "api_key")
    from_email = credential(db, "sendgrid", "from_email", "noreply@example.com")
    from_name  = credential(db, "sendgrid", "from_name", "Broker AutoPilot")
    if not api_key:
        return {"ok": False, "error": "missing_sendgrid_api_key"}
    os.environ[api_key_env] = api_key  # injeta para mailer
    subject = "Teste de envio — AutoPilot"
    body = "Mensagem de teste enviada pelo AutoPilot (SendGrid API)."
    try:
        send_via_provider("sendgrid_api", {"sendgrid_api_key_env": api_key_env, "from_email": from_email, "from_name": from_name},
                          to, subject, body, {"rfq_id": "TESTE"}, attachments=[])
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}

@router.post("/test/searchapi")
async def test_searchapi(q: str = Query("partner program"), db: Session = Depends(get_db)):
    # Apenas verifica se a chave permite chamada básica
    key = credential(db, "searchapi", "api_key")
    if not key:
        return {"ok": False, "error": "missing_searchapi_key"}
    try:
        r = requests.get("https://www.searchapi.io/api/v1/search", params={"engine":"google","q":q,"api_key":key}, timeout=20)
        return {"ok": r.status_code in (200, 429, 403), "status": r.status_code}
    except Exception as e:
        return {"ok": False, "error": str(e)}

@router.get("/bootstrap_links")
async def bootstrap_links():
    return {
        "sendgrid": {
            "signup": "https://app.sendgrid.com/",
            "docs": "https://docs.sendgrid.com/for-developers/sending-email/quickstart",
            "steps": [
                "Crie uma API Key com permissão 'Mail Send'.",
                "Valide um remetente (Single Sender) ou autentique seu domínio.",
                "Cole a API Key e o from_email aqui e salve."
            ]
        },
        "searchapi": {
            "signup": "https://www.searchapi.io/",
            "docs": "https://www.searchapi.io/docs",
            "steps": [
                "Crie uma conta e gere sua API Key.",
                "Cole a API Key aqui e salve."
            ]
        },
        "indiamart": {
            "portal_seller": "https://seller.indiamart.com/",
            "portal_buyer": "https://my.indiamart.com/",
            "steps": [
                "Faça login no portal (seller/buyer).",
                "Se precisar de integração, use exportações CSV/Email-Parser ou contate o suporte IndiaMART; não há documentação pública de API completa."
            ]
        },
        "stripe": {
            "signup": "https://dashboard.stripe.com/register",
            "docs": "https://stripe.com/docs/keys",
            "steps": [
                "Crie a conta, ative o modo live.",
                "Copie a 'Secret Key' e cole aqui.",
                "Opcional: crie Webhook e cole a URL aqui."
            ]
        },
        "openai": {
            "signup": "https://platform.openai.com/",
            "docs": "https://platform.openai.com/docs/overview",
            "steps": [
                "Crie a conta e gere uma API Key.",
                "Cole a chave aqui para recursos de IA no app (opcional)."
            ]
        },
        "zapier": {
            "signup": "https://zapier.com/",
            "docs": "https://help.zapier.com/hc/en-us/articles/8496246102043-Trigger-a-Zap-from-a-webhook",
            "steps": [
                "Crie um Zap com trigger 'Catch Hook'.",
                "Copie a URL do Webhook e cole aqui para ingestão automática de RFQs."
            ]
        }
    }


@router.post("/upload_logo")
async def upload_logo(file: UploadFile = File(...), db: Session = Depends(get_db)):
    import os
    data_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "data")
    os.makedirs(data_dir, exist_ok=True)
    out_path = os.path.join(data_dir, "branding_logo.png")
    with open(out_path, "wb") as f:
        f.write(await file.read())
    # salva credencial apontando para logo
    row = db.query(GlobalCredential).filter(GlobalCredential.service=="branding", GlobalCredential.key_name=="logo_path").first()
    if not row:
        row = GlobalCredential(service="branding", key_name="logo_path", value=out_path)
        db.add(row)
    else:
        row.value = out_path
    db.commit()
    return {"ok": True, "logo_path": out_path}

@router.post("/branding/set")
async def branding_set(brand_name: str = Query(""), color_primary: str = Query("#111111"), color_secondary: str = Query("#555555"), db: Session = Depends(get_db)):
    def put(k, v):
        row = db.query(GlobalCredential).filter(GlobalCredential.service=="branding", GlobalCredential.key_name==k).first()
        if not row:
            row = GlobalCredential(service="branding", key_name=k, value=v)
            db.add(row)
        else:
            row.value = v
    put("brand_name", brand_name or "")
    put("color_primary", color_primary or "#111111")
    put("color_secondary", color_secondary or "#555555")
    db.commit()
    return {"ok": True}


@router.get("/webhook_url")
async def webhook_url():
    import json, os
    path = os.path.join(os.path.dirname(__file__), "..", "..", "autopilot_config.json")
    with open(path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    base = cfg.get("public_base_url") or "https://globalsupplements.site"
    token = cfg.get("webhook_token") or ""
    return {"url": f"{base}/api/webhooks/sendgrid?token={token}" }
