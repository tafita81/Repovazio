from fastapi import APIRouter, Depends, Body
from sqlalchemy.orm import Session
from ...db import SessionLocal
from ...models import GlobalCredential

router = APIRouter()

def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()

@router.get("/policy")
async def get_policy(db: Session = Depends(get_db)):
    def read(k, default=""):
        r = db.query(GlobalCredential).filter(GlobalCredential.service=="collector", GlobalCredential.key_name==k).first()
        return r.value if r else default
    return {
        "prefer_apis": read("prefer_apis","true")=="true",
        "allow_scraping": read("allow_scraping","true")=="true",
        "screenshot_on_scrape": read("screenshot_on_scrape","false")=="true"
    }

@router.post("/policy")
async def set_policy(payload: dict = Body(...), db: Session = Depends(get_db)):
    for k in ["prefer_apis","allow_scraping","screenshot_on_scrape"]:
        if k in payload:
            row = db.query(GlobalCredential).filter(GlobalCredential.service=="collector", GlobalCredential.key_name==k).first()
            v = "true" if bool(payload.get(k)) else "false"
            if row: row.value = v
            else: db.add(GlobalCredential(service="collector", key_name=k, value=v))
    db.commit(); return {"ok": True}
