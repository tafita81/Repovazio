
from fastapi import APIRouter, Query, Body
import os

BASE = os.path.join(os.path.dirname(__file__), "..", "..", "templates")
CUSTOM = os.path.join(BASE, "custom")
os.makedirs(CUSTOM, exist_ok=True)

router = APIRouter()

@router.get("/get")
async def get_template(type_key: str = Query(...), lang: str = Query("en")):
    path = os.path.join(CUSTOM, f"{type_key}_{lang}.txt")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return {"type": type_key, "lang": lang, "content": f.read(), "source": "custom"}
    # fallback default
    path = os.path.join(BASE, f"{type_key}_{lang}.txt")
    if not os.path.exists(path):
        path = os.path.join(BASE, f"{type_key}_en.txt")
    with open(path, "r", encoding="utf-8") as f:
        return {"type": type_key, "lang": lang, "content": f.read(), "source": "default"}

@router.post("/save")
async def save_template(type_key: str = Query(...), lang: str = Query("en"), body: dict = Body(...)):
    content = body.get("content","")
    path = os.path.join(CUSTOM, f"{type_key}_{lang}.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return {"ok": True, "type": type_key, "lang": lang}
