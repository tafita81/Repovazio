from fastapi import APIRouter, UploadFile, File, Depends
from sqlalchemy.orm import Session
from ...db import SessionLocal
from ...services.importer import import_suppliers_csv
from ...models import Supplier, SupplierConnection, GlobalCredential
from ...services.mailer import send_via_provider
import os

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/import/csv")
async def import_suppliers(file: UploadFile = File(...), evidence_min: float = 0.7, db: Session = Depends(get_db)):
    content = await file.read()
    res = import_suppliers_csv(db, content, evidence_min=evidence_min)
    return res


@router.get("/list")
async def list_suppliers(db: Session = Depends(get_db)):
    rows = db.query(Supplier).order_by(Supplier.name.asc()).all()
    return [{
        "id": r.id, "name": r.name, "country_region": r.country_region, "category": r.category,
        "program_type": r.program_type, "website": r.website, "program_url": r.program_url,
        "evidence": r.evidence, "evidence_score": r.evidence_score, "notes": r.notes
    } for r in rows]

@router.get("/connections")
async def list_connections(db: Session = Depends(get_db)):
    rows = db.query(SupplierConnection).all()
    return [{
        "id": r.id, "supplier_id": r.supplier_id, "supplier_name": r.supplier_name,
        "api_base_url": r.api_base_url, "api_key": r.api_key, "partner_signup_url": r.partner_signup_url,
        "developer_docs_url": r.developer_docs_url, "status": r.status, "notes": r.notes
    } for r in rows]

@router.post("/connect")
async def save_connection(payload: dict, db: Session = Depends(get_db)):
    supplier_id = int(payload.get("supplier_id"))
    s = db.query(Supplier).filter(Supplier.id==supplier_id).first()
    if not s:
        return {"ok": False, "error": "supplier_not_found"}
    c = SupplierConnection(
        supplier_id=supplier_id,
        supplier_name=s.name,
        api_base_url=payload.get("api_base_url",""),
        api_key=payload.get("api_key",""),
        partner_signup_url=payload.get("partner_signup_url",""),
        developer_docs_url=payload.get("developer_docs_url",""),
        status=payload.get("status","planned"),
        notes=payload.get("notes","")
    )
    db.add(c)
    db.commit()
    # Email de boas-vindas automático (interno)
    api_key = get_cred(db, 'sendgrid', 'api_key')
    ops_email = get_cred(db, 'sendgrid', 'ops_email', get_cred(db,'sendgrid','from_email'))
    from_email = get_cred(db, 'sendgrid', 'from_email', 'noreply@example.com')
    from_name  = get_cred(db, 'sendgrid', 'from_name', 'Broker AutoPilot')
    if api_key and ops_email:
        os.environ['SENDGRID_API_KEY'] = api_key
        subject = f"Nova conexão criada: {s.name}"
        body = ("Bem-vindo, uma nova conexão de fornecedor foi criada.\n"+
                f"Fornecedor: {s.name}\nPrograma: {s.program_type or ''}\nWebsite: {s.website or ''}\nPortal: {s.program_url or ''}\nStatus: {c.status}\nNotas: {c.notes or ''}")
        try:
            send_via_provider('sendgrid_api', {'sendgrid_api_key_env':'SENDGRID_API_KEY', 'from_email': from_email, 'from_name': from_name},
                              ops_email, subject, body, {})
        except Exception as e:
            pass
    return {"ok": True, "id": c.id}


@router.put("/connect/{conn_id}")
async def update_connection(conn_id: int, payload: dict, db: Session = Depends(get_db)):
    from ...models import SupplierConnection
    c = db.query(SupplierConnection).filter(SupplierConnection.id==conn_id).first()
    if not c:
        return {"ok": False, "error": "connection_not_found"}
    for k in ["api_base_url","api_key","partner_signup_url","developer_docs_url","status","notes","reveal_after","public_alias"]:
        if k in payload:
            setattr(c, k, payload[k])
    db.commit()
    return {"ok": True}


def get_cred(db, service, key, default=None):
    row = db.query(GlobalCredential).filter(GlobalCredential.service==service, GlobalCredential.key_name==key).first()
    return row.value if row else default
