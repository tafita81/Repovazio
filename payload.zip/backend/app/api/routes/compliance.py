
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from ...db import SessionLocal
from ...services.compliance import checklist_for
from ...models import RFQ

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/checklist")
async def checklist(destination: str = Query(...), category: str = Query(...)):
    return {"destination": destination, "category": category, "checklist": checklist_for(destination, category)}

@router.get("/by_rfq")
async def checklist_by_rfq(rfq_id: str = Query(...), db: Session = Depends(get_db)):
    r = db.query(RFQ).filter(RFQ.rfq_id==rfq_id).first()
    if not r:
        return {"ok": False, "error": "rfq_not_found"}
    return {"ok": True, "rfq_id": rfq_id, "checklist": checklist_for(r.destination_country or "", r.category or "")}
