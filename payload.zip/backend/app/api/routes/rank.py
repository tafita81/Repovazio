from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ...db import SessionLocal
from ...services.ranker import rank_by_value, rank_by_revenue

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/all/value")
async def rank_value(db: Session = Depends(get_db)):
    return rank_by_value(db)

@router.get("/all/revenue")
async def rank_revenue(db: Session = Depends(get_db)):
    return rank_by_revenue(db)
