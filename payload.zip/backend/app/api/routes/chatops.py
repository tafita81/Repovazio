
from fastapi import APIRouter
from ...services.autopilot import AP

router = APIRouter()

@router.get("/status")
async def status():
    return {"enabled": True, "log": AP.log[-50:]}

@router.post("/run-now")
async def run_now():
    AP.cycle()
    return {"ok": True}

@router.post("/toggle")
async def toggle(enable: bool = True):
    # This toggles via config file
    import json, os
    cfgp = os.path.join(os.path.dirname(__file__), "..", "..", "autopilot_config.json")
    with open(cfgp, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    cfg["enabled"] = bool(enable)
    with open(cfgp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    return {"enabled": cfg["enabled"]}
