from fastapi import APIRouter, Depends, Body
from sqlalchemy.orm import Session
from typing import Optional, Dict
from ...db import SessionLocal
from ...services.matcher import match_and_assign

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/assign")
async def assign_suppliers(max_suppliers: int = 5, policy: Optional[Dict] = Body(default=None), db: Session = Depends(get_db)):
    pol = policy or {}
    res = match_and_assign(db, policy=pol, max_suppliers=max_suppliers)
    return res
