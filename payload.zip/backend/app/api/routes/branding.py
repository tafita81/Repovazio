from fastapi import APIRouter, Body, Depends
from sqlalchemy.orm import Session
from ...db import SessionLocal
from ...services.branding import get_brand, set_brand

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/get")
async def brand_get(db: Session = Depends(get_db)):
    return get_brand(db)

@router.post("/set")
async def brand_set(payload: dict = Body(...), db: Session = Depends(get_db)):
    ok = set_brand(db, payload)
    return {"ok": ok}
