
from fastapi import APIRouter, Depends, Body, Query
from sqlalchemy.orm import Session
from ...db import SessionLocal
from ...models import GlobalCredential
from ...services.monitoring import ping, alert_email

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/list")
async def list_mon(db: Session = Depends(get_db)):
    rows = db.query(GlobalCredential).filter(GlobalCredential.service=="monitoring").all()
    return [{"key_name": r.key_name, "value_masked": ("*"*(len(r.value)-4)+r.value[-4:]) if r.value else "", "notes": r.notes} for r in rows]

@router.post("/set")
async def set_mon(payload: dict = Body(...), db: Session = Depends(get_db)):
    key = payload.get("key"); val = payload.get("value",""); notes = payload.get("notes")
    if not key: return {"ok": False, "error": "missing_key"}
    row = db.query(GlobalCredential).filter(GlobalCredential.service=="monitoring", GlobalCredential.key_name==key).first()
    if row:
        row.value = val; row.notes = notes or row.notes
    else:
        row = GlobalCredential(service="monitoring", key_name=key, value=val, notes=notes)
        db.add(row)
    db.commit()
    return {"ok": True}

@router.post("/test_ping")
async def test_ping(url: str = Query(...)):
    return {"ok": bool(ping(url))}

@router.post("/test_alert")
async def test_alert(db: Session = Depends(get_db)):
    ok = alert_email(db, "Test Alert — Broker AutoPilot", "This is a test alert from Monitoring.")
    return {"ok": ok}
