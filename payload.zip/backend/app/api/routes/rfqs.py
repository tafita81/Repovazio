from fastapi import APIRouter, UploadFile, File, Depends
from sqlalchemy.orm import Session
from ...db import SessionLocal
from ...services.importer import import_rfqs_csv

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/import/csv")
async def import_rfqs(file: UploadFile = File(...), db: Session = Depends(get_db)):
    content = await file.read()
    res = import_rfqs_csv(db, content)
    return res
