from fastapi import APIRouter, Query, Depends, Body
from sqlalchemy.orm import Session
from typing import Optional, List
from ...db import SessionLocal
from ...models import Supplier
from ...services.harvester_strict import harvest_global_strict
from ...services.utils import compute_evidence_score
from ...models import GlobalCredential
from pydantic import BaseModel

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class StrictHarvestBody(BaseModel):
    domains: Optional[List[str]] = None
    keywords: Optional[List[str]] = None

@router.post("/global/strict")
async def harvest_global_strict_api(
    target: int = Query(99, ge=10, le=1000),
    exclude_country: Optional[str] = Query("IN"),
    evidence_min: float = Query(0.6, ge=0.0, le=1.0),
    body: Optional[StrictHarvestBody] = Body(default=None),
    db: Session = Depends(get_db)
):
    api_key = None
    row = db.query(GlobalCredential).filter(GlobalCredential.service=='searchapi', GlobalCredential.key_name=='api_key').first()
    if row: api_key = row.value
    items = harvest_global_strict(target=target, exclude_country=exclude_country, evidence_min=evidence_min,
                                  domains_override=(body.domains if body else None),
                                  keywords=(body.keywords if body else None), api_key_override=api_key)
    added = 0
    for r in items:
        ev = r.get("evidence_score") or compute_evidence_score(r.get("website"), r.get("program_url"), r.get("evidence"), r.get("program_type"))
        if ev < evidence_min: 
            continue
        s = Supplier(
            name=r.get("name"),
            country_region=r.get("country_region"),
            category=r.get("category"),
            program_type=r.get("program_type"),
            website=r.get("website"),
            program_url=r.get("program_url"),
            evidence=r.get("evidence"),
            indiamart_experience=r.get("indiamart_experience","sem_evidencia_publica"),
            notes=r.get("notes"),
            evidence_score=ev
        )
        exists = db.query(Supplier).filter(Supplier.name==s.name, Supplier.website==s.website).first()
        if exists:
            continue
        db.add(s)
        added += 1
    db.commit()
    return {"harvested": len(items), "inserted": added}
