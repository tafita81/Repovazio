
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ...db import SessionLocal
from ...models import OutboundLog, EmailEvent

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/summary")
async def summary(db: Session = Depends(get_db)):
    rows = db.query(OutboundLog).all()
    total = len(rows)
    opened = sum(1 for r in rows if r.opened_at)
    clicked = sum(1 for r in rows if r.clicked_at)
    return {"sent": total, "opened": opened, "clicked": clicked, "open_rate": (opened/total if total else 0.0), "click_rate": (clicked/total if total else 0.0)}

@router.get("/recent_events")
async def recent_events(limit: int = 200, db: Session = Depends(get_db)):
    rows = db.query(EmailEvent).order_by(EmailEvent.id.desc()).limit(limit).all()
    return [{
        "rfq_id": r.rfq_id, "buyer_email": r.buyer_email, "event": r.event, "timestamp": r.timestamp
    } for r in rows]
