from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from ...db import SessionLocal
from ...models import RFQ

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/top_by_value")
async def top_by_value(limit: int = Query(100, ge=1, le=1000), db: Session = Depends(get_db)):
    rows = db.query(RFQ).order_by(RFQ.ticket_val_usd.desc()).limit(limit).all()
    return [{
        "rfq_id": r.rfq_id, "buyer_company": r.buyer_company, "buyer_country": r.buyer_country,
        "category": r.category, "ticket_val_usd": float(r.ticket_val_usd or 0.0),
        "lead_time_required_days": r.lead_time_required_days, "incoterm": r.incoterm, "created_ts": r.created_ts
    } for r in rows]
