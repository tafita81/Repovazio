
from fastapi import APIRouter, Depends, Query, Response
from sqlalchemy.orm import Session
import os
from ...db import SessionLocal
from ...services.pdf import render_quote_pdf

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/quote.pdf")
async def quote_pdf(rfq_id: str = Query(...), db: Session = Depends(get_db)):
    out = f"/tmp/quote_{rfq_id}.pdf"
    path = render_quote_pdf(db, rfq_id, out, top_k=2)
    with open(path, "rb") as f:
        data = f.read()
    return Response(content=data, media_type="application/pdf", headers={
        "Content-Disposition": f"attachment; filename=quote_{rfq_id}.pdf"
    })


@router.get("/quote_buyer_safe.pdf")
async def quote_buyer_safe_pdf(rfq_id: str, db: Session = Depends(get_db)):
    out = f"/tmp/quote_bsafe_{rfq_id}.pdf"
    path = render_quote_pdf(db, rfq_id, out, top_k=2, buyer_safe=True, brand="Rafael Roberto Rodrigues de Oliveira Consultoria em Tecnologia da Informação Corp")
    with open(path, "rb") as f:
        data = f.read()
    return Response(content=data, media_type="application/pdf", headers={"Content-Disposition": f"attachment; filename=quote_buyer_safe_{rfq_id}.pdf"})

# NCNDA simple generator
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from datetime import datetime

@router.get("/ncnda.pdf")
async def ncnda_pdf(buyer_company: str = "Comprador", buyer_contact: str = "Contato", db: Session = Depends(get_db)):
    out = "/tmp/ncnda.pdf"
    c = canvas.Canvas(out, pagesize=A4)
    W,H = A4; y = H - 20*mm
    def line(t, fs=12):
        nonlocal y; c.setFont("Helvetica", fs); c.drawString(20*mm, y, t); y -= (fs+4)
    line("Rafael Roberto Rodrigues de Oliveira Consultoria em Tecnologia da Informação Corp", 16)
    line("NCNDA — Non-Circumvention, Non-Disclosure & Non-Compete", 14)
    line("Partes:")
    line(f"  - Broker: Rafael Roberto Rodrigues de Oliveira Consultoria em Tecnologia da Informação Corp")
    line(f"  - Comprador: " + buyer_company)
    y -= 6
    line("Cláusulas principais:")
    line("1) Não circumvenção: o Comprador não contata fornecedores apresentados sem anuência do Broker por 24 meses.")
    line("2) Confidencialidade: listas de fornecedores, condições comerciais e preços são confidenciais.")
    line("3) Remuneração: em toda compra decorrente das apresentações, o Broker é remunerado conforme proposta.")
    line("4) Foro e lei aplicável: a definir no fechamento.")
    y -= 12
    line("Assinaturas:", 14)
    y -= 10
    line("____________________________   ____________________________")
    line("Broker (assinatura)           Comprador (assinatura)")
    y -= 20
    line("Data: " + datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"))
    c.showPage(); c.save()
    with open(out, "rb") as f:
        data = f.read()
    return Response(content=data, media_type="application/pdf", headers={"Content-Disposition": "attachment; filename=ncnda.pdf"})
