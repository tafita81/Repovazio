from fastapi import APIRouter, Body, Depends, Query
from sqlalchemy.orm import Session
import json, re
from ...db import SessionLocal
from ...models import ScraperBlueprint
from ...services.scraper_engine import run_blueprint

router = APIRouter()

def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()

def slugify(s:str)->str:
    import re; return re.sub(r'[^a-z0-9]+','-', s.strip().lower()).strip('-')

@router.get("/list")
async def list_bps(db: Session = Depends(get_db)):
    rows = db.query(ScraperBlueprint).order_by(ScraperBlueprint.enabled.desc(), ScraperBlueprint.name.asc()).all()
    out = []
    for r in rows:
        out.append({"slug": r.slug, "name": r.name, "domain": r.domain, "method": r.method, "enabled": r.enabled,
                    "last_run_ts": r.last_run_ts, "last_ok": r.last_ok, "last_msg": r.last_msg, "config": json.loads(r.config_json or "{}")})
    return out

@router.post("/upsert")
async def upsert_bp(payload: dict = Body(...), db: Session = Depends(get_db)):
    name = payload.get("name"); domain=payload.get("domain"); method=payload.get("method","http")
    if not name or not domain: return {"ok": False, "error": "missing_fields"}
    slug = payload.get("slug") or slugify(name)
    r = db.query(ScraperBlueprint).filter(ScraperBlueprint.slug==slug).first()
    cfg = payload.get("config") or {}
    if r: r.name=name; r.domain=domain; r.method=method; r.config_json=json.dumps(cfg)
    else:
        r = ScraperBlueprint(slug=slug, name=name, domain=domain, method=method, config_json=json.dumps(cfg), enabled=bool(payload.get("enabled", False)))
        db.add(r)
    db.commit(); return {"ok": True, "slug": slug}

@router.post("/toggle")
async def toggle_bp(slug: str = Query(...), enabled: bool = Query(True), db: Session = Depends(get_db)):
    r = db.query(ScraperBlueprint).filter(ScraperBlueprint.slug==slug).first()
    if not r: return {"ok": False, "error": "not_found"}
    r.enabled=bool(enabled); db.commit(); return {"ok": True}

@router.post("/run")
async def run(slug: str = Query(...), dry_run: bool = Query(True), limit: int = Query(25), db: Session = Depends(get_db)):
    r = db.query(ScraperBlueprint).filter(ScraperBlueprint.slug==slug).first()
    if not r: return {"ok": False, "error": "not_found"}
    return run_blueprint(db, r, dry_run=dry_run, limit=limit)
