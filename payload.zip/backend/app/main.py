from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from .db import Base, engine
from .api.routes.branding import router as branding_router
from .api.routes.collector import router as collector_router
from .api.routes.scrapers import router as scrapers_router
from .api.routes.metrics import router as metrics_router
from .api.routes.fx import router as fx_router
from .api.routes.rfq_reports import router as rfq_reports_router
from .api.routes.suppliers import router as suppliers_router
from .api.routes.rfqs import router as rfqs_router
from .api.routes.harvest_strict import router as harvest_router
from .api.routes.match import router as match_router
from .api.routes.rank import router as rank_router
from .api.routes.exports import router as export_router
from .api.routes.compliance import router as compliance_router
from .api.routes.docs import router as docs_router
from .api.routes.chatops import router as chatops_router
from .api.routes.settings import router as settings_router
from .api.routes.templates import router as templates_router
from .api.routes.webhooks import router as webhooks_router
from .api.routes.email_reports import router as email_reports_router
from .api.routes.monitoring import router as monitoring_router
from .api.routes.lead_sources import router as lead_sources_router

Base.metadata.create_all(bind=engine)
from .services.autopilot import AP

from sqlalchemy.orm import Session
from .db import SessionLocal
from .services.importer import import_suppliers_csv
import os

@app.on_event("startup")
def startup_load_suppliers():
    db = SessionLocal()
    try:
        # Se não houver fornecedores, importe CSVs padrão
        count = db.execute("SELECT COUNT(*) FROM suppliers").scalar() if db.bind else 0
        if not count:
            for fname in ["fornecedores_unificado_master_v6_global.csv","fornecedores_anexo.csv"]:
                fpath = os.path.join(os.path.dirname(__file__), "..", "data", fname)
                if os.path.exists(fpath):
                    with open(fpath, "rb") as f:
                        import_suppliers_csv(db, f.read(), evidence_min=0.7)
    finally:
        db.close()


app = FastAPI(title="Brokerage App", version="1.0.0")
app.include_router(suppliers_router, prefix="/api/suppliers", tags=["suppliers"])
app.include_router(rfqs_router, prefix="/api/rfqs", tags=["rfqs"])
app.include_router(harvest_router, prefix="/api/harvest", tags=["harvest"])
app.include_router(match_router, prefix="/api/match", tags=["match"])
app.include_router(rank_router, prefix="/api/rank", tags=["rank"])
app.include_router(export_router, prefix="/api/exports", tags=["exports"])
app.include_router(compliance_router, prefix="/api/compliance", tags=["compliance"])
app.include_router(docs_router, prefix="/api/docs", tags=["docs"])
app.include_router(chatops_router, prefix="/api/autopilot", tags=["autopilot"])
app.include_router(settings_router, prefix="/api/settings", tags=["settings"])
app.include_router(templates_router, prefix="/api/email_templates", tags=["email_templates"])
app.include_router(webhooks_router, prefix="/api/webhooks", tags=["webhooks"])
app.include_router(email_reports_router, prefix="/api/email_reports", tags=["email_reports"])
app.include_router(monitoring_router, prefix="/api/monitoring", tags=["monitoring"])
app.include_router(lead_sources_router, prefix="/api/lead_sources", tags=["lead_sources"])
app.mount("/frontend", StaticFiles(directory="../frontend/static_admin"), name="frontend")


@app.on_event("startup")
def startup_autopilot():
    try:
        AP.start()
    except Exception as e:
        print("AutoPilot não iniciou:", e)

app.include_router(rfq_reports_router, prefix="/api/rfqs", tags=["rfq_reports"])

app.include_router(fx_router, prefix="/api/fx", tags=["fx"])

app.include_router(metrics_router, prefix="/api/metrics", tags=["metrics"])

app.include_router(scrapers_router, prefix="/api/scrapers", tags=["scrapers"])

app.include_router(collector_router, prefix="/api/collector", tags=["collector"])

app.include_router(branding_router, prefix="/api/branding", tags=["branding"])
