#!/usr/bin/env bash
set -euo pipefail
pip install -r backend/requirements.txt
export PYTHONPATH=backend
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
