# Brokerage App — v1

## Rodando local
```bash
cd backend
bash run.sh
# API em http://localhost:8000  | Admin: http://localhost:8000/frontend
```

## Endpoints
- POST `/api/suppliers/import/csv?evidence_min=0.7`
- POST `/api/rfqs/import/csv`
- POST `/api/match/assign?max_suppliers=5`
- GET  `/api/rank/all/value`
- GET  `/api/rank/all/revenue`
- GET  `/api/exports/rfq_assignments.csv`
- POST `/api/harvest/global/strict?target=250&evidence_min=0.7`

## SendGrid (API) — Configuração
1. Crie uma API Key no SendGrid com permissão **Mail Send**.
2. Verifique um **Single Sender** ou **Domain Authentication**.
3. Exporte a variável de ambiente antes de iniciar a API:
   ```bash
   export SENDGRID_API_KEY="*** SUA_CHAVE_AQUI ***"
   ```
4. Ajuste `autopilot_config.json` se quiser trocar o `from_email`/`from_name`.


## Webhook SendGrid (produção)
Cole no painel do SendGrid → Event Webhook:
```
https://globalsupplements.site/api/webhooks/sendgrid?token=m9NKfz53SAPa7AYTbM1m80KLQ4XF-qz7
```

Mantenha o token em segredo. Eventos aceitos: delivered, open, click, bounce.


## Scraping (Sem API)
- **Respeite o robots.txt e os Termos de Uso** de cada site.
- Use **APIs oficiais** quando disponíveis; o módulo de scraping é um fallback.
- O engine usa **requests + BeautifulSoup** (modo http). Alguns sites requerem JS — neste caso, habilite um conector **browser** (Playwright) no Dockerfile e atualize `method` para `browser`.
