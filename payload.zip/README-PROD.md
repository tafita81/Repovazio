# GlobalSupplements Broker — **PRODUÇÃO** (globalsupplements.site)

Este repositório publica o **globalsupplements-broker** com tudo automático: *Preferir APIs + Fallback Scraping*, Painel Gerencial em tempo real e **one-shot bootstrap** (branding + i18n + coleta + auditoria + 1º ciclo do AutoPilot).

---

## ✅ Pré‑requisitos de Produção
- **SendGrid API Key** (obrigatório) — envios de propostas e follow‑ups.
- **SECRET_KEY** (obrigatório) — gere com `openssl rand -hex 32`.
- (Opcional) **OPENAI_API_KEY**, **HC_PING_URL**, **HC_FAIL_URL**.
- **Marca** já definida: **globalsupplements.site** e `contact@globalsupplements.site` (padrão do projeto).

### `.env.production` (modelo)
Use `env/.env.production.example` e preencha:
```
SENDGRID_API_KEY=...
PUBLIC_BASE_URL=https://globalsupplements-broker.fly.dev
SECRET_KEY=...
OPENAI_API_KEY=...
TIMEZONE=America/Sao_Paulo
BRAND_NAME=Global Supplements
BRAND_DOMAIN=globalsupplements.site
BRAND_FROM_EMAIL=contact@globalsupplements.site
BRAND_FROM_NAME=Global Supplements — RFQ Desk
DEFAULT_LANG=en
SUPPORTED_LANGS=en,pt,es,fr,de,it,ja,ko,zh_cn,zh_tw,ar,ru,hi,tr
```

---

## 🚀 Deploy na **Render** (com preDeploy automático)
1. Faça push deste repo para o GitHub (ou use o script `scripts/github_new_repo_push.sh`).  
2. Na Render, crie **Web Service (Docker)** apontando para `backend/` (runtime Docker).  
   - **autoDeploy: ON**  
   - **Health Check Path**: `/api/healthz`  
   - O `render.yaml` já contém:  
     ```yaml
     preDeployCommand: bash /app/scripts/render_predeploy.sh
     ```
3. Em **Environment**, cole as variáveis de produção do `.env.production`.  
4. A cada deploy, o **preDeploy** executa `python /app/scripts/one_shot_bootstrap.py` para:
   - Gravar **Branding & Idiomas**,
   - Ligar **Preferir APIs** + **Fallback Scraping**,
   - Coletar RFQs (APIs + Scrapers),
   - Auditar estratégia e rodar **1º ciclo do AutoPilot**.  
5. Admin: **https://<seu-servico>.onrender.com/admin**

### Deploy Hook (opcional) + One‑Off Job
- Configure os **Secrets** no GitHub: `RENDER_DEPLOY_HOOK_URL`, `RENDER_API_KEY`, `RENDER_SERVICE_ID`.  
- Rode a Action **Deploy (Render) + One‑Shot (Hook)** nas *Actions* do GitHub.

---

## 🚀 Deploy no **Fly.io** (alternativo)
1. `fly auth login`
2. Crie app e volume:
```
fly apps create globalsupplements-broker
fly volumes create data --region gru --size 1
```
3. Secrets de produção:
```
fly secrets set   SENDGRID_API_KEY=...   PUBLIC_BASE_URL=https://globalsupplements-broker.fly.dev   SECRET_KEY=$(openssl rand -hex 32)   OPENAI_API_KEY=...   TIMEZONE=America/Sao_Paulo
```
4. Deploy: `fly deploy`  
5. Bootstrap: `fly ssh console -C "python /app/scripts/one_shot_bootstrap.py"`  
6. Admin: **https://globalsupplements-broker.fly.dev/admin**

---

## 📬 **Configurar remetente no SendGrid** (credibilidade + entregabilidade)
1. **Autentique o domínio** `globalsupplements.site` no SendGrid (Domain Authentication).  
2. **SPF**: adicione **TXT** em **@** com valor genérico (exemplo): `v=spf1 include:sendgrid.net ~all`.  
3. **DKIM**: o SendGrid fornece **CNAMEs** (ex.: `s1._domainkey` e `s2._domainkey`) → copie exatamente os valores mostrados no painel.  
4. **Reverse DNS / Tracking** (opcional): o SendGrid pode sugerir CNAME adicional para *click tracking*.  
5. **Single Sender/From**: confirme `contact@globalsupplements.site` como remetente.  
> As entradas DNS variam por conta; siga exatamente as **instruções do SendGrid** exibidas para o seu domínio.

---

## 🌐 **Domínio customizado** (CNAME + SSL)
- **Render**: aponte um **CNAME** (ex.: `app.globalsupplements.site`) para o host do serviço na Render; ative **TLS/SSL** gerenciado.  
- **Fly.io**: adicione o domínio no app (`fly cert create app.globalsupplements.site`) e crie **CNAME** para o endpoint Fly; aguarde o certificado **Let’s Encrypt**.  
- Atualize `PUBLIC_BASE_URL` conforme o domínio final (ex.: `https://app.globalsupplements.site`).

---

## 📊 Operação
- **/admin → Painel Gerencial**: KPIs (RFQs, ticket médio/máx/soma, e-mails, open/click), Top Categorias/Países, buckets de ticket.  
- **Top RFQs (USD)**: lista por maior valor (sem corte mínimo).  
- **Ranking de Fornecedores**: receita estimada por fornecedor, filtrável.  
- **Compradores & Credenciais**: cole APIs; crie Blueprints de Scraping quando não existir API (respeite `robots.txt` e ToS).  
- **AutoPilot**: gera 3 opções (A/B/C), define Incoterms, prazos, garantia e follow‑ups.

---

## 🔐 Segurança & Compliance
- **Nunca** commitar chaves; use **Secrets/Env Vars**.  
- **Scraping responsável**: habilite apenas onde permitido (verifique `robots.txt`/ToS).  
- **E‑mail**: valide SPF/DKIM e monitore bounces no SendGrid.  
- **Logs & Saúde**: `/api/healthz` e (opcional) `HC_PING_URL/HC_FAIL_URL` para healthchecks externos.

---

## 🧰 Troubleshooting rápido
- **Playwright/Chromium**: já no Dockerfile; se faltar lib, redeploy limpa resolve.  
- **Open rate baixo**: valide domínio no SendGrid, teste assunto e aquecimento de IP/volume.  
- **RFQs vazios**: confirme APIs ativas e Blueprints habilitados; verifique `last_msg` de cada blueprint.  
- **USD=0**: force atualização de câmbio: `POST /api/fx/refresh`.

---

## 🔁 Atualizações e Actions
- **Fly**: `Deploy & Bootstrap (Fly.io)`  
- **Render**: `Deploy (Render) + One‑Shot (Hook)`  
- **PreDeploy** no Render já liga tudo automaticamente.

---

## ✅ Checklist Final de Go‑Live
- [ ] Secrets/Env definidos (SendGrid, SECRET_KEY, etc.)  
- [ ] `preDeployCommand` ativo na Render  
- [ ] SPF/DKIM publicados e verificados para `globalsupplements.site`  
- [ ] AutoPilot ligado (3 opções A/B/C)  
- [ ] APIs coladas; Blueprints ativos onde não há API  
- [ ] Painel Gerencial sem erros e e‑mails entregando

Pronto. **globalsupplements-broker** em produção, com coleta e negociação automatizadas.
