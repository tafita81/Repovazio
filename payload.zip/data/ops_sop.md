
# SOP — Operação de Brokerage (Produção)

## A. Captação de RFQs (somente dados reais)
- Fonte primária: **IndiaMART API/export** (quando disponível).  
- Fallback legal: **inbox RFQ**, **planilhas** do cliente, ou **integração Zapier/Email Parser**.  
- **Jamais crie RFQ fictício**. Use `rfq_import_template.csv` para ingestão em lote.

## B. Ingestão e Validação
1. Importar CSV via `POST /api/rfqs/import/csv` (ou via painel).  
2. Validar campos críticos: `category`, `quantity`, `destination_country`, `deadline_date`, `incoterm`.  
3. Enriquecer com meta: `market_hotness`, `urgency`, `cert_ready`, `payment_security`.

## C. Matching automático (até 5 fornecedores por RFQ)
- Política: `assign_suppliers_policy.json`.  
- Filtro duro: `evidence_score ≥ 0,7` e `program_type ∈ {dropshipping,reseller,partner,affiliate,distributor}`.  
- Preferência: **categoria**, **proximidade regional**, **program_fit** e **overseas warehouse** quando houver.

## D. Ranking e Seleção
- Para cada RFQ, calcular `MATCH_SCORE` e escolher **top-5**.  
- Exibir `ticket_val` e `BROKER_REVENUE` estimado por opção.  
- Caso nenhum fornecedor atenda, gerar **tarefa de sourcing** (global harvester) p/ aquela categoria/região.

## E. Comercial & Fechamento
- Propostas duplas (OEM A + OEM B) com Incoterms, prazos, garantia e instalação.  
- Cobrar **30–50% de depósito**. Adicionar **cláusula de substituição equivalente**.  
- Compliance: anexar **CE/UL/INMETRO** conforme destino; **NCM/HS Code** e **MSDS** se aplicável.

## F. Logística & Pós-venda
- Selecionar termo padrão: **DAP** para equipamentos e **DDP** para consumo/DS.  
- Tracking, notas fiscais e documentação aduaneira.  
- RMA/Warranty: tratar sempre via OEM/distribuidor oficial.

## G. Auditoria e Anti-risco
- Registro de evidências (URLs) por proposta.  
- Checagem de sanções/embargos para destino (ex.: OFAC/EU).  
- Logs de decisão e trilha por RFQ (LGPD/GDPR).

## H. KPIs
- Taxa de conversão por categoria/fornecedor.  
- Ticket médio, **margem do broker**, lead time médio, NPS comprador.

