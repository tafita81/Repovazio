
# Ranking de RFQs e Fornecedores (Ticket e Receita do Broker)

## 1) Score do RFQ (priorização)
```
RFQ_SCORE = norm(ticket_val) * 0.5
           + norm(urgency) * 0.2
           + norm(market_hotness) * 0.15
           + norm(cert_ready) * 0.1
           + norm(payment_security) * 0.05
```
- **ticket_val**: estimativa de valor do pedido (US$).  
- **urgency**: 1–5 (1=baixa, 5=urgente).  
- **market_hotness**: mapeado pela categoria (EV/BESS/Heat Pump/Robótica > demais).  
- **cert_ready**: exigência/registros disponíveis (CE/UL/INMETRO/KC etc.).  
- **payment_security**: (Antecipado/Depósito/LC/PO governamental).

## 2) Score de compatibilidade fornecedor↔RFQ
```
MATCH_SCORE = 0.35*category_match + 0.20*region_proximity + 0.20*program_fit
            + 0.15*evidence_score + 0.05*lead_time_signal + 0.05*historical_success
```
- **category_match**: 0–1 por palavras-chave (mapa no `assign_suppliers_policy.json`).  
- **region_proximity**: 0–1 (mesma região/continente/overseas warehouse).  
- **program_fit**: 1 se o fornecedor suporta o modelo (dropship/reseller/partner) pedido.  
- **evidence_score**: da base de fornecedores (≥ 0,7 exigido).  
- **lead_time_signal**: 1 se há “overseas warehouse / pronta-entrega / SLA”.  
- **historical_success**: reservado p/ métricas futuras.

## 3) Receita estimada do broker
```
BROKER_REVENUE = max(commission_flat, ticket_val * commission_pct, integrator_margin)
```
- **commission_flat**: quando afiliado/fee fixo.  
- **commission_pct**: quando reseller/canal (faixa 3%–18%).  
- **integrator_margin**: quando projeto/instalação (escopo/serviços).

## 4) Ordenação final por oportunidade
1. Ordene RFQs por **RFQ_SCORE** (desc).  
2. Para cada RFQ, calcule **MATCH_SCORE** por fornecedor elegível, ordene e **seleciona até 5**.  
3. Mostre **BROKER_REVENUE** estimado e **ticket_val** por opção, favorecendo maior receita.
