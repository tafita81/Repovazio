
#!/usr/bin/env bash
set -euo pipefail

: "${API_BASE:=http://localhost:8000}"
: "${EVIDENCE_MIN:=0.7}"

echo ">> 1) Importar fornecedores (versão v6 global) — já com 214+ únicos"
curl -s -F "file=@/mnt/data/fornecedores_unificado_master_v6_global.csv" \
  "${API_BASE}/api/suppliers/import/csv?evidence_min=${EVIDENCE_MIN}" | tee import_suppliers_v6.log

echo ">> 2) Importar 100+ RFQs reais (preencha rfq_import_template.csv com dados reais)"
curl -s -F "file=@/mnt/data/rfq_pipeline_assets/rfq_import_template.csv" \
  "${API_BASE}/api/rfqs/import/csv" | tee import_rfqs.log

echo ">> 3) Matching automático: até 5 fornecedores por RFQ"
curl -s -X POST -H "Content-Type: application/json" \
  --data @"./assign_suppliers_policy.json" \
  "${API_BASE}/api/match/assign?max_suppliers=5" | tee match_assign.log

echo ">> 4) Ranking por ticket (valor)"
curl -s "${API_BASE}/api/rank/all/value" | tee rank_value.log

echo ">> 5) Ranking por receita estimada do broker"
curl -s "${API_BASE}/api/rank/all/revenue" | tee rank_revenue.log

echo ">> 6) Exportar atribuições (CSV)"
curl -s "${API_BASE}/api/exports/rfq_assignments.csv" -o /mnt/data/rfq_pipeline_assets/rfq_assignments_empty.csv
echo "Arquivos gerados em /mnt/data/rfq_pipeline_assets"
