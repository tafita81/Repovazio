#!/usr/bin/env bash
set -euo pipefail
APP_NAME="${1:-globalsupplements-broker}"

echo ">> Criando app $APP_NAME (ajuste para um nome único se der conflito)"
fly apps create "$APP_NAME" || true

echo ">> Criando volume 'data' na região GRU"
fly volumes create data --region gru --size 1 || true

echo ">> Lembre de setar suas secrets após rodar este script, ex.:"
echo "fly secrets set SENDGRID_API_KEY=... PUBLIC_BASE_URL=https://globalsupplements-broker.fly.dev SECRET_KEY=$(openssl rand -hex 32)"
echo ">> Agora rode: fly deploy"
