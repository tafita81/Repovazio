#!/usr/bin/env bash
set -euo pipefail

# === CONFIG ===
: "${API_BASE:=http://localhost:8000}"
: "${EVIDENCE_MIN:=0.7}"
: "${TARGET:=350}"          # alvo alto para garantir 188+ únicos após dedupe
: "${CSV:=/mnt/data/fornecedores_unificado_master_v2.csv}"
: "${JOBS_ZIP:=/mnt/data/strict_batches_jobs.zip}"

echo ">> Verificando SEARCHAPI_IO_KEY..."
if [ -z "${SEARCHAPI_IO_KEY:-}" ]; then
  echo "ERRO: Defina SEARCHAPI_IO_KEY antes de rodar. Ex.: export SEARCHAPI_IO_KEY=SEU_TOKEN"
  exit 1
fi

echo ">> Importando planilha master com validação (evidence_min=$EVIDENCE_MIN)"
curl -s -F "file=@${CSV}" "${API_BASE}/api/suppliers/import/csv?evidence_min=${EVIDENCE_MIN}" | tee import_master.log

echo ">> Preparando lotes estritos (Lasers -> Cryogenia -> Óptica -> EV/BESS -> Robótica)"
mkdir -p /mnt/data/jobs && unzip -o "${JOBS_ZIP}" -d /mnt/data/jobs >/dev/null
cd /mnt/data/jobs

# Ajusta a base da API dentro do script de lotes
sed -i.bak "s|http://localhost:8000|${API_BASE}|g" run_batches.sh
chmod +x run_batches.sh

echo ">> Disparando lotes com evidence_min=${EVIDENCE_MIN}"
./run_batches.sh

echo ">> Concluído. Verifique os arquivos *.log em /mnt/data/jobs e a tabela suppliers."
