# GlobalSupplements Broker — v23 (API-first, Scraping Fallback)

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=<YOUR_GITHUB_REPO_URL>)

> App completo para captar RFQs (prioriza **APIs**; fallback **scraping/Playwright**), casar com até 5 fornecedores, gerar **propostas A/B/C**, enviar e-mails (SendGrid), e acompanhar tudo no **Painel Gerencial (tempo real)**.

## Estrutura
- `backend/` — FastAPI + SQLAlchemy + SendGrid + Playwright (Dockerfile incluso).
- `frontend/` — Admin estático embutido.
- `render.yaml` — Deploy 1-clique no Render (plano gratuito).

## Deploy (Render)
1. **Fork/Upload** este repositório no seu GitHub.
2. Clique no botão **Deploy to Render** acima (substitua `<YOUR_GITHUB_REPO_URL>` pela URL HTTPS deste repo após publicar).
3. No Render:
   - Root Directory: `backend`
   - Service env: **Docker**
   - Instance: **Free** (para testes)
   - Defina **Env Vars**:
     - `SENDGRID_API_KEY` — sua chave
     - `PUBLIC_BASE_URL` — URL do app (ex.: `https://globalsupplements.site` ou do Render)
     - `HC_PING_URL`, `HC_FAIL_URL` — (opcional) Healthchecks
     - `OPENAI_API_KEY` — (opcional) se usar geração de conteúdo
4. Acesse `/admin` e configure:
   - **Credenciais & APIs**, **Compradores & RFQ Sources**
   - **Coleta — Preferir APIs / Fallback Scraping**
   - **Monitoring & Alerts**
   - **AutoPilot**

## Deploy (Fly.io) — opcional
- Gere um `fly.toml` e rode:
```bash
fly launch --dockerfile backend/Dockerfile --name globalsupplements-broker
fly secrets set SENDGRID_API_KEY=... PUBLIC_BASE_URL=https://globalsupplements-broker.fly.dev
fly deploy
```

## Notas de scraping
- Respeite **robots.txt** e os **Termos de Uso**. Prefira **APIs oficiais**.
- `backend/app/services/scraper_engine.py` (HTTP) e `scraper_browser.py` (Playwright) com **screenshots** opcionais em `app/data/scraper_shots/`.

Boa sorte e boas vendas! 🚀


## Branding & Seed
- Ajuste `env/.env.example.<lang>` e crie o `.env` real no seu ambiente com **BRAND_NAME**, **BRAND_DOMAIN**, **BRAND_FROM_EMAIL**, etc.
- Rode o seed para gravar no banco:
```bash
# dentro do contêiner backend
python /app/scripts/seed_branding.py
```
- API: 
  - `GET /api/branding/get` — lê branding atual
  - `POST /api/branding/set` — atualiza branding (JSON)

Idiomas suportados por padrão: `en,pt,es,fr,de,it,ja,ko,zh_cn,zh_tw,ar,ru,hi,tr`.
