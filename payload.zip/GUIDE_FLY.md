# Fly.io — Guia
1) `fly auth login`
2) `fly apps create globalsupplements-broker` e `fly volumes create data --region gru --size 1`
3) Secrets: `fly secrets set SENDGRID_API_KEY=... PUBLIC_BASE_URL=https://globalsupplements-broker.fly.dev SECRET_KEY=$(openssl rand -hex 32)`
4) `fly deploy`
5) `fly ssh console -C "python /app/scripts/one_shot_bootstrap.py"`
