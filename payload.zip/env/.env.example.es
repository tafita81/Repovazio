# Copia a .env — NO COMPARTAS tus claves reales (Español)
SENDGRID_API_KEY=
PUBLIC_BASE_URL=https://globalsupplements-broker.fly.dev
SECRET_KEY= # gere com: openssl rand -hex 32
OPENAI_API_KEY=
HC_PING_URL=
HC_FAIL_URL=
TIMEZONE=America/Mexico_City
# Marca/Empresa
BRAND_NAME=Global Supplements
BRAND_DOMAIN=globalsupplements.site
BRAND_FROM_EMAIL=contact@globalsupplements.site
BRAND_FROM_NAME=Global Supplements — RFQ Desk
BRAND_LOGO_URL=
DEFAULT_LANG=en
SUPPORTED_LANGS=en,pt,es,fr,de,it,ja,ko,zh_cn,zh_tw,ar,ru,hi,tr
