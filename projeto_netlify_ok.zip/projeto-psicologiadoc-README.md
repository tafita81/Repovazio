# PSICOLOGIA.DOC — Projeto Completo
## Canal @psicologiadoc · Sistema Autônomo 24/7

### IDENTIDADE
- **Canal:** psicologia.doc (@psicologiadoc)
- **DOC** = Daniela Oliveira Coelho + Documentário
- **Slogan:** "A psicologia que você vive — documentada."
- **2026:** Canal 100% anônimo — ZERO menção a nome ou pessoa
- **2027 (após botão):** Daniela Coelho, psicóloga (NÃO "Dra.")

### DATAS CRÍTICAS
- **Dia 1 = 15 abril 2026**
- **Dia 261 = ~1 jan 2027** → Botão de Revelação disponível
- **630 dias total** (abr 2026 → dez 2027)

### FASES
| Fase | Dias | Período | Meta |
|------|------|---------|------|
| 1: SEO | 1-14 | 15-28 abr 2026 | 1.000 inscritos |
| 2: Viral | 15-30 | 29 abr-14 mai 2026 | 5.000 + viral |
| 3: Escala | 31-60 | 15 mai-13 jun 2026 | 10K + AdSense |
| 4: Crescimento | 61-180 | 14 jun-11 out 2026 | 50K + R$10-40K/mês |
| 5: Autoridade | 181-260 | 12 out-31 dez 2026 | 100K+ + WA cheio |
| 6: Pré-revelação | 261+ | jan 2027+ | 200K+ lista de espera |
| 7: Revelação | 261+ (botão) | jan 2027+ | Consultas abertas |

### ARQUIVOS
- `cerebrodani-prod-v7.jsx` — Sistema completo ATUAL (usar este)
- `cerebrodani-prod-v6.jsx` — Versão anterior (referência)

### TECNOLOGIAS
- Claude API (Anthropic) — geração de roteiros
- ElevenLabs — narração cinematic PT-BR
- HeyGen — avatar cinematográfico
- YouTube Data API v3 — publicação automática
- Instagram Meta Graph API — publicação automática
- TikTok Content Posting API — publicação automática
- Pinterest API v5 — publicação automática

### MONETIZAÇÃO (CRP-compliant)
1. YouTube AdSense — R$7-25/1K views
2. Afiliados Zenklub/Vittude — R$30-80/cadastro (dia 1)
3. WhatsApp Premium — R$29-97/mês/membro
4. YouTube Memberships — R$9,90-49/mês
5. Afiliados Livros Amazon — 4-8%
6. Patrocínio direto — R$1-8K/vídeo
7. Curso Digital Básico — R$97-197
8. Curso Digital Avançado — R$297-997
9. Grupo de Estudo Premium — R$197-497/mês
10. Consultas psicológicas — R$150-350/sessão (2027+)
11. Programa de Acompanhamento — R$497-997/mês (2027+)
**META: R$80.000-250.000/mês**

### REGRAS CRP (anti-ban)
- NUNCA: diagnóstico, promessa de cura, medicamentos
- NUNCA: prática ilegal de psicologia
- SEMPRE: base DSM-5, APA, CID-11
- SEMPRE: linguagem inclusiva e empática
- NUNCA: "Dra." — apenas "psicóloga" em 2027
- NUNCA: nome de pessoa em 2026

### WHATSAPP
- Máx 1.024 membros/grupo → cria novo automaticamente
- 2026: funil de comunidade (membros conversam entre si)
- 2027: funil de consultas → agendamento Daniela Coelho, psicóloga

### SÉRIES EPISÓDICAS (loop aberto)
1. 📎 A Ciência do Apego — 8 eps (ativa desde dia 1)
2. 🪞 Narcisismo Documentado — 7 eps (dia 30)
3. ⚡ Ansiedade Documentada — 8 eps (dia 60)
4. 🔓 Trauma Invisível — 6 eps (dia 90)
5. 🔥 Burnout Documentado — 5 eps (dia 120)

### TÉCNICAS AVANÇADAS
- PNL Espelhamento: pessoa se VÊ no vídeo
- Loop aberto hipnótico: nunca fecha a curiosidade até o fim
- Vídeos longos 22-28min (CPM 6x maior, público 25-54)
- Indexação sutil de bestsellers (sem venda direta)
- Motor 1000x: 10 hooks × 10 corpos × 10 CTAs
- Revisão em loop até score ≥88 + safety ≥85

### BIOS APÓS REVELAÇÃO (jan 2027)
- YouTube: "Daniela Coelho, psicóloga 🧠 | psicologia.doc | CRP [NÚMERO] | Consultas online → link abaixo"
- Instagram: "@psicologiadoc | Daniela Coelho, psicóloga 🧠 | CRP [NÚMERO] | Consultas online 🔗 link na bio"
- TikTok: "Daniela Coelho • Psicóloga CRP 🧠 • psicologia.doc • Consultas: link na bio"
- Pinterest: "Daniela Coelho, psicóloga | psicologia.doc | Consultas online"

