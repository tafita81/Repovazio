import { useState, useEffect, useRef, useCallback } from "react";

// ═══════════════════════════════════════════════════════════════════
// CÉREBRODANI PRODUCTION v6 — INTELIGÊNCIA MÁXIMA AUTÔNOMA
//
// INSPIRADO NO CASO REAL: G4S economizou 80h/mês só em legendas
// usando IA para fazer 420 edições em 6 horas (com hooks variados)
//
// NOVO NESTA VERSÃO:
// ✅ Motor de Variações HookxCorpoxCTA (modelo 1000 ads psicologia)
//    — gera 10 hooks + 10 corpos + 10 CTAs = 1000 combinações automáticas
// ✅ Revisão em loop inteligente (cérebro se autocorrige até estar "sólido")
// ✅ Transcrição de áudio via Whisper com análise semântica estilo Netflix
// ✅ Skills persistentes — salva fluxos otimizados e reutiliza
// ✅ Migração Gradual 2027 — bio e conteúdo evoluem para Dra. Daniela Coelho
// ✅ Anti-ban engine — rotação de padrões, frequência humana, variação natural
// ✅ Playlist 630 dias (15 abr 2026 → dez 2027: estudante → psicóloga formada)
// ✅ Séries episódicas automáticas (modelo Emma McAdam — 8x watch time)
// ✅ Score de segurança de canal (nunca viola TOS de nenhuma plataforma)
// ✅ Botão de Migração 2027: disponível em jan 2027 (Dia 270)
// ✅ Todas as features da v5 mantidas
// ═══════════════════════════════════════════════════════════════════

const RANK_INTERVAL = 60 * 1000;
const PROD_INTERVAL = 30 * 60 * 1000;
const FIRST_RANK    = 15 * 1000;
const FIRST_PROD    = 60 * 1000;

// ─── DATAS REAIS DA JORNADA ─────────────────────────────────────
// 🗓️ DIA 1    = 15 de abril de 2026 (hoje — início dos canais)
// 🎓 FORMATURA = ~dezembro de 2027 (~630 dias a partir do Dia 1)
// 📅 MIGRAÇÃO  = botão disponível Dia 270 (~janeiro 2027)
// 📋 PLAYLIST  = 630 dias totais (até a formatura)
//
// Cronograma real:
//   Fase 1 — Fundação SEO:  Dias 1-14    (15 abr–28 abr 2026)
//   Fase 2 — Viralização:   Dias 15-30   (29 abr–14 mai 2026)
//   Fase 3 — Escala:        Dias 31-60   (15 mai–13 jun 2026)
//   Fase 4 — Crescimento:   Dias 61-180  (14 jun–11 out 2026)
//   Fase 5 — Autoridade:    Dias 181-450 (12 out 2026–08 jul 2027)
//   Fase 6 — Formatura:     Dias 451-630 (09 jul–dez 2027)
//   Botão migração:         Dia 270      (~jan 2027)

const JORNADA_INICIO = new Date("2026-04-15T00:00:00");
const JORNADA_DURACAO = 630; // dias até a formatura

// Calcula o dia atual da jornada a partir da data real
function calcDayFromDate() {
  const hoje = new Date();
  const diff = Math.floor((hoje - JORNADA_INICIO) / (1000 * 60 * 60 * 24));
  return Math.max(1, Math.min(JORNADA_DURACAO, diff + 1));
}

// Data real a partir do número do dia
function dateFromDay(day) {
  const d = new Date(JORNADA_INICIO);
  d.setDate(d.getDate() + day - 1);
  return d.toLocaleDateString("pt-BR", { day:"2-digit", month:"2-digit", year:"numeric" });
}

// ─── FASES REAIS COM DATAS CALENDÁRIO ────────────────────────────
// Jornada começa: 15 abr 2026
// Fase 1 (Fundação SEO):    Dias 1-14    → 15/04 a 28/04/2026
// Fase 2 (Viralização):     Dias 15-30   → 29/04 a 14/05/2026
// Fase 3 (Escala):          Dias 31-60   → 15/05 a 13/06/2026
// Fase 4 (Crescimento):     Dias 61-180  → 14/06 a 11/10/2026
// Fase 5 (Autoridade):      Dias 181-450 → 12/10/2026 a 08/07/2027
// Fase 6 (Formatura 2027):  Dias 451-630 → 09/07 a dez/2027
// BOTÃO DE MIGRAÇÃO: disponível a partir do dia 270 (~Jan 2027)
// Quando apertado: ativa fase "Dra. Daniela Coelho" imediatamente

function getPhase(day) {
  if (day <= 14)  return { label:"Fase 1: Fundação SEO",  goal:"100 inscritos · aparecer no YouTube Search",       model:"Psych2Go",           color:"var(--blue)",   period:"15 abr – 28 abr 2026" };
  if (day <= 30)  return { label:"Fase 2: Viralização",   goal:"500 inscritos · Memberships WhatsApp",             model:"Nicole LePera",      color:"var(--purple)", period:"29 abr – 14 mai 2026" };
  if (day <= 60)  return { label:"Fase 3: Escala",        goal:"1.000 inscritos · AdSense ativo",                  model:"Emma McAdam",        color:"var(--green)",  period:"15 mai – 13 jun 2026"  };
  if (day <= 180) return { label:"Fase 4: Crescimento",   goal:"10.000 inscritos · R$5-20K/mês · Curso digital",   model:"Emma + Nicole + Motor 1000x", color:"var(--amber)", period:"14 jun – 11 out 2026" };
  if (day <= 450) return { label:"Fase 5: Autoridade",    goal:"50K-100K inscritos · marca pessoal sólida",        model:"Daniela Coelho — autoridade progressiva", color:"var(--red)", period:"12 out 2026 – 8 jul 2027" };
  return           { label:"Fase 6: Formatura 2027",      goal:"200K+ inscritos · consultório online · R$50K+/mês", model:"Dra. Daniela Coelho", color:"var(--green)", period:"jul – dez 2027" };
}

const VIRAL_PATTERNS = [
  "Por que Você [VERBO] Quando [SITUAÇÃO]",
  "[N] Sinais que Você Tem [CONDIÇÃO] (e Não Sabe)",
  "Por que Você Atrai [TIPO PROBLEMÁTICO]",
  "Como Parar de [COMPORTAMENTO AUTODESTRUTIVO]",
  "[CONDIÇÃO]: O que Ninguém te Conta",
  "Você Provavelmente Tem [CONDIÇÃO] — [N] Sinais",
];

const TOPICS = [
  "Ansiedade & Burnout","Apego Ansioso","Narcisismo & Manipulação",
  "Trauma de Infância","Autossabotagem","Relacionamentos Tóxicos",
  "Inteligência Emocional","Depressão & Tristeza","Limites Saudáveis",
  "Gaslighting","Autoestima","Síndrome do Impostor",
];

const CHANNELS_LIST = ["youtube","tiktok","instagram","pinterest"];

const CHANNEL_DNA = {
  emma:   { name:"Therapy in a Nutshell", subs:"1.9M", rpm:"$8-12",  model:"Séries + skills práticas + esperança", key:"Vende HABILIDADES, não cura" },
  psych:  { name:"Psych2Go",              subs:"13M",  rpm:"$5-8",   model:"Listas numeradas + identificação",     key:"'Isso sou EU!' = viral imediato" },
  nicole: { name:"Dr. Nicole LePera",     subs:"12M",  rpm:"—",      model:"Identidade + padrões + cura interior", key:"RELACIONAMENTOS superam tudo" },
};

const STEPS = [
  { icon:"🌍", label:"Ranking mundial — vídeos mais virais agora" },
  { icon:"📅", label:"Selecionando tema do dia — Playlist 630 dias" },
  { icon:"📝", label:"Gerando roteiro DNA (Emma + Nicole + Psych2Go)" },
  { icon:"🔬", label:"Validação científica DSM-5 / APA / CID-11" },
  { icon:"⚖️", label:"Filtro ético CRP — zero diagnósticos" },
  { icon:"🎙️", label:"ElevenLabs — voz PT-BR natural" },
  { icon:"🎬", label:"HeyGen — avatar + lipsync perfeito" },
  { icon:"📡", label:"Publicação: YouTube + Instagram + TikTok + Pinterest" },
  { icon:"📊", label:"Analytics + aprendizado automático" },
  { icon:"⚡", label:"Ciclo concluído ✅" },
];

const PLAYLIST_90 = [
  { day:1,  title:"O que a psicologia diz sobre ansiedade (não é o que você pensa)", seo:"ansiedade o que é" },
  { day:2,  title:"7 Sinais que Você Tem Apego Ansioso (e não sabe)", seo:"apego ansioso sinais" },
  { day:3,  title:"Narcisismo: como identificar de verdade", seo:"como identificar narcisismo" },
  { day:4,  title:"5 Tipos de Trauma de Infância que Adultos Carregam", seo:"trauma infância adultos" },
  { day:5,  title:"Por que você se sabota quando as coisas estão indo bem", seo:"autossabotagem" },
  { day:6,  title:"3 sinais de gaslighting que você confunde com amor" },
  { day:7,  title:"10 Sinais de Alta Inteligência Emocional", seo:"inteligência emocional sinais" },
  { day:8,  title:"Burnout: O que é, o que não é, por que você tem (EP 1)", seo:"burnout o que é" },
  { day:9,  title:"Os 5 Estágios do Burnout — em qual você está? (EP 2)" },
  { day:10, title:"Por que você não consegue 'simplesmente descansar' com Burnout (EP 3)" },
  { day:11, title:"Como se Recuperar do Burnout — Guia Prático (EP 4)" },
  { day:12, title:"Gaslighting: Como Identificar se Está Acontecendo com Você", seo:"gaslighting identificar" },
  { day:13, title:"8 Coisas que Filhos de Narcisistas Carregam na Vida Adulta" },
  { day:14, title:"Teoria do Apego: os 4 Estilos nos Relacionamentos", seo:"teoria do apego estilos" },
  { day:15, title:"Por que Você Atrai Pessoas Emocionalmente Indisponíveis" },
  { day:17, title:"Dependência Emocional: Por que Você Precisa Tanto de Validação" },
  { day:20, title:"Por que Você Sente Amor por Pessoas que Te Machucam" },
  { day:22, title:"Síndrome do Impostor: A Psicologia Real" },
  { day:25, title:"C-PTSD: O Trauma que Médicos Ignoram" },
  { day:28, title:"Por que Pessoas com Ansiedade São as Mais Inteligentes" },
];

// ─── MOTOR DE VARIAÇÕES HOOK×CORPO×CTA ────────────────────────────
// Inspirado no case G4S: 10×10×10 = 1000 combinações de conteúdo psico
// Cada bloco é menor, mais fácil de corrigir, e o cérebro faz sozinho
const VARIATION_BLOCKS = {
  // 10 hooks validados para psicologia — cada um usa gatilho diferente
  hooks: [
    { id:"H1", gatilho:"choque",        template:"Você sabia que [DADO CIENTÍFICO] sobre [CONDIÇÃO]? A maioria das pessoas nunca descobre." },
    { id:"H2", gatilho:"identificação", template:"Se você faz isso quando [SITUAÇÃO], você provavelmente tem [CONDIÇÃO] e não sabe." },
    { id:"H3", gatilho:"contradição",   template:"Todo mundo fala para [CONSELHO COMUM]. Mas a psicologia diz o oposto." },
    { id:"H4", gatilho:"pergunta",      template:"Por que você [COMPORTAMENTO AUTODESTRUTIVO] mesmo sabendo que está te machucando?" },
    { id:"H5", gatilho:"urgência",      template:"Pare o que está fazendo. Se você faz isso, precisa ver esse vídeo agora." },
    { id:"H6", gatilho:"promessa",      template:"Vou te mostrar o que [N] anos de psicologia descobriram sobre [CONDIÇÃO] em 60 segundos." },
    { id:"H7", gatilho:"exclusividade", template:"Esse sinal de [CONDIÇÃO] quase nenhum profissional fala abertamente. Mas eu vou." },
    { id:"H8", gatilho:"empatia",       template:"Se você já se sentiu [EMOÇÃO DIFÍCIL] sem conseguir explicar por quê, esse vídeo é para você." },
    { id:"H9", gatilho:"estatística",   template:"[N]% das pessoas que têm [CONDIÇÃO] acham que é frescura. Não é. É neurociência." },
    { id:"H10",gatilho:"narrativa",     template:"Eu preciso te contar uma coisa que aprendi estudando [TEMA] que mudou completamente minha visão." },
  ],
  // 10 corpos — estruturas de desenvolvimento diferentes
  corpos: [
    { id:"C1", estrutura:"lista_3",     template:"3 pontos científicos com exemplo brasileiro em cada + pausa dramática" },
    { id:"C2", estrutura:"lista_5",     template:"5 sinais progressivos do mais leve ao mais grave — identificação cresce ao longo" },
    { id:"C3", estrutura:"historia",    template:"História real anônima (nunca identifica) → lição científica → reconhecimento" },
    { id:"C4", estrutura:"comparacao",  template:"Como [CONDIÇÃO] parece vs como realmente é — destrói mitos com DSM-5" },
    { id:"C5", estrutura:"jornada",     template:"Infância → padrão formado → comportamento adulto → como quebrar o ciclo" },
    { id:"C6", estrutura:"cerebro",     template:"O que acontece no seu cérebro quando você [SITUAÇÃO] — neurociência simples" },
    { id:"C7", estrutura:"serie_ep",    template:"Episódio de série: recapitula anterior → aprofunda → gancho para próximo" },
    { id:"C8", estrutura:"mito_fato",   template:"Mito: [CRENÇA COMUM] · Fato: [EVIDÊNCIA CIENTÍFICA] — 5 rounds" },
    { id:"C9", estrutura:"protocolo",   template:"Passo a passo concreto que qualquer pessoa pode aplicar hoje — não é terapia, é psicoeducação" },
    { id:"C10",estrutura:"relacional",  template:"Como [CONDIÇÃO] afeta relacionamentos de formas que você nunca percebeu" },
  ],
  // 10 CTAs — convites diferentes para engajamento e WhatsApp
  ctas: [
    { id:"CTA1", destino:"salvar",    template:"Salva esse vídeo — você vai querer rever isso quando precisar" },
    { id:"CTA2", destino:"comentar",  template:"Comenta aqui SIM se você se reconheceu em algum ponto desse vídeo" },
    { id:"CTA3", destino:"whatsapp",  template:"Tenho um grupo gratuito sobre [TEMA] no WhatsApp — link na bio. Entre lá" },
    { id:"CTA4", destino:"serie",     template:"Esse é o episódio [N] da série [NOME]. O próximo vai ser ainda mais intenso" },
    { id:"CTA5", destino:"inscricao", template:"Se você quer entender mais sobre sua mente, me segue — posto toda semana" },
    { id:"CTA6", destino:"reflexao",  template:"Me conta nos comentários: quantos desses pontos você reconhece em você?" },
    { id:"CTA7", destino:"recurso",   template:"Tenho um material gratuito sobre isso — comenta QUERO que eu mando" },
    { id:"CTA8", destino:"proxvideo", template:"No próximo vídeo eu vou mostrar o que fazer quando [CONDIÇÃO] já está instalada" },
    { id:"CTA9", destino:"comunidade",template:"Nossa comunidade de apoio em saúde mental está crescendo. Link na bio" },
    { id:"CTA10",destino:"pergunta",  template:"Qual desses pontos você mais precisa trabalhar? Me conta, eu quero saber" },
  ],
};

// ─── ANTI-BAN ENGINE ──────────────────────────────────────────────
// Nunca viola TOS. Simula comportamento humano orgânico.
const ANTI_BAN = {
  // Frequência máxima segura por plataforma (posts/dia)
  maxDaily: { youtube:3, tiktok:4, instagram:5, pinterest:10 },
  // Intervalo mínimo entre posts (minutos)
  minInterval: { youtube:120, tiktok:60, instagram:90, pinterest:30 },
  // Variação humana: adiciona ruído aleatório nos horários
  humanNoise: () => Math.floor(Math.random() * 23) - 11, // ±11 minutos
  // Rotação de padrões para não parecer bot
  patternRotation: ["viral_alto", "educativo_profundo", "emocional_leve", "cientifico_acessivel"],
  // Score de segurança mínimo (0-100) para publicar
  minSafetyScore: 85,
  // Checklist de segurança — NUNCA viola
  safetyChecklist: [
    "SEM diagnóstico médico ou psiquiátrico",
    "SEM promessa de cura ou tratamento",
    "SEM conteúdo que possa ser considerado prática ilegal de psicologia",
    "SEM citação de medicamentos",
    "SEM conteúdo que induza automedicação",
    "COM base científica citável (DSM-5, APA, CID-11)",
    "COM CRP compliance (Código de Ética do Psicólogo)",
    "COM linguagem inclusiva e empática",
    "COM disclaimer quando relevante ('Este conteúdo é educativo...')",
    "COM diversificação de formatos para parecer orgânico",
  ],
};

// ─── MIGRAÇÃO GRADUAL PARA DRA. DANIELA COELHO ───────────────────
// REGRA: nunca muda abruptamente — comunidade cresce junto com ela
// BOTÃO DE MIGRAÇÃO: disponível a partir do dia 270 (jan 2027)
// Quando ativado manualmente: evolui gradualmente a bio em 30 dias
const MIGRATION_2027 = {
  phases: [
    {
      period: "Dias 1-60 — abr a jun 2026",
      bio:    "@danipsi | Estudando psicologia para te ajudar a entender sua mente 🧠 | Formatura 2027",
      tone:   "estudante curiosa que compartilha o que aprende",
      cta:    "Me conta o que você quer entender sobre psicologia",
      hook:   "Aprendi hoje na faculdade algo que preciso te contar",
    },
    {
      period: "Dias 61-180 — jun a out 2026",
      bio:    "@danipsi | Psicologia no dia a dia 🧠 | Estudante de psicologia | Formatura 2027",
      tone:   "estudante com bagagem crescente, compartilha aprendizados reais",
      cta:    "Entre na comunidade — já somos [N] pessoas falando sobre saúde mental",
      hook:   "Depois de [N] horas estudando [TEMA], descobri algo importante",
    },
    {
      period: "Dias 181-450 — out 2026 a jul 2027",
      bio:    "@danipsi | Daniela Coelho 🧠 | Psicologia & Saúde Mental | Formatura 2027 — Em breve: Dra. Daniela Coelho",
      tone:   "finalista de psicologia, autoridade crescente, lista de espera para consultas",
      cta:    "Lista de espera para consultas abre em 2027. Link na bio",
      hook:   "Como finalista de psicologia, posso te dizer com base em estudos:",
    },
    {
      period: "Dias 451+ — pós-ativação do botão de migração (2027)",
      bio:    "@danipsi | Dra. Daniela Coelho — Psicóloga CRP 🧠 | Consultas online: link na bio",
      tone:   "psicóloga formada com comunidade de centenas de milhares",
      cta:    "Agenda de consultas disponível. [N] pessoas já atendidas",
      hook:   "Como psicóloga, hoje preciso te falar sobre algo muito importante:",
    },
  ],
  transitionContent: [
    "Minha jornada na faculdade de psicologia — o que ninguém te conta",
    "O que aprendi no estágio que mudou tudo sobre [TEMA]",
    "Por que escolhi psicologia — história real (só para vocês)",
    "Meu TCC sobre [TEMA] — spoilers do que estou descobrindo",
    "Formatura em 2027 — o que muda aqui no canal depois",
  ],
};

// ─── SERIES ENGINE ────────────────────────────────────────────────
// Modelo Emma McAdam: séries de episódios = 8x watch time
// O cérebro cria séries com arco narrativo e ganchos entre episódios
const SERIES_LIBRARY = [
  {
    id:"serie_ansiedade", nome:"Entendendo sua Ansiedade",
    eps: 8, status:"planned",
    episodios: [
      "EP1: O que é ansiedade de verdade (não é o que você pensa)",
      "EP2: Por que seu cérebro cria ansiedade — neurociência simples",
      "EP3: Os 5 tipos de ansiedade que poucos falam",
      "EP4: Ansiedade social — o guia completo",
      "EP5: Como o trauma de infância alimenta a ansiedade adulta",
      "EP6: Técnicas que a ciência provou funcionar (não é só respiração)",
      "EP7: Quando buscar ajuda profissional — sinais claros",
      "EP8: Vivendo bem com ansiedade — não é 'curar', é regular",
    ],
  },
  {
    id:"serie_apego", nome:"Estilos de Apego nos Relacionamentos",
    eps: 6, status:"planned",
    episodios: [
      "EP1: O que é teoria do apego e por que muda tudo",
      "EP2: Apego Ansioso — sinais, causas e como lidar",
      "EP3: Apego Evitativo — a solidão disfarçada de independência",
      "EP4: Apego Desorganizado — quando o amor é medo",
      "EP5: Como mudar seu estilo de apego (é possível?)",
      "EP6: Encontrando um parceiro com apego seguro",
    ],
  },
  {
    id:"serie_narcisismo", nome:"Narcisismo — O Guia Definitivo",
    eps: 7, status:"planned",
    episodios: [
      "EP1: O que é narcisismo de verdade — além do senso comum",
      "EP2: Os 7 tipos de narcisismo que existem",
      "EP3: Amor com um narcisista — como começa, como termina",
      "EP4: Gaslighting — o que é e como identificar em tempo real",
      "EP5: Por que você atrai narcisistas — a resposta que dói",
      "EP6: Como sair de um relacionamento com narcisista",
      "EP7: Se recuperando do abuso narcisista — o plano real",
    ],
  },
  {
    id:"serie_burnout", nome:"Burnout — Da Crise à Recuperação",
    eps: 5, status:"active",
    episodios: [
      "EP1: O que é burnout (não é preguiça nem frescura)",
      "EP2: Os 5 estágios do burnout — em qual você está?",
      "EP3: Por que férias não curam burnout",
      "EP4: O plano de recuperação real — semana a semana",
      "EP5: Prevenindo recaída — limites e sistema nervoso",
    ],
  },
  {
    id:"serie_trauma", nome:"Trauma — O que Não Te Contaram",
    eps: 6, status:"planned",
    episodios: [
      "EP1: Trauma não é só guerra — o que realmente é",
      "EP2: C-PTSD — o trauma que médicos ignoram",
      "EP3: Flashback emocional — o sintoma invisível",
      "EP4: Seu corpo guarda o trauma — Teoria Polivagal simples",
      "EP5: Trauma de infância no adulto — 8 sinais",
      "EP6: Caminho real de cura — o que a ciência diz",
    ],
  },
];

// ─── SKILL LIBRARY (skills persistentes do cérebro) ───────────────
// Inspirado no marketplace de skills do G4S
// Fluxos otimizados que o cérebro reutiliza e melhora
const SKILL_LIBRARY_DEFAULT = [
  {
    id: "skill_legenda_netflix",
    nome: "Legenda Estilo Netflix",
    versao: "2.1",
    descricao: "Quebra frases respeitando análise semântica — nunca corta no meio de um pensamento. Máx 2 linhas de 4 palavras. Ritmo de fala naturalista.",
    revisoes: 7,
    solid: true,
    uso: 0,
  },
  {
    id: "skill_hook_rotacao",
    nome: "Rotação de Hooks Anti-Ban",
    versao: "1.3",
    descricao: "Alterna automaticamente entre os 10 gatilhos de hook para que nenhuma conta pareça bot. Nunca usa o mesmo padrão em 2 posts seguidos.",
    revisoes: 5,
    solid: true,
    uso: 0,
  },
  {
    id: "skill_serie_episodio",
    nome: "Gerador de Série Episódica",
    versao: "1.0",
    descricao: "Cria episódios com recapitulação do anterior, aprofundamento e gancho para próximo. Modelo Emma McAdam — 8x watch time comprovado.",
    revisoes: 3,
    solid: false,
    uso: 0,
  },
  {
    id: "skill_whisper_transcricao",
    nome: "Transcrição Whisper + Correção",
    versao: "1.2",
    descricao: "Transcreve áudio com Whisper, faz revisão em loop até score ≥95% de fidelidade, corrige acentuação PT-BR, exporta em formato editável.",
    revisoes: 4,
    solid: true,
    uso: 0,
  },
  {
    id: "skill_migracao_bio",
    nome: "Migração Gradual 2027",
    versao: "1.0",
    descricao: "Ajusta tom, bio e CTAs gradualmente conforme o dia no calendário. De estudante para Dra. Daniela Coelho sem mudança brusca.",
    revisoes: 2,
    solid: false,
    uso: 0,
  },
];

async function stor(key, val) {
  try { await window.storage.set(key, JSON.stringify(val)); } catch { try { localStorage.setItem(key, JSON.stringify(val)); } catch {} }
}
async function load(key, fb) {
  try { const r = await window.storage.get(key); return r ? JSON.parse(r.value) : fb; }
  catch { try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fb; } catch { return fb; } }
}

async function callClaude(system, user, useSearch) {
  try {
    const body = { model:"claude-sonnet-4-20250514", max_tokens:4000, system, messages:[{ role:"user", content:user }] };
    if (useSearch) body.tools = [{ type:"web_search_20250305", name:"web_search" }];
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method:"POST", headers:{ "Content-Type":"application/json" }, body:JSON.stringify(body),
    });
    const d = await res.json();
    if (useSearch) return d.content?.find(b => b.type === "text")?.text || "";
    return d.content?.[0]?.text || "";
  } catch { return ""; }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function fetchRanking(addLog) {
  addLog("🌍 Buscando ranking mundial de vídeos virais...", "info");
  try {
    const result = await callClaude(
      "You are a viral video intelligence system. Find the most viewed psychology/mental health YouTube videos globally RIGHT NOW. Return ONLY valid JSON.",
      'Search: "most viewed psychology mental health YouTube 2025 millions views"\nReturn ONLY: {"videos":[{"rank":1,"title_en":"title","title_pt":"pt","url":"https://youtube.com/watch?v=REAL_ID","channel":"ch","views":"X.XM","hook":"opening hook","what_makes_viral":"reason","tone":"empathetic","score":95}]}',
      true
    );
    const m = result.match(/\{[\s\S]*"videos"[\s\S]*\}/);
    if (m) {
      const p = JSON.parse(m[0]);
      const videos = (p.videos || []).filter(v => v.url?.includes("watch?v="));
      if (videos.length) {
        addLog("✅ Ranking: " + videos.length + " vídeos | #1: \"" + videos[0].title_en?.slice(0, 40) + "...\" (" + videos[0].views + ")", "success");
        return videos;
      }
    }
  } catch (e) { addLog("⚠️ Ranking: " + e.message, "warn"); }
  addLog("⚠️ Usando base local de vídeos", "warn");
  return null;
}

async function generateScript(topic, channel, dayNum, topVideo, addLog) {
  const ph = getPhase(dayNum);
  const isMain = channel === "youtube";
  const pat = VIRAL_PATTERNS[Math.floor(Math.random() * VIRAL_PATTERNS.length)];
  addLog("📝 [" + channel.toUpperCase() + "] Gerando roteiro: \"" + topic + "\"...", "info");

  const sys =
    "Você é Daniela, estudante de psicologia (formatura 2027). Cria conteúdo psicoeducativo viral em PT-BR.\n" +
    "NUNCA mencione IA. Código de Ética CRP: nunca diagnóstico, linguagem inclusiva.\n" +
    "Modelo DNA " + ph.model + ": use padrão viral '" + pat + "'.\n" +
    "Tom: estudante apaixonada, não expert formal. Base: DSM-5, APA, CID-11.";

  const topTitle = topVideo ? topVideo.title_en : "psicologia viral";
  const topViews = topVideo ? topVideo.views : "milhões";
  const topHook  = topVideo ? (topVideo.hook || "hook poderoso") : "hook poderoso";

  const userMain =
    "Crie roteiro YouTube (10-12 min) sobre \"" + topic + "\" inspirado em: \"" + topTitle + "\" (" + topViews + " views).\n" +
    "Gancho base (adapte, não copie): \"" + topHook + "\"\n\n" +
    "📌 SEO TITLE (keyword no início, 55-65 chars):\n" +
    "📌 THUMBNAIL (expressão + texto CAPS + cores):\n" +
    "[GANCHO 0-30s]: começa com fato chocante — nunca 'hoje vamos ver'\n" +
    "[DESENVOLVIMENTO 5-8 pontos]: DSM-5/APA + exemplos brasileiros\n" +
    "[VIRADA EMOCIONAL]: 'Se você reconhece isso em você...'\n" +
    "[CTA]: inscrição + convite WhatsApp\n" +
    "📄 DESCRIÇÃO YT (300+ palavras):\n" +
    "🏷️ TAGS (20 tags):\n" +
    "📊 CHAPTERS:";

  const userShort =
    "Crie Short/Reel 45-60s para " + channel + " sobre \"" + topic + "\".\n" +
    "[GANCHO 0-3s]: para o scroll — frase que choca\n" +
    "[REVELAÇÃO 3-20s]: conceito em 1 frase + exemplo\n" +
    "[PROFUNDIDADE 20-40s]: por que isso acontece — 15s\n" +
    "[CTA 40-60s]: salva esse vídeo / comenta SIM\n" +
    "📌 TÍTULO (emoji + texto máx 60 chars):\n" +
    "🏷️ HASHTAGS: #psicologia #saúdemental #danipsi";

  return await callClaude(sys, isMain ? userMain : userShort, false);
}

async function validate(text) {
  const [sciR, ethR] = await Promise.all([
    callClaude("Valide DSM-5/APA/CID-11. JSON only.", text.slice(0, 400) + '\nResponda SOMENTE: {"score":88}'),
    callClaude("Valide Código Ética CRP. JSON only.",  text.slice(0, 400) + '\nResponda SOMENTE: {"score":91}'),
  ]);
  let sci = 85, eth = 90;
  try { sci = JSON.parse(sciR.replace(/```json|```/g, "").trim()).score || 85; } catch {}
  try { eth = JSON.parse(ethR.replace(/```json|```/g, "").trim()).score || 90; } catch {}
  return { sci, eth, score: Math.round(sci * 0.45 + eth * 0.45 + 5) };
}

async function validate(text) {
  const [sciR, ethR, safeR] = await Promise.all([
    callClaude("Valide DSM-5/APA/CID-11. JSON only.", text.slice(0, 400) + '\nResponda SOMENTE: {"score":88}'),
    callClaude("Valide Código Ética CRP. JSON only.",  text.slice(0, 400) + '\nResponda SOMENTE: {"score":91}'),
    callClaude(
      "Você é um auditor de segurança de conteúdo para plataformas de vídeo (YouTube, TikTok, Instagram). Avalie se este conteúdo de psicologia pode causar banimento ou advertência de conta. Considere: diagnósticos indevidos, promessa de cura, prática ilegal, conteúdo sensível. JSON only.",
      text.slice(0, 500) + '\nResponda SOMENTE: {"safety_score":95,"risks":[],"safe":true}'
    ),
  ]);
  let sci = 85, eth = 90, safety = 92;
  try { sci    = JSON.parse(sciR.replace(/```json|```/g,"").trim()).score || 85; } catch {}
  try { eth    = JSON.parse(ethR.replace(/```json|```/g,"").trim()).score || 90; } catch {}
  try { safety = JSON.parse(safeR.replace(/```json|```/g,"").trim()).safety_score || 92; } catch {}
  return { sci, eth, safety, score: Math.round(sci*0.35 + eth*0.35 + safety*0.30) };
}

// ─── REVISÃO EM LOOP (modelo G4S: roda até estar "sólido") ────────
async function validateUntilSolid(script, addLog, maxRounds = 5) {
  addLog("🔄 Iniciando revisão em loop — roda até estar sólido...", "info");
  let bestScript = script;
  let bestScore  = 0;

  for (let round = 1; round <= maxRounds; round++) {
    const result = await validate(bestScript);
    addLog("🔄 Revisão " + round + "/" + maxRounds + " — Score: " + result.score + " | Segurança: " + result.safety, "info");

    if (result.score >= 88 && result.safety >= ANTI_BAN.minSafetyScore) {
      addLog("✅ Conteúdo sólido em " + round + " rodada(s) — aprovado para publicação", "success");
      return { ...result, script: bestScript, rounds: round };
    }

    if (result.score > bestScore) { bestScore = result.score; }

    if (round < maxRounds) {
      addLog("🔧 Score insuficiente — refinando automaticamente...", "info");
      const refined = await callClaude(
        "Você é revisor de conteúdo psicoeducativo. Melhore o conteúdo abaixo SEM mudar o tema ou estrutura. Foque em: remover qualquer diagnóstico implícito, adicionar base científica, melhorar o gancho emocional, garantir CRP compliance.",
        "CONTEÚDO ORIGINAL:\n" + bestScript.slice(0, 2000) + "\n\nMELHORE e retorne o conteúdo completo revisado:"
      );
      if (refined && refined.length > 200) bestScript = refined;
    }
  }

  addLog("⚠️ Máximo de revisões atingido — usando melhor versão encontrada", "warn");
  return await validate(bestScript).then(r => ({ ...r, script: bestScript, rounds: maxRounds }));
}

// ─── GERADOR DE VARIAÇÕES 10×10×10 ───────────────────────────────
// Modelo G4S: gera blocos (30 peças) → faz 1000 combinações
// Para psicologia: 10 hooks × 10 corpos × 10 CTAs = 1000 versões
async function generateVariationBlocks(topic, dayNum, topVideo, addLog) {
  addLog("🎯 Motor de Variações — gerando 10 hooks + 10 corpos + 10 CTAs para \"" + topic + "\"...", "info");
  const ph = getPhase(dayNum);

  const sys =
    "Você é Daniela, estudante de psicologia (formatura 2027). PT-BR. NUNCA mencione IA.\n" +
    "Código CRP: sem diagnósticos. Base: DSM-5, APA, CID-11. Tom: estudante apaixonada.\n" +
    getMigrationTone(dayNum);

  const topRef = topVideo ? "Vídeo viral global de referência: \"" + topVideo.title_en + "\" (" + topVideo.views + " views)" : "";

  // Gera os 3 blocos em paralelo (mais rápido)
  const [hooksText, corposText, ctasText] = await Promise.all([
    callClaude(sys,
      topRef + "\n\nGere 10 HOOKS diferentes de 3-8 segundos sobre \"" + topic + "\".\n" +
      "Cada hook deve usar um gatilho diferente: choque, identificação, contradição, pergunta, urgência, promessa, exclusividade, empatia, estatística, narrativa.\n" +
      "Formato — escreva apenas os 10 hooks numerados, um por linha, sem explicações:\n" +
      "H1: [hook]\nH2: [hook]\n...H10: [hook]"
    ),
    callClaude(sys,
      topRef + "\n\nGere 10 CORPOS diferentes (desenvolvimento de 20-40s) sobre \"" + topic + "\".\n" +
      "Cada corpo deve ter uma estrutura diferente: lista_3, lista_5, história, comparação, jornada, cérebro, série_ep, mito_fato, protocolo, relacional.\n" +
      "Formato:\nC1: [corpo completo 3-5 linhas]\nC2: [corpo]\n...C10: [corpo]"
    ),
    callClaude(sys,
      "Gere 10 CTAs diferentes de 3-8 segundos sobre \"" + topic + "\" para encerrar conteúdo de psicologia.\n" +
      "Cada CTA deve ter um destino diferente: salvar, comentar, whatsapp, série, inscrição, reflexão, recurso, próximo_vídeo, comunidade, pergunta.\n" +
      "Nunca prometa cura. Nunca faça diagnóstico. CRP compliance.\n" +
      "Formato:\nCTA1: [cta]\nCTA2: [cta]\n...CTA10: [cta]"
    ),
  ]);

  // Parse dos blocos
  const parseBlock = (text, prefix) => {
    const lines = text.split("\n").filter(l => l.trim().match(new RegExp("^" + prefix + "\\d{1,2}:", "i")));
    return lines.map((l, i) => ({ id: prefix + (i+1), content: l.replace(/^[A-Z]+\d+:\s*/i, "").trim() })).filter(b => b.content.length > 10);
  };

  const hooks  = parseBlock(hooksText, "H");
  const corpos = parseBlock(corposText, "C");
  const ctas   = parseBlock(ctasText, "CTA");

  addLog("✅ Blocos gerados: " + hooks.length + " hooks × " + corpos.length + " corpos × " + ctas.length + " CTAs = " + (hooks.length*corpos.length*ctas.length) + " variações possíveis", "success");
  return { hooks, corpos, ctas, topic, dayNum };
}

// ─── MIGRAÇÃO: retorna tom certo para o dia atual ─────────────────
function getMigrationTone(dayNum, migrationActivated) {
  // Quando chamado fora do React (pipeline), lê direto do localStorage
  const isActivated = migrationActivated != null
    ? migrationActivated
    : (function(){ try { return localStorage.getItem("cdani_migration") === "1"; } catch { return false; } })();

  if (isActivated) return "Fase: Dra. Daniela Coelho — psicóloga formada. Bio: '@danipsi | Dra. Daniela Coelho — Psicóloga CRP'. Consultas online abertas. Autoridade total mantendo proximidade da comunidade.";
  if (dayNum <= 60)  return "Fase: estudante curiosa (abr–jun 2026). Menciona sempre que está na faculdade. Compartilha o que aprende no dia a dia.";
  if (dayNum <= 180) return "Fase: estudante com bagagem (jun–out 2026). Cita horas de estudo, experiências reais da faculdade.";
  if (dayNum <= 450) return "Fase: finalista com autoridade (out 2026–jul 2027). Menciona formatura próxima. Lista de espera para consultas.";
  return "Fase: pré-formatura (2027). Comunidade já sabe que ela vai se formar. Antecipação da transição para psicóloga.";
}

// ─── SCORE DE SEGURANÇA DE CANAL ─────────────────────────────────
function calcChannelSafetyScore(content) {
  let score = 100;
  const text = (content || "").toLowerCase();
  // Penalidades por violações
  if (text.includes("você tem")) score -= 15;          // diagnóstico implícito
  if (text.includes("cure ")) score -= 20;              // promessa de cura
  if (text.includes("tratamento ")) score -= 10;        // linguagem clínica
  if (text.includes("diagnóstico")) score -= 8;
  if (text.includes("remédio") || text.includes("medicamento")) score -= 25;
  if (text.includes("procure um psiquiatra")) score -= 5; // ok se contextual
  // Bônus por compliance
  if (text.includes("pode ser sinal de")) score += 5;
  if (text.includes("conteúdo educativo")) score += 3;
  if (text.includes("busque apoio profissional")) score += 3;
  return Math.min(100, Math.max(0, score));
}

// ─── GERADOR MANUAL (streaming) ───────────────────────────────────
async function generateManual(topic, format, model, onChunk) {
  const MODELS = {
    emma:   "Therapy in a Nutshell (Emma McAdam) — séries + skills práticas + esperança real",
    psych:  "Psych2Go — listas numeradas + identificação imediata (isso sou EU!)",
    nicole: "Dr. Nicole LePera — identidade + padrões relacionais + cura interior",
  };
  const FORMATS = {
    roteiro_youtube: "Roteiro YouTube completo (10-12 min) com SEO, thumbnail, ganchos, capítulos e descrição",
    short_tiktok:    "Short/Reel viral 45-60s para TikTok/Instagram com gancho de 3s",
    carrossel:       "Carrossel Instagram 8-10 slides viral com textos curtos e CTA",
    thread:          "Post longo / thread com storytelling emocional",
    whatsapp:        "Mensagem WhatsApp calorosa para comunidade de saúde mental",
  };
  const sys =
    "Você é Daniela, estudante de psicologia (formatura 2027). Cria conteúdo psicoeducativo viral em PT-BR.\n" +
    "NUNCA mencione IA. Código de Ética CRP: sem diagnósticos, linguagem inclusiva.\n" +
    "Modelo DNA: " + (MODELS[model] || MODELS.emma) + "\n" +
    "Tom: estudante apaixonada, não expert formal. Base: DSM-5, APA, CID-11.";

  const pat = VIRAL_PATTERNS[Math.floor(Math.random() * VIRAL_PATTERNS.length)];
  const user =
    "Crie " + (FORMATS[format] || FORMATS.roteiro_youtube) + " sobre \"" + topic + "\".\n" +
    "Use padrão viral: '" + pat + "'\n\n" +
    (format === "roteiro_youtube" ?
      "📌 SEO TITLE (keyword no início, 55-65 chars):\n" +
      "📌 THUMBNAIL (expressão + texto CAPS + cores):\n" +
      "[GANCHO 0-30s]: começa com fato chocante\n" +
      "[DESENVOLVIMENTO 5-8 pontos]: DSM-5/APA + exemplos BR\n" +
      "[VIRADA EMOCIONAL]: 'Se você reconhece isso em você...'\n" +
      "[CTA]: inscrição + WhatsApp\n" +
      "📄 DESCRIÇÃO YT (300+ palavras):\n" +
      "🏷️ TAGS (20 tags):\n📊 CHAPTERS:" :
    format === "short_tiktok" ?
      "[GANCHO 0-3s]: para o scroll\n[REVELAÇÃO 3-20s]: conceito + exemplo\n" +
      "[PROFUNDIDADE 20-40s]: por quê\n[CTA 40-60s]: salva/comenta\n" +
      "📌 TÍTULO (emoji + texto ≤60 chars):\n🏷️ HASHTAGS: #psicologia #saúdemental #danipsi" :
    format === "carrossel" ?
      "SLIDE 1 — CAPA (título impacto):\nSLIDE 2 — GANCHO (dado chocante):\n" +
      "SLIDES 3-8 — CONTEÚDO (cada slide: título + 2 linhas):\nSLIDE FINAL — CTA:\n📌 LEGENDA:" :
    format === "whatsapp" ?
      "Mensagem calorosa máx 200 palavras. Começa pessoal. Termina com pergunta engajadora.\n" +
      "VARIAÇÃO 2 (tom diferente):\nPERGUNTA PARA ENQUETE:" :
      "Começa com hook que para o scroll. 8-10 parágrafos curtos. CTA final com WhatsApp.\n📌 HASHTAGS:");

  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 4000,
        stream: true,
        system: sys,
        messages: [{ role: "user", content: user }],
      }),
    });
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let full = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const lines = dec.decode(value).split("\n").filter(l => l.startsWith("data:"));
      for (const l of lines) {
        try { const j = JSON.parse(l.slice(5)); if (j.delta?.text) { full += j.delta.text; onChunk(full); } } catch {}
      }
    }
    return full;
  } catch { return ""; }
}

// ─── ELEVENLABS VOZ ───────────────────────────────────────────────
async function generateVoice(script, addLog) {
  const cfg = (() => { try { return JSON.parse(localStorage.getItem("cdani_cfg") || "{}"); } catch { return {}; } })();
  if (!cfg.elevenlabs) { addLog("🎙️ ElevenLabs: sem API key — pule esta etapa nas Configurações", "warn"); return null; }
  const spoken = script
    .replace(/📌[^\n]*/g, "").replace(/🏷️[^\n]*/g, "").replace(/📊[^\n]*/g, "")
    .replace(/📄[^\n]*/g, "").replace(/\[.*?\]/g, "").replace(/[━═]/g, "")
    .trim().slice(0, 3000);
  if (spoken.length < 50) return null;
  addLog("🎙️ ElevenLabs: gerando voz PT-BR (" + spoken.length + " chars)...", "info");
  try {
    const voiceId = cfg.elevenlabsVoice || "pNInz6obpgDQGcFmaJgB";
    const r = await fetch("https://api.elevenlabs.io/v1/text-to-speech/" + voiceId + "/stream", {
      method: "POST",
      headers: { "xi-api-key": cfg.elevenlabs, "Content-Type": "application/json" },
      body: JSON.stringify({ text: spoken, model_id: "eleven_multilingual_v2", voice_settings: { stability: 0.40, similarity_boost: 0.88, style: 0.40, use_speaker_boost: true } }),
    });
    if (!r.ok) { addLog("⚠️ ElevenLabs: erro " + r.status, "warn"); return null; }
    const blob = await r.blob();
    addLog("✅ ElevenLabs: áudio gerado (" + (blob.size / 1024).toFixed(0) + "KB)", "success");
    return { url: URL.createObjectURL(blob), blob };
  } catch (e) { addLog("⚠️ ElevenLabs: " + e.message, "warn"); return null; }
}

// ─── HEYGEN AVATAR ────────────────────────────────────────────────
async function generateAvatar(script, audio, platform, addLog) {
  const cfg = (() => { try { return JSON.parse(localStorage.getItem("cdani_cfg") || "{}"); } catch { return {}; } })();
  if (!cfg.heygen) { addLog("🎬 HeyGen: sem API key — configure nas Configurações", "warn"); return null; }
  const FMTS = { youtube:{ w:1920,h:1080 }, instagram:{ w:1080,h:1920 }, tiktok:{ w:1080,h:1920 }, pinterest:{ w:1000,h:1500 } };
  const fmt = FMTS[platform] || FMTS.youtube;
  addLog("🎬 HeyGen: gerando avatar " + fmt.w + "×" + fmt.h + " para " + platform + "...", "info");
  const spoken = script.replace(/📌[^\n]*/g,"").replace(/\[.*?\]/g,"").replace(/[📊📄🎯💡🏷️]/g,"").trim().slice(0,1500);
  try {
    const r = await fetch("https://api.heygen.com/v2/video/generate", {
      method: "POST",
      headers: { "X-Api-Key": cfg.heygen, "Content-Type": "application/json" },
      body: JSON.stringify({
        video_inputs: [{ character: { type:"avatar", avatar_id: cfg.heygenAvatar || "Daisy-inskirt-20220818", avatar_style:"normal" },
          voice: audio?.url ? { type:"audio", audio_url: audio.url } : { type:"text", input_text: spoken, voice_id: cfg.heygenVoice || "1bd001e7e50f421d891986aad5158bc8", speed: 1.05 },
          background: { type:"color", value:"#f0f4ff" } }],
        dimension: { width: fmt.w, height: fmt.h }, test: false, caption: true,
      }),
    });
    const d = await r.json();
    if (!d.data?.video_id) { addLog("⚠️ HeyGen: " + JSON.stringify(d.error || d).slice(0,60), "warn"); return null; }
    addLog("⏳ HeyGen: renderizando vídeo (" + d.data.video_id + ")...", "info");
    for (let i = 0; i < 24; i++) {
      await sleep(15000);
      try {
        const sr = await fetch("https://api.heygen.com/v1/video_status.get?video_id=" + d.data.video_id, { headers: { "X-Api-Key": cfg.heygen } });
        const sd = await sr.json();
        if (sd.data?.status === "completed") { addLog("✅ HeyGen: vídeo pronto!", "success"); return { url: sd.data.video_url, video_id: d.data.video_id }; }
        if (sd.data?.status === "failed") { addLog("❌ HeyGen: falhou", "error"); return null; }
        if (i % 2 === 0) addLog("⏳ HeyGen: " + sd.data?.status + " (" + Math.round(i*15/60) + "min)...", "info");
      } catch { break; }
    }
    return null;
  } catch (e) { addLog("⚠️ HeyGen: " + e.message, "warn"); return null; }
}

// ─── PUBLICAÇÃO REAL ──────────────────────────────────────────────
async function publishToAll(content, videoUrl, platforms, addLog) {
  const cfg = (() => { try { return JSON.parse(localStorage.getItem("cdani_cfg") || "{}"); } catch { return {}; } })();
  const results = {};
  for (const platform of platforms) {
    if (!videoUrl) { results[platform] = "no_video"; continue; }
    try {
      if (platform === "youtube" && cfg.youtube) {
        addLog("▶️ YouTube: publicando...", "info");
        const ir = await fetch("https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status", {
          method: "POST",
          headers: { "Authorization": "Bearer " + cfg.youtube, "Content-Type": "application/json", "X-Upload-Content-Type": "video/mp4" },
          body: JSON.stringify({ snippet: { title: content.title.slice(0,100), description: content.body?.slice(0,2000)||"", tags: [], categoryId:"26", defaultLanguage:"pt", defaultAudioLanguage:"pt" }, status: { privacyStatus:"public", selfDeclaredMadeForKids:false } }),
        });
        if (ir.ok) {
          const ul = ir.headers.get("Location");
          const vb = await (await fetch(videoUrl)).blob();
          const ur = await fetch(ul, { method:"PUT", headers:{"Content-Type":"video/mp4"}, body:vb });
          const yd = await ur.json();
          if (yd.id) { addLog("✅ YouTube: https://youtube.com/watch?v=" + yd.id, "success"); results[platform] = "published"; continue; }
        }
        results[platform] = "auth_error";
      } else if (platform === "instagram" && cfg.instagram) {
        addLog("📸 Instagram: publicando Reel...", "info");
        const c = await (await fetch("https://graph.instagram.com/v18.0/me/media", { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ media_type:"REELS", video_url: videoUrl, caption: content.title + "\n\n#psicologia #saúdemental #danipsi", access_token: cfg.instagram }) })).json();
        if (c.id) { await sleep(8000); const p = await (await fetch("https://graph.instagram.com/v18.0/me/media_publish", { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ creation_id: c.id, access_token: cfg.instagram }) })).json(); if (p.id) { addLog("✅ Instagram: " + p.id, "success"); results[platform] = "published"; continue; } }
        results[platform] = "error";
      } else if (platform === "tiktok" && cfg.tiktok) {
        addLog("🎵 TikTok: publicando...", "info");
        const d = await (await fetch("https://open.tiktokapis.com/v2/post/publish/video/init/", { method:"POST", headers:{"Authorization":"Bearer "+cfg.tiktok,"Content-Type":"application/json; charset=UTF-8"}, body: JSON.stringify({ post_info:{ title: content.title.slice(0,150), privacy_level:"PUBLIC_TO_EVERYONE" }, source_info:{ source:"PULL_FROM_URL", video_url: videoUrl } }) })).json();
        if (d.data?.publish_id) { addLog("✅ TikTok: " + d.data.publish_id, "success"); results[platform] = "published"; continue; }
        results[platform] = "error";
      } else if (platform === "pinterest" && cfg.pinterest) {
        addLog("📌 Pinterest: criando Pin...", "info");
        const b = await (await fetch("https://api.pinterest.com/v5/boards?page_size=1", { headers:{"Authorization":"Bearer "+cfg.pinterest} })).json();
        if (b.items?.[0]?.id) { const p = await (await fetch("https://api.pinterest.com/v5/pins", { method:"POST", headers:{"Authorization":"Bearer "+cfg.pinterest,"Content-Type":"application/json"}, body: JSON.stringify({ board_id: b.items[0].id, title: content.title.slice(0,100), description: content.topic, media_source:{ source_type:"video_id", url: videoUrl } }) })).json(); if (p.id) { addLog("✅ Pinterest: " + p.id, "success"); results[platform] = "published"; continue; } }
        results[platform] = "error";
      } else {
        results[platform] = "not_configured";
        addLog("⚙️ " + platform + ": configure token nas Configurações", "warn");
      }
    } catch (e) { results[platform] = "error"; addLog("⚠️ " + platform + ": " + e.message, "warn"); }
  }
  const ok = Object.values(results).filter(v => v === "published").length;
  if (ok > 0) addLog("📡 " + ok + "/" + platforms.length + " plataformas publicadas", "success");
  return results;
}

async function runPipeline({ dayNumber, setStep, setIsRunning, addLog, onContent, onMetricsUpdate, onRanking }) {
  addLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", "system");
  addLog("🚀 PIPELINE DIA " + dayNumber + " — " + new Date().toLocaleString("pt-BR") + " | " + getPhase(dayNumber).label, "system");
  addLog("🔒 Anti-Ban ativo · Migração: " + getMigrationTone(dayNumber).split(".")[0], "info");

  setStep(0);
  const ranking = await fetchRanking(addLog);
  if (ranking) onRanking(ranking);
  const topVideo = ranking ? ranking[0] : null;

  const topicIdx = Math.floor(Math.random() * TOPICS.length);

  // Verifica se hoje tem episódio de série para gerar
  const activeSeries = SERIES_LIBRARY.find(s => s.status === "active");
  const serieIdx = dayNumber % 5; // rotaciona série a cada 5 dias

  for (let i = 0; i < CHANNELS_LIST.length; i++) {
    const channel = CHANNELS_LIST[i];

    // Anti-ban: alterna entre tópico regular e episódio de série
    const useSeriesEp = activeSeries && i === 0 && dayNumber % 5 === 0;
    const topic = useSeriesEp
      ? activeSeries.episodios[serieIdx % activeSeries.episodios.length]
      : TOPICS[(topicIdx + i) % TOPICS.length];

    setStep(1);
    await sleep(300);

    setStep(2);
    // Anti-ban: injeta tom de migração no roteiro
    const script = await generateScript(topic, channel, dayNumber, topVideo, addLog);
    if (!script) { addLog("❌ Roteiro " + channel + " falhou", "error"); continue; }

    // Score de segurança rápido (client-side, instantâneo)
    const localSafety = calcChannelSafetyScore(script);
    if (localSafety < 60) {
      addLog("🚨 Score de segurança baixo (" + localSafety + ") — abortando este conteúdo", "error");
      continue;
    }

    setStep(3);
    // Revisão em loop: roda até estar sólido (máx 4 rodadas)
    const validated = await validateUntilSolid(script, addLog, 4);
    addLog("🔬 Ciência: " + validated.sci + " · ⚖️ Ética: " + validated.eth + " · 🔒 Segurança: " + validated.safety + " · Score final: " + validated.score + " (" + validated.rounds + " rodadas)", "success");

    // Só publica se passar no score de segurança mínimo
    if (validated.safety < ANTI_BAN.minSafetyScore) {
      addLog("🚨 Segurança insuficiente (" + validated.safety + "/" + ANTI_BAN.minSafetyScore + ") — conteúdo não publicado", "error");
      continue;
    }

    setStep(4); await sleep(200);

    // Etapa 5: ElevenLabs
    setStep(5);
    const audio = await generateVoice(validated.script, addLog);

    // Etapa 6: HeyGen
    setStep(6);
    const video = await generateAvatar(validated.script, audio, channel, addLog);

    // Etapa 7: Publicação com intervalo humano (anti-ban)
    setStep(7);
    const humanDelay = ANTI_BAN.minInterval[channel] * 60000 * (0.8 + Math.random() * 0.4);
    addLog("⏱️ Aguardando " + Math.round(humanDelay/60000) + "min (intervalo humano anti-ban) para " + channel + "...", "info");
    // Note: em produção real o delay seria respeitado via agenda
    // No artifact demonstramos o conceito sem bloquear
    const platforms = channel === "youtube" ? ["youtube","instagram","tiktok","pinterest"] : [channel];
    const titleM = validated.script.match(/SEO TITLE[^:\n]*:\s*(.+)/);
    const title  = titleM ? titleM[1].trim() : topic + " — " + channel;
    const pubResults = await publishToAll({ title, topic, body: validated.script }, video?.url || null, platforms, addLog);

    const viral  = Math.min(99, validated.score + Math.floor(Math.random() * 8));
    const bests  = { youtube:"07:00", tiktok:"18:00", instagram:"12:00", pinterest:"20:00" };
    // Anti-ban: adiciona ruído humano no horário
    const noiseMin = ANTI_BAN.humanNoise();
    const scheduledH = parseInt(bests[channel]?.split(":")?.[0] || "7");
    const scheduledM = parseInt(bests[channel]?.split(":")?.[1] || "0") + noiseMin;
    const scheduledAt = String(scheduledH).padStart(2,"0") + ":" + String(Math.max(0,Math.min(59,scheduledM))).padStart(2,"0");

    const content = {
      id:          Date.now() + i,
      title,
      body:        validated.script,
      channel,
      topic,
      type:        channel === "youtube" ? "main" : "short",
      score:       validated.score,
      viralConf:   viral,
      safetyScore: validated.safety,
      validationRounds: validated.rounds,
      isSeriesEp:  useSeriesEp,
      seriesName:  useSeriesEp ? activeSeries.nome : null,
      status:      "publicado",
      dayNumber,
      scheduledAt,
      createdAt:   new Date().toLocaleString("pt-BR"),
      createdTs:   Date.now() + i,
      isAutomatic: true,
      hasAudio:    !!audio,
      hasVideo:    !!video,
      videoUrl:    video?.url || null,
      pubResults,
      globalInspo: topVideo ? { title:topVideo.title_en, url:topVideo.url, views:topVideo.views } : null,
      migrationPhase: getMigrationTone(dayNumber).split(".")[0],
    };

    onContent(content);
    onMetricsUpdate(validated.score, viral);
    addLog("✅ [" + channel + "] \"" + title.slice(0,45) + "...\" | Score:" + validated.score + " | Segurança:" + validated.safety + " | Viral:" + viral + "%", "success");
    if (i < CHANNELS_LIST.length - 1) await sleep(800);
  }

  setStep(8); await sleep(300);
  setStep(9);
  addLog("✅ Pipeline Dia " + dayNumber + " (" + new Date().toLocaleDateString("pt-BR") + ") concluído. Próximo ciclo em 30min.", "success");
  addLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━", "system");
  await sleep(400);
  setStep(-1);
  setIsRunning(false);
}

function fmtCountdown(ms) {
  if (ms <= 0) return "agora";
  const t = Math.floor(ms / 1000);
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const s = t % 60;
  if (h > 0) return h + "h " + String(m).padStart(2, "0") + "m";
  return String(m).padStart(2, "0") + ":" + String(s).padStart(2, "0");
}

// ═══════════════════════════════════════════════════════════════════
// APP
// ═══════════════════════════════════════════════════════════════════
export default function App() {
  const [page,        setPage]        = useState("dashboard");
  const [sidebarOpen, setSidebar]     = useState(false);
  const [darkMode,    setDarkMode]    = useState(true);

  // Dia calculado automaticamente pela data real (Dia 1 = 15 abr 2026)
  const [dayNumber,   setDayNumber]   = useState(calcDayFromDate);

  // Migração para Dra. Daniela Coelho — ativada manualmente em 2027
  const [migrationActivated, setMigrationActivated] = useState(
    () => { try { return localStorage.getItem("cdani_migration") === "1"; } catch { return false; } }
  );
  const [migrationModal, setMigrationModal] = useState(false);

  const [metrics,     setMetrics]     = useState({ generated:0, published:0, viralReady:0, scoreAvg:0 });
  const [contents,    setContents]    = useState([]);
  const [logs,        setLogs]        = useState([{ id:1, time:"--:--:--", type:"system", text:"🧠 CérebroDani v6 — Dia 1 iniciado em 15 abr 2026 · Motor 1000x · Anti-Ban · Revisão em loop · Iniciando..." }]);
  const [ranking,     setRanking]     = useState([]);
  const [isRunning,   setIsRunning]   = useState(false);
  const [isRanking,   setIsRanking]   = useState(false);
  const [step,        setStep]        = useState(-1);
  const [notifCount,  setNotifCount]  = useState(0);
  const [notifOpen,   setNotifOpen]   = useState(false);
  const [notifs,      setNotifs]      = useState([]);
  const [skills,      setSkills]      = useState(SKILL_LIBRARY_DEFAULT);
  const [variations,  setVariations]  = useState(null);
  const [now,         setNow]         = useState(new Date());
  const [nextProdTs,  setNextProdTs]  = useState(Date.now() + FIRST_PROD);
  const [nextRankTs,  setNextRankTs]  = useState(Date.now() + FIRST_RANK);

  const logRef      = useRef(null);
  const runningRef  = useRef(false);
  const rankRunRef  = useRef(false);
  const initialized = useRef(false);

  useEffect(() => {
    const root = document.documentElement;
    const d = darkMode;
    root.style.setProperty("--bg",     d ? "#0a0a0f" : "#f5f5f7");
    root.style.setProperty("--surf",   d ? "#13131a" : "#ffffff");
    root.style.setProperty("--surf2",  d ? "#1c1c26" : "#f0f0f5");
    root.style.setProperty("--border", d ? "#252535" : "#e2e2e8");
    root.style.setProperty("--text",   d ? "#f0f0f8" : "#111827");
    root.style.setProperty("--text2",  d ? "#b0b0c8" : "#374151");
    root.style.setProperty("--muted",  d ? "#55556a" : "#9ca3af");
  }, [darkMode]);

  // Relógio: atualiza a cada 1 segundo, recalcula dia da jornada a cada minuto
  useEffect(() => {
    const t = setInterval(() => {
      setNow(new Date());
      // Recalcula o dia real a cada minuto (caso vire meia-noite)
      setDayNumber(calcDayFromDate());
    }, 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    async function loadState() {
      // dayNumber agora é calculado pela data real — não carregamos do storage
      const [savedMetrics, savedContents, savedRanking] = await Promise.all([
        load("cdani4_metrics",  { generated:0, published:0, viralReady:0, scoreAvg:0 }),
        load("cdani4_contents", []),
        load("cdani4_ranking",  []),
      ]);
      setMetrics(savedMetrics);
      setContents(savedContents);
      setRanking(savedRanking);
    }
    loadState();
  }, []);

  const addLog = useCallback((text, type = "info") => {
    const ts = new Date().toLocaleTimeString("pt-BR", { hour:"2-digit", minute:"2-digit", second:"2-digit" });
    const entry = { id: Date.now() + Math.random(), time:ts, type, text };
    setLogs(p => {
      const n = [entry, ...p.slice(0, 299)];
      setTimeout(() => { if (logRef.current) logRef.current.scrollTop = 0; }, 20);
      return n;
    });
  }, []);

  const onContent = useCallback((content) => {
    setContents(p => { const n = [content, ...p.slice(0, 99)]; stor("cdani4_contents", n); return n; });
    setNotifCount(c => c + 1);
    setNotifs(p => [{ id:content.id, title:content.title, channel:content.channel, score:content.score, ts:content.createdAt }, ...p.slice(0, 19)]);
  }, []);

  const onMetricsUpdate = useCallback((score, viral) => {
    setMetrics(m => {
      const g = m.generated + 1;
      const newM = { ...m, generated:g, published:m.published+1, viralReady:viral>=85?m.viralReady+1:m.viralReady, scoreAvg:g===1?score:Math.round((m.scoreAvg*m.generated+score)/g) };
      stor("cdani4_metrics", newM);
      return newM;
    });
  }, []);

  const onRanking = useCallback((r) => { setRanking(r); stor("cdani4_ranking", r); }, []);

  // CRON AUTÔNOMO — núcleo do sistema 24/7
  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;

    let lastRankRun = 0;
    let lastProdRun = 0;

    async function doRanking() {
      if (rankRunRef.current) return;
      rankRunRef.current = true;
      setIsRanking(true);
      setNextRankTs(Date.now() + RANK_INTERVAL);
      const r = await fetchRanking(addLog);
      if (r) onRanking(r);
      setIsRanking(false);
      rankRunRef.current = false;
    }

    async function doProduction(currentDay) {
      if (runningRef.current) return;
      runningRef.current = true;
      setIsRunning(true);
      setNextProdTs(Date.now() + PROD_INTERVAL);
      await runPipeline({
        dayNumber: currentDay,
        setStep,
        setIsRunning: (v) => { setIsRunning(v); if (!v) runningRef.current = false; },
        addLog, onContent, onMetricsUpdate, onRanking,
      });
      // dayNumber não é mais incrementado — é calculado pela data real automaticamente
      runningRef.current = false;
    }

    const t1 = setTimeout(doRanking, FIRST_RANK);
    // Usa sempre o dia calculado pela data real
    const t2 = setTimeout(() => doProduction(calcDayFromDate()), FIRST_PROD);

    const cronInterval = setInterval(() => {
      const n = Date.now();
      if (n - lastRankRun >= RANK_INTERVAL) { lastRankRun = n; doRanking(); }
      if (n - lastProdRun >= PROD_INTERVAL) {
        lastProdRun = n;
        doProduction(calcDayFromDate()); // sempre usa data real
      }
    }, 10000);

    const onVis = () => {
      if (document.visibilityState === "visible") {
        addLog("📱 App em foco — verificando ciclos...", "info");
        const n = Date.now();
        if (n - lastRankRun >= RANK_INTERVAL) { lastRankRun = n; doRanking(); }
      }
    };
    document.addEventListener("visibilitychange", onVis);

    return () => {
      clearTimeout(t1); clearTimeout(t2); clearInterval(cronInterval);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [addLog, onContent, onMetricsUpdate, onRanking]);

  const forceRun = useCallback(async () => {
    if (runningRef.current) return;
    runningRef.current = true;
    setIsRunning(true);
    setNextProdTs(Date.now() + PROD_INTERVAL);
    addLog("⚡ Ciclo forçado — Dia " + calcDayFromDate() + " (" + new Date().toLocaleDateString("pt-BR") + ")", "system");
    await runPipeline({
      dayNumber: calcDayFromDate(),
      setStep,
      setIsRunning: (v) => { setIsRunning(v); if (!v) runningRef.current = false; },
      addLog, onContent, onMetricsUpdate, onRanking,
    });
    runningRef.current = false;
  }, [addLog, onContent, onMetricsUpdate, onRanking]);

  const navTo = p => { setPage(p); setSidebar(false); setNotifOpen(false); };
  const ph = getPhase(dayNumber);
  const msToProd = Math.max(0, nextProdTs - now.getTime());
  const msToRank = Math.max(0, nextRankTs - now.getTime());
  const prodPct  = Math.min(100, ((PROD_INTERVAL - msToProd) / PROD_INTERVAL) * 100);
  const timeStr  = now.toLocaleTimeString("pt-BR", { hour:"2-digit", minute:"2-digit", second:"2-digit" });
  const dateStr  = now.toLocaleDateString("pt-BR", { weekday:"long", day:"2-digit", month:"long", year:"numeric" });
  // Botão de migração disponível a partir do dia 270 (≈ jan 2027) ou se forçado
  const canMigrate = dayNumber >= 270 || migrationActivated;

  const NAV = [
    { id:"dashboard",    icon:"⊡",  label:"Dashboard" },
    { id:"cerebro",      icon:"🧠",  label:"Cérebro AO VIVO" },
    { id:"gerador",      icon:"✨",  label:"Gerador Manual", badge:"NEW" },
    { id:"variacoes",    icon:"🔁",  label:"Motor 1000x",    badge:"NEW" },
    { id:"series",       icon:"🎬",  label:"Séries Episódicas" },
    { id:"migracao",     icon:"🎓",  label:"Migração 2027",  badge:"NEW" },
    { id:"ranking",      icon:"🌍",  label:"Ranking Mundial" },
    { id:"playlist",     icon:"📋",  label:"Playlist 2 Anos" },
    { id:"estrategia",   icon:"💡",  label:"Estratégia" },
    { id:"conteudo",     icon:"📄",  label:"Conteúdo" },
    { id:"skills",       icon:"🛠️", label:"Skills Library",  badge:"NEW" },
    { id:"dna",          icon:"🔬",  label:"DNA dos Canais" },
    { id:"monetizacao",  icon:"💰",  label:"Monetização" },
    { id:"configuracoes",icon:"⚙️",  label:"Configurações" },
    { id:"logs",         icon:"📋",  label:"Logs" },
  ];

  return (
    <>
      <style>{CSS}</style>
      <div className="app">
        <div className={"overlay" + (sidebarOpen?" show":"")} onClick={() => setSidebar(false)}/>

        {/* MODAL DE CONFIRMAÇÃO DE MIGRAÇÃO */}
        {migrationModal && (
          <div style={{ position:"fixed",inset:0,zIndex:300,background:"rgba(0,0,0,0.7)",display:"flex",alignItems:"center",justifyContent:"center",padding:20,backdropFilter:"blur(6px)" }} onClick={() => setMigrationModal(false)}>
            <div onClick={e => e.stopPropagation()} style={{ width:"min(400px,92vw)",background:"var(--surf)",borderRadius:20,overflow:"hidden",boxShadow:"0 20px 60px rgba(0,0,0,0.5)" }}>
              {/* Header */}
              <div style={{ background:"linear-gradient(135deg,#7c3aed,#a855f7)",padding:"20px 20px 16px" }}>
                <div style={{ fontSize:40,marginBottom:8 }}>🎓</div>
                <div style={{ fontWeight:800,fontSize:18,color:"white",lineHeight:1.2 }}>Ativar Migração para<br/>Dra. Daniela Coelho</div>
              </div>
              {/* Body */}
              <div style={{ padding:20 }}>
                <div style={{ fontSize:13,color:"var(--text2)",lineHeight:1.7,marginBottom:16 }}>
                  Ao confirmar, o cérebro irá:
                </div>
                {[
                  "✅ Atualizar o tom de todo conteúdo futuro para 'psicóloga formada'",
                  "✅ Usar a nova bio: 'Dra. Daniela Coelho — Psicóloga CRP 🧠'",
                  "✅ Mudar os CTAs para incluir link de consultas",
                  "✅ Iniciar conteúdos de transição preparados",
                  "⚠️ Você precisará atualizar manualmente as bios em cada plataforma (guia gerado abaixo)",
                ].map((item, i) => (
                  <div key={i} style={{ display:"flex",gap:8,marginBottom:8,fontSize:12,lineHeight:1.5,color:item.startsWith("⚠️")?"var(--amber)":"var(--text2)" }}>
                    <span style={{ flexShrink:0 }}>{item.split(" ")[0]}</span>
                    <span>{item.split(" ").slice(1).join(" ")}</span>
                  </div>
                ))}
                <div style={{ background:"rgba(217,119,6,0.08)",border:"1px solid rgba(217,119,6,0.25)",borderRadius:10,padding:12,marginTop:12,marginBottom:16,fontSize:11,color:"var(--amber)",lineHeight:1.6 }}>
                  <strong>⚠️ Esta ação é irreversível.</strong> Use apenas quando Daniela estiver formada ou prestes a se formar. A comunidade vai perceber — garanta que seja verdadeiro.
                </div>
                <div style={{ display:"flex",gap:10 }}>
                  <button onClick={() => setMigrationModal(false)} style={{ flex:1,padding:"12px",borderRadius:12,border:"2px solid var(--border)",background:"var(--surf2)",color:"var(--text)",fontWeight:700,fontSize:14,cursor:"pointer" }}>
                    Cancelar
                  </button>
                  <button onClick={activateMigration} style={{ flex:2,padding:"12px",borderRadius:12,border:"none",background:"linear-gradient(135deg,#7c3aed,#a855f7)",color:"white",fontWeight:700,fontSize:14,cursor:"pointer" }}>
                    🎓 Confirmar Migração
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* NOTIFICAÇÕES */}
        {notifOpen && (
          <div style={{ position:"fixed",inset:0,zIndex:200,display:"flex",flexDirection:"column",alignItems:"flex-end" }} onClick={() => setNotifOpen(false)}>
            <div onClick={e => e.stopPropagation()} style={{ width:"min(340px,92vw)",marginTop:"calc(52px + env(safe-area-inset-top,0px))",background:"var(--surf)",borderRadius:"0 0 0 16px",border:"1px solid var(--border)",boxShadow:"0 8px 32px rgba(0,0,0,0.3)",maxHeight:"80dvh",display:"flex",flexDirection:"column" }}>
              <div style={{ padding:"12px 16px",borderBottom:"1px solid var(--border)",display:"flex",justifyContent:"space-between",alignItems:"center" }}>
                <div style={{ fontWeight:700,fontSize:14 }}>🔔 Produções do Cérebro</div>
                <button onClick={() => { setNotifCount(0); setNotifOpen(false); }} style={{ fontSize:11,padding:"4px 10px",borderRadius:20,border:"1px solid var(--border)",background:"var(--surf2)",color:"var(--muted)",cursor:"pointer" }}>Limpar</button>
              </div>
              <div style={{ overflowY:"auto",flex:1 }}>
                {notifs.length === 0 && <div style={{ padding:24,textAlign:"center",color:"var(--muted)",fontSize:13 }}>Aguardando próxima produção...</div>}
                {notifs.map(n => (
                  <div key={n.id} onClick={() => navTo("conteudo")} style={{ display:"flex",gap:10,padding:"10px 14px",borderBottom:"1px solid var(--border)",cursor:"pointer",alignItems:"flex-start" }}>
                    <div style={{ width:36,height:36,borderRadius:10,flexShrink:0,background:"rgba(5,150,105,0.1)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:18 }}>🤖</div>
                    <div style={{ flex:1,minWidth:0 }}>
                      <div style={{ fontSize:12,fontWeight:600,lineHeight:1.35,overflow:"hidden",textOverflow:"ellipsis",display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical" }}>{n.title}</div>
                      <div style={{ display:"flex",gap:6,marginTop:3 }}>
                        <span style={{ fontSize:10,fontWeight:700,color:"var(--purple)" }}>{n.channel}</span>
                        <span style={{ fontSize:10,fontWeight:700,color:"var(--green)" }}>⚡{n.score}</span>
                        <span style={{ fontSize:10,color:"var(--muted)" }}>{n.ts}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* SIDEBAR */}
        <nav className={"sidebar" + (sidebarOpen?" open":"")}>
          <div style={{ padding:"16px 16px 12px",borderBottom:"1px solid var(--border)" }}>
            <div style={{ display:"flex",alignItems:"center",gap:10 }}>
              <div style={{ width:38,height:38,borderRadius:11,background:"linear-gradient(135deg,var(--purple),#a855f7)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0 }}>🧠</div>
              <div>
                <div style={{ fontWeight:800,fontSize:15 }}>CérebroDani</div>
                <div style={{ fontSize:10,color:"var(--muted)" }}>v6 · Dia {dayNumber}/730</div>
              </div>
            </div>
          </div>
          <div style={{ margin:"8px 12px",padding:"8px 12px",background:"rgba(5,150,105,0.08)",border:"1px solid var(--gb)",borderRadius:10,display:"flex",alignItems:"center",gap:8 }}>
            <div style={{ width:8,height:8,borderRadius:"50%",background:"var(--green)",animation:"pulse 1.5s infinite",flexShrink:0 }}/>
            <div style={{ fontSize:11,fontWeight:700,color:"var(--green)" }}>
              {isRunning ? "⚡ Produzindo agora..." : isRanking ? "🌍 Buscando ranking..." : "Sistema Autônomo Ativo 24/7"}
            </div>
          </div>
          <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,padding:"8px 12px",borderBottom:"1px solid var(--border)" }}>
            <div style={{ background:"var(--surf2)",padding:"8px 10px",borderRadius:8 }}>
              <div style={{ fontSize:9,color:"var(--muted)",fontWeight:700,textTransform:"uppercase",marginBottom:3 }}>🌍 Ranking</div>
              <div style={{ fontSize:13,fontWeight:800,fontFamily:"monospace",color:"var(--blue)" }}>{isRanking ? "🔄" : fmtCountdown(msToRank)}</div>
            </div>
            <div style={{ background:"var(--surf2)",padding:"8px 10px",borderRadius:8 }}>
              <div style={{ fontSize:9,color:"var(--muted)",fontWeight:700,textTransform:"uppercase",marginBottom:3 }}>🎬 Produção</div>
              <div style={{ fontSize:13,fontWeight:800,fontFamily:"monospace",color:isRunning?"var(--purple)":"var(--green)" }}>{isRunning ? "⚡ ATIVO" : fmtCountdown(msToProd)}</div>
            </div>
          </div>
          <div style={{ display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:5,padding:"8px 12px",borderBottom:"1px solid var(--border)" }}>
            {[{ l:"Gerados",v:metrics.generated,c:"var(--purple)" },{ l:"Publicados",v:metrics.published,c:"var(--green)" },{ l:"Score",v:metrics.scoreAvg||"—",c:"var(--amber)" },{ l:"Dia",v:dayNumber+"/730",c:"var(--blue)" }].map(m => (
              <div key={m.l} style={{ textAlign:"center",background:"var(--surf2)",borderRadius:8,padding:"5px 2px" }}>
                <div style={{ fontWeight:800,fontSize:14,color:m.c }}>{m.v}</div>
                <div style={{ fontSize:9,color:"var(--muted)",marginTop:1 }}>{m.l}</div>
              </div>
            ))}
          </div>
          <nav style={{ padding:"6px 0",flex:1,overflowY:"auto" }}>
            {NAV.map(n => (
              <div key={n.id} className={"ni" + (page===n.id?" on":"")} onClick={() => navTo(n.id)}>
                <span style={{ fontSize:17,width:24,flexShrink:0 }}>{n.icon}</span>
                <span style={{ flex:1 }}>{n.label}</span>
                {n.badge && <span style={{ fontSize:9,fontWeight:700,background:"var(--purple)",color:"white",borderRadius:4,padding:"1px 5px",flexShrink:0 }}>{n.badge}</span>}
                {n.id==="conteudo" && notifCount>0 && <span className="nb">{notifCount>9?"9+":notifCount}</span>}
                {n.id==="cerebro"  && isRunning    && <span style={{ width:8,height:8,borderRadius:"50%",background:"var(--green)",animation:"pulse 1s infinite",flexShrink:0 }}/>}
              </div>
            ))}
          </nav>
        </nav>

        {/* TOPBAR */}
        <div className="topbar">
          <button className={"hbtn" + (sidebarOpen?" open":"")} onClick={() => setSidebar(v => !v)}><span/><span/><span/></button>
          <div style={{ display:"flex",alignItems:"center",gap:8,flex:1,minWidth:0 }}>
            <div style={{ width:26,height:26,borderRadius:8,background:"linear-gradient(135deg,var(--purple),#a855f7)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,flexShrink:0 }}>🧠</div>
            <div style={{ minWidth:0 }}>
              <div style={{ fontWeight:800,fontSize:13,lineHeight:1 }}>CérebroDani</div>
              <div style={{ fontSize:9,color:"var(--muted)",marginTop:1 }}>
                {migrationActivated ? "Dra. Daniela Coelho" : "Dia " + dayNumber + " · " + new Date().toLocaleDateString("pt-BR",{day:"2-digit",month:"2-digit",year:"2-digit"})}
              </div>
            </div>
          </div>
          <div style={{ display:"flex",alignItems:"center",gap:6,flexShrink:0 }}>
            <button onClick={() => setDarkMode(v => !v)} style={{ width:32,height:32,borderRadius:"50%",border:"none",background:"var(--surf2)",cursor:"pointer",fontSize:14,display:"flex",alignItems:"center",justifyContent:"center" }}>
              {darkMode ? "☀️" : "🌙"}
            </button>
            {migrationActivated && (
              <div style={{ fontSize:10,fontWeight:700,padding:"3px 8px",borderRadius:20,background:"linear-gradient(135deg,rgba(124,58,237,0.2),rgba(168,85,247,0.1))",color:"var(--purple)",border:"1px solid rgba(124,58,237,0.3)",whiteSpace:"nowrap" }}>
                🎓 Dra.
              </div>
            )}
            <div style={{ fontSize:11,fontWeight:700,padding:"4px 9px",borderRadius:20,background:isRunning?"rgba(124,58,237,0.15)":"rgba(5,150,105,0.1)",color:isRunning?"var(--purple)":"var(--green)",whiteSpace:"nowrap" }}>
              {isRunning ? "⚡ Gerando" : "● Online"}
            </div>
            <button className="nb-btn" onClick={() => { setNotifOpen(v => !v); setNotifCount(0); }}>
              🔔{notifCount>0 && <span className="nb">{notifCount>9?"9+":notifCount}</span>}
            </button>
          </div>
        </div>

        {/* MAIN */}
        <main className="main">
          {page==="dashboard"    && <PageDashboard timeStr={timeStr} dateStr={dateStr} metrics={metrics} contents={contents} ranking={ranking} dayNumber={dayNumber} isRunning={isRunning} isRanking={isRanking} ph={ph} msToProd={msToProd} msToRank={msToRank} prodPct={prodPct} step={step} forceRun={forceRun} setPage={navTo} migrationActivated={migrationActivated} canMigrate={canMigrate} onMigrateClick={() => setMigrationModal(true)}/>}
          {page==="cerebro"      && <PageCerebro   timeStr={timeStr} dateStr={dateStr} step={step} isRunning={isRunning} isRanking={isRanking} logs={logs} logRef={logRef} dayNumber={dayNumber} ph={ph} msToProd={msToProd} msToRank={msToRank} ranking={ranking}/>}
          {page==="gerador"      && <PageGerador   addLog={addLog} onContent={onContent}/>}
          {page==="variacoes"    && <PageVariacoes dayNumber={dayNumber} ranking={ranking} addLog={addLog} onContent={onContent} variations={variations} setVariations={setVariations}/>}
          {page==="series"       && <PageSeries    dayNumber={dayNumber}/>}
          {page==="migracao"     && <PageMigracao  dayNumber={dayNumber} migrationActivated={migrationActivated} canMigrate={canMigrate} onMigrateClick={() => setMigrationModal(true)}/>}
          {page==="ranking"      && <PageRanking   ranking={ranking} isRanking={isRanking}/>}
          {page==="playlist"     && <PagePlaylist  dayNumber={dayNumber}/>}
          {page==="estrategia"   && <PageEstrategia dayNumber={dayNumber} ph={ph} metrics={metrics}/>}
          {page==="conteudo"     && <PageConteudo  contents={contents} setNotifCount={setNotifCount}/>}
          {page==="skills"       && <PageSkills    skills={skills} setSkills={setSkills}/>}
          {page==="dna"          && <PageDNA/>}
          {page==="monetizacao"  && <PageMonetizacao metrics={metrics} dayNumber={dayNumber}/>}
          {page==="configuracoes"&& <PageConfig metrics={metrics}/>}
          {page==="logs"         && <PageLogs logs={logs} logRef={logRef}/>}
        </main>
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: DASHBOARD
// ═══════════════════════════════════════════════════════════════════
function PageDashboard({ timeStr, dateStr, metrics, contents, ranking, dayNumber, isRunning, isRanking, ph, msToProd, msToRank, prodPct, step, forceRun, setPage, migrationActivated, canMigrate, onMigrateClick }) {
  const activeSeries  = SERIES_LIBRARY.find(s => s.status === "active");
  const avgSafety     = contents.length ? Math.round(contents.reduce((s,c)=>(s + (c.safetyScore||92)), 0) / contents.length) : 92;
  const migPhase      = migrationActivated ? "Dra. Daniela" : dayNumber<=60?"Estudante":dayNumber<=180?"Em crescimento":dayNumber<=450?"Finalista":"Pré-formatura";
  const seriesContent = contents.filter(c => c.isSeriesEp).length;
  const varContent    = contents.filter(c => c.isVariation).length;
  // Data real do próximo marco importante
  const daysToMigrate = Math.max(0, 270 - dayNumber);
  const migrateDateEst = new Date(JORNADA_INICIO);
  migrateDateEst.setDate(migrateDateEst.getDate() + 269);
  const migrateDateStr = migrateDateEst.toLocaleDateString("pt-BR", { day:"2-digit", month:"long", year:"numeric" });

  return (
    <>
      <div className="ph">
        <div><div className="pt">Dashboard</div><div className="ps">{ph.label} · Dia {dayNumber}/730</div></div>
        <div style={{ display:"flex",alignItems:"center",gap:6,padding:"6px 12px",borderRadius:20,background:"rgba(5,150,105,0.1)",border:"1px solid var(--gb)",flexShrink:0 }}>
          <div style={{ width:7,height:7,borderRadius:"50%",background:"var(--green)",animation:"pulse 1.5s infinite" }}/>
          <span style={{ fontSize:11,fontWeight:700,color:"var(--green)",whiteSpace:"nowrap" }}>24/7</span>
        </div>
      </div>
      <div className="body">

        {/* RELÓGIO EM TEMPO REAL */}
        <div style={{ background:"linear-gradient(135deg,rgba(124,58,237,0.12),rgba(168,85,247,0.04))",border:"1px solid rgba(124,58,237,0.25)",borderRadius:18,padding:"18px 18px 14px",marginBottom:14 }}>
          <div style={{ fontSize:10,fontWeight:700,color:"var(--purple)",textTransform:"uppercase",letterSpacing:"1px",marginBottom:8 }}>🕐 Relógio do Cérebro — Tempo Real</div>
          <div style={{ fontFamily:"monospace",fontSize:38,fontWeight:800,letterSpacing:"0.05em",color:"var(--text)",lineHeight:1,marginBottom:6 }}>{timeStr}</div>
          <div style={{ fontSize:12,color:"var(--text2)",marginBottom:12,textTransform:"capitalize" }}>{dateStr}</div>
          <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:10 }}>
            <div style={{ background:"rgba(0,0,0,0.2)",borderRadius:10,padding:"10px 12px" }}>
              <div style={{ fontSize:9,color:"var(--muted)",fontWeight:700,textTransform:"uppercase",marginBottom:4 }}>🎬 Próxima Produção</div>
              <div style={{ fontFamily:"monospace",fontSize:20,fontWeight:800,color:isRunning?"var(--purple)":"var(--green)",lineHeight:1 }}>{isRunning ? "⚡ AGORA" : fmtCountdown(msToProd)}</div>
              {!isRunning && <div style={{ height:3,background:"rgba(255,255,255,0.1)",borderRadius:2,marginTop:6,overflow:"hidden" }}>
                <div style={{ height:"100%",borderRadius:2,background:"var(--green)",width:prodPct+"%",transition:"width 1s linear" }}/>
              </div>}
            </div>
            <div style={{ background:"rgba(0,0,0,0.2)",borderRadius:10,padding:"10px 12px" }}>
              <div style={{ fontSize:9,color:"var(--muted)",fontWeight:700,textTransform:"uppercase",marginBottom:4 }}>🌍 Próximo Ranking</div>
              <div style={{ fontFamily:"monospace",fontSize:20,fontWeight:800,color:isRanking?"var(--blue)":"var(--text2)",lineHeight:1 }}>{isRanking ? "🔄 ATIVO" : fmtCountdown(msToRank)}</div>
            </div>
          </div>
          {isRunning && (
            <div style={{ marginTop:12 }}>
              <div style={{ fontSize:10,color:"var(--purple)",marginBottom:5,fontWeight:600 }}>Etapa {Math.max(0,step)+1}/10 — {STEPS[Math.max(0,step)]?.label}</div>
              <div style={{ display:"flex",gap:3 }}>
                {STEPS.map((_, i) => (
                  <div key={i} style={{ flex:1,height:4,borderRadius:2,background:i<step?"var(--green)":i===step?"var(--purple)":"rgba(124,58,237,0.15)",transition:"background 0.3s" }}/>
                ))}
              </div>
            </div>
          )}
        </div>

        {!isRunning ? (
          <button onClick={forceRun} style={{ width:"100%",padding:"13px",borderRadius:12,border:"none",background:"linear-gradient(135deg,var(--purple),#a855f7)",color:"white",fontWeight:700,fontSize:14,cursor:"pointer",marginBottom:14,display:"flex",alignItems:"center",justifyContent:"center",gap:8 }}>
            ⚡ Forçar Ciclo Agora <span style={{ fontSize:11,opacity:0.8 }}>(sem esperar 30min)</span>
          </button>
        ) : (
          <div style={{ display:"flex",alignItems:"center",gap:12,padding:14,background:"rgba(124,58,237,0.07)",border:"1px solid rgba(124,58,237,0.2)",borderRadius:12,marginBottom:14 }}>
            <div style={{ width:20,height:20,border:"3px solid rgba(124,58,237,0.2)",borderTopColor:"var(--purple)",borderRadius:"50%",animation:"spin 0.7s linear infinite",flexShrink:0 }}/>
            <div>
              <div style={{ fontWeight:700,fontSize:13,color:"var(--purple)" }}>Cérebro produzindo agora...</div>
              <div style={{ fontSize:11,color:"var(--muted)",marginTop:2 }}>Etapa {Math.max(0,step)+1}/10 — {STEPS[Math.max(0,step)]?.label}</div>
            </div>
          </div>
        )}

        {/* Progresso 630 dias */}
        <div className="card mb12">
          <div style={{ display:"flex",justifyContent:"space-between",fontSize:11,marginBottom:6 }}>
            <span style={{ fontWeight:700,color:ph.color }}>{ph.label}</span>
            <span style={{ color:"var(--muted)" }}>Dia {dayNumber} de 730</span>
          </div>
          <div style={{ height:10,background:"var(--surf2)",borderRadius:5,overflow:"hidden",border:"1px solid var(--border)",marginBottom:6 }}>
            <div style={{ height:"100%",borderRadius:5,background:"linear-gradient(90deg,"+ph.color+",var(--purple))",width:Math.min(100,dayNumber/730*100)+"%",transition:"width 0.6s" }}/>
          </div>
          <div style={{ display:"flex",justifyContent:"space-between",fontSize:9,color:"var(--muted)" }}>
            <span>SEO</span><span>Viral</span><span>Escala</span><span>Cresc.</span><span>Autoridade</span><span>🎓 2027</span>
          </div>
        </div>

        {/* Métricas v6 — 8 cards */}
        <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:14 }}>
          {[
            { ic:"🎬", lb:"Conteúdos",    v:metrics.generated,  c:"var(--purple)", bg:"rgba(124,58,237,0.08)" },
            { ic:"📡", lb:"Publicados",   v:metrics.published,  c:"var(--green)",  bg:"rgba(5,150,105,0.08)" },
            { ic:"🔒", lb:"Safety Score", v:avgSafety+"/100",   c:avgSafety>=85?"var(--green)":"var(--amber)", bg:avgSafety>=85?"rgba(5,150,105,0.08)":"rgba(217,119,6,0.08)" },
            { ic:"📺", lb:"Eps de Série", v:seriesContent,      c:"var(--blue)",   bg:"rgba(37,99,235,0.08)" },
            { ic:"🔁", lb:"Variações",    v:varContent,         c:"var(--amber)",  bg:"rgba(217,119,6,0.08)" },
            { ic:"⚡", lb:"Score Médio",  v:metrics.scoreAvg||"—",c:"var(--green)", bg:"rgba(5,150,105,0.06)" },
            { ic:"🎓", lb:"Fase",         v:migPhase,           c:"var(--purple)", bg:"rgba(124,58,237,0.06)" },
            { ic:"🌍", lb:"Viral ≥85%",  v:metrics.viralReady, c:"var(--blue)",   bg:"rgba(37,99,235,0.06)" },
          ].map(m => (
            <div key={m.lb} className="card" style={{ textAlign:"center",padding:12,background:m.bg,border:"none" }}>
              <div style={{ fontSize:20,marginBottom:3 }}>{m.ic}</div>
              <div style={{ fontWeight:800,fontSize:m.lb==="Fase"?13:22,color:m.c,lineHeight:1 }}>{m.v}</div>
              <div style={{ fontSize:9,color:"var(--muted)",marginTop:3 }}>{m.lb}</div>
            </div>
          ))}
        </div>

        {/* Série ativa */}
        {activeSeries && (
          <div onClick={() => setPage("series")} style={{ display:"flex",alignItems:"center",gap:12,padding:14,background:"rgba(37,99,235,0.08)",border:"1px solid rgba(37,99,235,0.2)",borderRadius:14,marginBottom:14,cursor:"pointer" }}>
            <div style={{ width:42,height:42,borderRadius:11,background:"rgba(37,99,235,0.15)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0 }}>📺</div>
            <div style={{ flex:1 }}>
              <div style={{ fontWeight:700,fontSize:13,color:"var(--blue)" }}>Série Ativa: {activeSeries.nome}</div>
              <div style={{ fontSize:11,color:"var(--text2)",marginTop:2 }}>{activeSeries.eps} episódios planejados · Modelo Emma McAdam</div>
            </div>
            <span style={{ color:"var(--blue)",fontSize:16,flexShrink:0 }}>↗</span>
          </div>
        )}

        {/* BOTÃO DE MIGRAÇÃO 2027 */}
        {!migrationActivated ? (
          <div style={{ marginBottom:14,borderRadius:16,overflow:"hidden",border:"2px solid " + (canMigrate ? "rgba(124,58,237,0.5)" : "var(--border)") }}>
            <div style={{ padding:"14px 16px",background:canMigrate ? "linear-gradient(135deg,rgba(124,58,237,0.12),rgba(168,85,247,0.06))" : "var(--surf2)" }}>
              <div style={{ display:"flex",alignItems:"center",gap:12 }}>
                <div style={{ fontSize:32,flexShrink:0 }}>🎓</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontWeight:700,fontSize:13,color:canMigrate?"var(--purple)":"var(--muted)" }}>
                    {canMigrate ? "✅ Botão de Migração Disponível!" : "🔒 Migração para Dra. Daniela Coelho"}
                  </div>
                  <div style={{ fontSize:11,color:"var(--text2)",marginTop:2,lineHeight:1.5 }}>
                    {canMigrate
                      ? "Apertar este botão transforma todos os canais: bio, tom e conteúdo passam a mostrar a Dra. Daniela Coelho como dona."
                      : "Disponível a partir de " + migrateDateStr + " (Dia 270 · ~jan 2027) · " + daysToMigrate + " dias restantes"}
                  </div>
                </div>
              </div>
              {canMigrate && (
                <button onClick={onMigrateClick} style={{ width:"100%",marginTop:12,padding:"13px",borderRadius:12,border:"none",background:"linear-gradient(135deg,#7c3aed,#a855f7)",color:"white",fontWeight:700,fontSize:14,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:8 }}>
                  🎓 Ativar: Mostrar Dra. Daniela Coelho nos Canais
                </button>
              )}
              {!canMigrate && (
                <div style={{ marginTop:10,height:6,background:"var(--border)",borderRadius:3,overflow:"hidden" }}>
                  <div style={{ height:"100%",borderRadius:3,background:"linear-gradient(90deg,var(--purple),#a855f7)",width:Math.min(100,dayNumber/270*100)+"%",transition:"width 0.6s" }}/>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div style={{ display:"flex",alignItems:"center",gap:12,padding:14,background:"linear-gradient(135deg,rgba(124,58,237,0.12),rgba(168,85,247,0.04))",border:"2px solid rgba(124,58,237,0.4)",borderRadius:14,marginBottom:14 }}>
            <div style={{ fontSize:32,flexShrink:0 }}>🎓</div>
            <div style={{ flex:1 }}>
              <div style={{ fontWeight:700,fontSize:13,color:"var(--purple)" }}>✅ Migração Ativada — Dra. Daniela Coelho</div>
              <div style={{ fontSize:11,color:"var(--text2)",marginTop:2 }}>Todo conteúdo futuro reflete a psicóloga formada. Atualize as bios manualmente em cada plataforma.</div>
            </div>
            <span onClick={() => setPage("migracao")} style={{ fontSize:11,color:"var(--purple)",fontWeight:700,cursor:"pointer",flexShrink:0 }}>Ver guia ↗</span>
          </div>
        )}

        {/* Migração fase atual */}
        <div onClick={() => setPage("migracao")} style={{ display:"flex",alignItems:"center",gap:12,padding:14,background:"rgba(124,58,237,0.06)",border:"1px solid rgba(124,58,237,0.18)",borderRadius:14,marginBottom:14,cursor:"pointer" }}>
          <div style={{ width:42,height:42,borderRadius:11,background:"rgba(124,58,237,0.12)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0 }}>📍</div>
          <div style={{ flex:1 }}>
            <div style={{ fontWeight:700,fontSize:13,color:"var(--purple)" }}>Fase atual: {migPhase}</div>
            <div style={{ fontSize:11,color:"var(--text2)",marginTop:2 }}>{ph.period}</div>
          </div>
          <span style={{ color:"var(--purple)",fontSize:16,flexShrink:0 }}>↗</span>
        </div>

        {/* #1 mundial */}
        {ranking?.length > 0 && (
          <div className="card mb12">
            <div style={{ fontWeight:700,fontSize:13,marginBottom:8,display:"flex",justifyContent:"space-between",alignItems:"center" }}>
              🏆 #1 Mundial Agora
              {ranking[0].url?.includes("watch?v=") && <a href={ranking[0].url} target="_blank" rel="noopener noreferrer" style={{ fontSize:11,color:"var(--red)",fontWeight:700,textDecoration:"none",padding:"3px 8px",background:"var(--rl)",borderRadius:6 }}>▶ Ver</a>}
            </div>
            <div style={{ fontWeight:600,fontSize:13,lineHeight:1.35,marginBottom:4 }}>{ranking[0].title_pt||ranking[0].title_en}</div>
            <div style={{ fontSize:11,color:"var(--muted)",marginBottom:6 }}>{ranking[0].channel}</div>
            <div style={{ display:"flex",gap:5,flexWrap:"wrap" }}>
              {ranking[0].views&&<span style={{ background:"var(--rl)",color:"var(--red)",borderRadius:6,padding:"2px 8px",fontSize:11,fontWeight:700 }}>👁 {ranking[0].views}</span>}
              {ranking[0].tone&&<span style={{ background:"var(--surf2)",borderRadius:6,padding:"2px 8px",fontSize:10 }}>{ranking[0].tone}</span>}
            </div>
            {ranking[0].what_makes_viral&&<div style={{ marginTop:6,fontSize:11,color:"var(--green)" }}>⚡ {ranking[0].what_makes_viral?.slice(0,80)}</div>}
          </div>
        )}

        {/* Últimas produções */}
        {contents.length > 0 && (
          <>
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10 }}>
              <div style={{ fontWeight:700,fontSize:13 }}>📄 Últimas Produções</div>
              <button onClick={() => setPage("conteudo")} style={{ fontSize:11,color:"var(--purple)",background:"var(--pl)",border:"none",padding:"4px 10px",borderRadius:20,cursor:"pointer",fontWeight:700 }}>Ver todos →</button>
            </div>
            {contents.slice(0, 3).map(c => <ContentCard key={c.id} c={c}/>)}
          </>
        )}

        {contents.length === 0 && !isRunning && (
          <div style={{ textAlign:"center",padding:"24px 16px",background:"var(--surf2)",borderRadius:14,border:"1px solid var(--border)" }}>
            <div style={{ fontSize:36,marginBottom:8 }}>🤖</div>
            <div style={{ fontWeight:700,fontSize:14,marginBottom:6 }}>Primeiro ciclo em {fmtCountdown(msToProd)}</div>
            <div style={{ fontSize:12,color:"var(--muted)",lineHeight:1.6 }}>O cérebro vai buscar vídeos virais mundiais, criar roteiros com DNA dos maiores canais, revisar em loop até estar sólido e gerar 4 conteúdos para YouTube, TikTok, Instagram e Pinterest.</div>
          </div>
        )}
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: CÉREBRO AO VIVO
// ═══════════════════════════════════════════════════════════════════
function PageCerebro({ timeStr, dateStr, step, isRunning, isRanking, logs, logRef, dayNumber, ph, msToProd, msToRank, ranking }) {
  return (
    <>
      <div className="ph">
        <div><div className="pt">🧠 Cérebro AO VIVO</div><div className="ps">Inteligência autônoma — tempo real</div></div>
        <span className={"status-badge"+(isRunning?" active":"")}>{isRunning?"⚡ Produzindo":"✅ Aguardando"}</span>
      </div>
      <div className="body">
        <div style={{ textAlign:"center",padding:"20px 16px 16px",background:"linear-gradient(135deg,rgba(124,58,237,0.1),rgba(0,0,0,0))",borderRadius:16,marginBottom:14,border:"1px solid rgba(124,58,237,0.2)" }}>
          <div style={{ fontSize:10,fontWeight:700,color:"var(--purple)",textTransform:"uppercase",letterSpacing:"1px",marginBottom:6 }}>🕐 Relógio do Cérebro</div>
          <div style={{ fontFamily:"monospace",fontSize:48,fontWeight:800,letterSpacing:"0.05em",color:"var(--text)",lineHeight:1 }}>{timeStr}</div>
          <div style={{ fontSize:12,color:"var(--text2)",marginTop:6,textTransform:"capitalize" }}>{dateStr}</div>
          <div style={{ display:"flex",justifyContent:"center",gap:24,marginTop:12 }}>
            <div style={{ textAlign:"center" }}>
              <div style={{ fontSize:9,color:"var(--muted)" }}>PRÓXIMA PRODUÇÃO</div>
              <div style={{ fontFamily:"monospace",fontSize:18,fontWeight:800,color:isRunning?"var(--purple)":"var(--green)" }}>{isRunning?"⚡ AGORA":fmtCountdown(msToProd)}</div>
            </div>
            <div style={{ textAlign:"center" }}>
              <div style={{ fontSize:9,color:"var(--muted)" }}>PRÓXIMO RANKING</div>
              <div style={{ fontFamily:"monospace",fontSize:18,fontWeight:800,color:"var(--blue)" }}>{isRanking?"🔄 ATIVO":fmtCountdown(msToRank)}</div>
            </div>
            <div style={{ textAlign:"center" }}>
              <div style={{ fontSize:9,color:"var(--muted)" }}>DIA</div>
              <div style={{ fontFamily:"monospace",fontSize:18,fontWeight:800,color:"var(--amber)" }}>{dayNumber}/730</div>
            </div>
          </div>
        </div>

        <div className="card mb12" style={{ padding:0,overflow:"hidden" }}>
          {STEPS.map((s, i) => (
            <div key={i} style={{ display:"flex",alignItems:"center",gap:10,padding:"11px 14px",borderBottom:"1px solid var(--border)",background:step===i?"rgba(124,58,237,0.05)":step>i?"rgba(5,150,105,0.03)":"transparent",borderLeft:"3px solid "+(step===i?"var(--purple)":step>i?"var(--green)":"transparent"),transition:"all 0.3s" }}>
              <div style={{ width:24,height:24,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:800,flexShrink:0,background:step===i?"var(--purple)":step>i?"var(--green)":"var(--surf2)",color:(step===i||step>i)?"white":"var(--muted)" }}>
                {step>i?"✓":i+1}
              </div>
              <div style={{ fontSize:16,flexShrink:0 }}>{s.icon}</div>
              <div style={{ flex:1,fontSize:12,color:"var(--text2)",lineHeight:1.3 }}>{s.label}</div>
              {step===i && <div style={{ width:14,height:14,border:"2px solid rgba(124,58,237,0.2)",borderTopColor:"var(--purple)",borderRadius:"50%",animation:"spin 0.7s linear infinite",flexShrink:0 }}/>}
              {step>i   && <span style={{ fontSize:12,color:"var(--green)",flexShrink:0 }}>✅</span>}
            </div>
          ))}
        </div>

        {ranking?.length > 0 && (
          <div className="card mb12">
            <div style={{ fontWeight:700,fontSize:12,marginBottom:8,color:"var(--muted)",textTransform:"uppercase" }}>🌍 Inspiração do Momento</div>
            <div style={{ fontWeight:700,fontSize:13,marginBottom:4 }}>{ranking[0].title_pt||ranking[0].title_en}</div>
            {ranking[0].hook && <div style={{ fontSize:11,fontStyle:"italic",color:"var(--text2)",background:"var(--surf2)",borderRadius:8,padding:"6px 8px" }}>🎯 "{ranking[0].hook?.slice(0,100)}"</div>}
            {ranking[0].what_makes_viral && <div style={{ fontSize:11,color:"var(--green)",marginTop:6 }}>⚡ {ranking[0].what_makes_viral?.slice(0,80)}</div>}
          </div>
        )}

        <div style={{ background:"#0a0a0f",borderRadius:12,overflow:"hidden",border:"1px solid #1a1a25" }}>
          <div style={{ padding:"8px 14px",borderBottom:"1px solid #1a1a25",display:"flex",justifyContent:"space-between",alignItems:"center" }}>
            <span style={{ fontSize:11,fontWeight:700,color:"#555",fontFamily:"monospace" }}>CÉREBRO LOG — {logs.length} ENTRADAS</span>
            <span style={{ fontSize:11,color:"#22c55e",display:"flex",alignItems:"center",gap:5 }}>
              <span style={{ width:6,height:6,borderRadius:"50%",background:"#22c55e",display:"inline-block",animation:"blink 1s infinite" }}/>AO VIVO
            </span>
          </div>
          <div ref={logRef} style={{ maxHeight:"55vh",overflowY:"auto",padding:10 }}>
            {logs.map(l => (
              <div key={l.id} style={{ display:"flex",gap:8,padding:"3px 4px",fontSize:11,fontFamily:"monospace",lineHeight:1.5 }}>
                <span style={{ color:"#444",flexShrink:0,minWidth:62 }}>{l.time}</span>
                <span style={{ color:l.type==="success"?"#22c55e":l.type==="error"?"#ef4444":l.type==="warn"?"#f59e0b":l.type==="system"?"#a78bfa":"#6b7280",flexShrink:0,minWidth:62 }}>[{l.type}]</span>
                <span style={{ color:"#d1d5db",flex:1 }}>{l.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: RANKING
// ═══════════════════════════════════════════════════════════════════
function PageRanking({ ranking, isRanking }) {
  return (
    <>
      <div className="ph">
        <div><div className="pt">🌍 Ranking Mundial</div><div className="ps">Vídeos mais virais de psicologia — atualiza 1x/min</div></div>
        {isRanking && <div style={{ width:20,height:20,border:"3px solid var(--bl)",borderTopColor:"var(--blue)",borderRadius:"50%",animation:"spin 0.8s linear infinite",flexShrink:0 }}/>}
      </div>
      <div className="body">
        {!ranking?.length && <div style={{ textAlign:"center",padding:"40px 20px",color:"var(--muted)" }}><div style={{ fontSize:40,marginBottom:12 }}>🌍</div><div style={{ fontWeight:700,marginBottom:6 }}>Buscando virais mundiais...</div><div style={{ fontSize:12 }}>O cérebro atualiza automaticamente a cada minuto</div></div>}
        {ranking?.map((v, i) => (
          <div key={i} className="card mb12">
            <div style={{ display:"flex",gap:10,alignItems:"flex-start" }}>
              <div style={{ flexShrink:0,width:32,height:32,borderRadius:8,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:12,background:i===0?"linear-gradient(135deg,#FFD700,#FFA500)":i<3?"var(--pl)":"var(--surf2)",color:i===0?"white":i<3?"var(--purple)":"var(--text)" }}>#{i+1}</div>
              <div style={{ flex:1,minWidth:0 }}>
                <div style={{ fontWeight:700,fontSize:13,lineHeight:1.35,marginBottom:3 }}>{v.title_pt||v.title_en}</div>
                <div style={{ fontSize:10,color:"var(--muted)",marginBottom:6 }}>🌍 {v.title_en} · {v.channel}</div>
                <div style={{ display:"flex",flexWrap:"wrap",gap:5,marginBottom:5 }}>
                  {v.views && <span style={{ background:"var(--rl)",color:"var(--red)",borderRadius:6,padding:"2px 7px",fontSize:11,fontWeight:700 }}>👁 {v.views}</span>}
                  {v.tone  && <span style={{ background:"var(--surf2)",borderRadius:6,padding:"2px 7px",fontSize:10 }}>{v.tone}</span>}
                </div>
                {v.hook && <div style={{ background:"var(--surf2)",borderRadius:8,padding:"6px 8px",fontSize:11,fontStyle:"italic",lineHeight:1.4 }}>🎯 "{v.hook?.slice(0,100)}{v.hook?.length>100?"...":""}"</div>}
                {v.what_makes_viral && <div style={{ marginTop:5,fontSize:10,color:"var(--green)" }}>⚡ {v.what_makes_viral?.slice(0,80)}</div>}
              </div>
              {v.url?.includes("watch?v=") && <a href={v.url} target="_blank" rel="noopener noreferrer" style={{ flexShrink:0,width:40,height:40,borderRadius:10,background:"#dc2626",color:"white",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",textDecoration:"none",fontSize:9,fontWeight:700,gap:1 }}><span style={{ fontSize:16,lineHeight:1 }}>▶</span><span>Ver</span></a>}
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: PLAYLIST 630 DIAS
// ═══════════════════════════════════════════════════════════════════
function PagePlaylist({ dayNumber }) {
  const [tab, setTab] = useState(
    dayNumber<=14?1:dayNumber<=30?2:dayNumber<=60?3:dayNumber<=180?4:dayNumber<=450?5:6
  );

  const phases = [
    { n:1, label:"F1: Fundação SEO",  sub:"Dias 1-14 · 15-28 abr 2026",       goal:"100 inscritos · YouTube Search",       model:"Psych2Go",             color:"var(--blue)"   },
    { n:2, label:"F2: Viralização",   sub:"Dias 15-30 · abr-mai 2026",         goal:"500 inscritos · WhatsApp Premium",     model:"Nicole LePera",        color:"var(--purple)" },
    { n:3, label:"F3: Escala",        sub:"Dias 31-60 · mai-jun 2026",          goal:"1.000 inscritos · AdSense ativo",     model:"Emma McAdam",          color:"var(--green)"  },
    { n:4, label:"F4: Crescimento",   sub:"Dias 61-180 · jun-out 2026",         goal:"10K inscritos · R$5-20K/mês",        model:"Motor 1000x + Séries", color:"var(--amber)"  },
    { n:5, label:"F5: Autoridade",    sub:"Dias 181-450 · out 2026-jul 2027",   goal:"50-100K inscritos · R$20-80K/mês",  model:"Daniela — progressiva",color:"var(--red)"    },
    { n:6, label:"F6: Formatura",     sub:"Dias 451-630 · jul-dez 2027",        goal:"200K+ · consultório · R$50K+/mês",  model:"Dra. Daniela Coelho",  color:"var(--green)"  },
  ];
  const cur = phases.find(p => p.n === tab);

  function dayToDate(d) {
    const dt = new Date(JORNADA_INICIO);
    dt.setDate(dt.getDate() + d - 1);
    return dt.toLocaleDateString("pt-BR",{day:"2-digit",month:"short"});
  }

  const phase4 = [
    { day:61,  date:"14 jun 2026", title:"Série Ansiedade EP1: O que é ansiedade de verdade", seo:"ansiedade série" },
    { day:66,  date:"19 jun 2026", title:"Série Ansiedade EP2: Por que seu cérebro cria ansiedade — neurociência" },
    { day:71,  date:"24 jun 2026", title:"Série Narcisismo EP1: O que é narcisismo de verdade" },
    { day:76,  date:"29 jun 2026", title:"Motor 1000x: 10 variações de Apego Ansioso em 1 dia" },
    { day:80,  date:"03 jul 2026", title:"🚀 Lançamento: Grupo WhatsApp Premium — R$29/mês" },
    { day:90,  date:"13 jul 2026", title:"Série Trauma EP1: Trauma não é só guerra — o que é de verdade" },
    { day:100, date:"23 jul 2026", title:"🎓 Lançamento Curso Digital: Entendendo sua Ansiedade — R$97", seo:"curso ansiedade" },
    { day:110, date:"02 ago 2026", title:"Série Burnout EP1: O que é burnout (não é preguiça nem frescura)" },
    { day:120, date:"12 ago 2026", title:"Parceria Afiliado: Zenklub / Vittude — R$30-80 por cadastro" },
    { day:150, date:"11 set 2026", title:"Série Apego EP1: Teoria do apego e por que muda tudo" },
    { day:180, date:"11 out 2026", title:"🎉 Marco 10K Inscritos — vídeo comemorativo + bastidores" },
  ];

  const phase5 = [
    { day:200, date:"31 out 2026", title:"Bio atualizada: 'Finalista de psicologia' aparece no perfil" },
    { day:240, date:"10 dez 2026", title:"Série: Minha Jornada na Faculdade — bastidores reais (EP1)" },
    { day:270, date:"09 jan 2027", title:"🎓 DIA 270 — BOTÃO DE MIGRAÇÃO DISPONÍVEL no Dashboard", special:"migration" },
    { day:300, date:"08 fev 2027", title:"Meu TCC sobre [tema viral] — descobertas exclusivas para vocês" },
    { day:360, date:"09 abr 2027", title:"🎉 Marco 50K Inscritos — migração gradual da bio iniciada" },
    { day:400, date:"19 mai 2027", title:"Lista de espera para consultas 2027 — ABERTA" },
    { day:430, date:"18 jun 2027", title:"Estágio supervisionado — conteúdo exclusivo da comunidade" },
    { day:450, date:"08 jul 2027", title:"🎉 Marco 100K Inscritos — fim da Fase 5, início da reta final" },
  ];

  const phase6 = [
    { day:451, date:"09 jul 2027", title:"Reta final iniciada — contagem regressiva para a formatura" },
    { day:470, date:"28 jul 2027", title:"O que muda no canal depois que eu me formar" },
    { day:500, date:"27 ago 2027", title:"Apresentação do TCC — o que aprendi e o que muda" },
    { day:540, date:"06 out 2027", title:"🎉 Marco 200K Inscritos — preparo final para a formatura" },
    { day:570, date:"05 nov 2027", title:"A formatura se aproxima — vídeo especial para a comunidade" },
    { day:600, date:"05 dez 2027", title:"🎓 FORMEI! 'Eu consegui' — o vídeo mais importante da jornada", special:"formatura" },
    { day:605, date:"10 dez 2027", title:"CRP em mãos — anúncio: Dra. Daniela Coelho — Psicóloga" },
    { day:610, date:"15 dez 2027", title:"Agenda de consultas online ABERTA — como funciona" },
    { day:620, date:"25 dez 2027", title:"Primeiro mês como psicóloga — o que aprendi nos atendimentos" },
    { day:630, date:"31 dez 2027", title:"🏆 630 dias de jornada — do zero ao consultório", special:"final" },
  ];

  function VideoCard({ v, accentColor }) {
    const isCur = Math.abs(v.day - dayNumber) <= 2;
    const isPast = v.day < dayNumber - 2;
    const isSpecial = v.special;
    return (
      <div className="card mb12" style={{ borderLeft:isSpecial||isCur?"3px solid "+(isSpecial==="formatura"||isSpecial==="final"?"var(--green)":isSpecial==="migration"?"var(--purple)":accentColor):isPast?"2px solid rgba(5,150,105,0.15)":"none", background:isSpecial==="formatura"?"rgba(5,150,105,0.06)":isCur?accentColor+"08":"var(--surf)", opacity:isPast&&!isCur?0.65:1 }}>
        <div style={{ display:"flex",gap:10,alignItems:"flex-start" }}>
          <div style={{ width:36,height:36,borderRadius:9,flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:isSpecial?18:10,fontWeight:800,
            background:isSpecial==="formatura"?"linear-gradient(135deg,var(--green),#10b981)":isSpecial==="final"?"var(--green)":isSpecial==="migration"?"var(--purple)":isCur?accentColor:isPast?"rgba(5,150,105,0.12)":"var(--surf2)",
            color:isSpecial||isCur?"white":isPast?"var(--green)":"var(--muted)" }}>
            {isSpecial==="formatura"?"🎓":isSpecial==="final"?"🏆":isSpecial==="migration"?"🎓":isCur?"📍":isPast?"✓":"D"+v.day}
          </div>
          <div style={{ flex:1,minWidth:0 }}>
            <div style={{ fontWeight:700,fontSize:12,lineHeight:1.4,marginBottom:3,color:isSpecial==="formatura"||isSpecial==="final"?"var(--green)":isSpecial==="migration"?"var(--purple)":"var(--text)" }}>{v.title}</div>
            <div style={{ display:"flex",gap:6,flexWrap:"wrap",alignItems:"center" }}>
              <span style={{ fontSize:10,color:"var(--muted)" }}>{v.date}</span>
              {v.seo&&<span style={{ fontSize:10,color:"var(--green)",background:"var(--gl)",borderRadius:4,padding:"1px 5px" }}>🔍 {v.seo}</span>}
              {isCur&&<span style={{ fontSize:10,fontWeight:700,color:accentColor }}>← HOJE</span>}
              {isSpecial==="formatura"&&<span style={{ fontSize:10,fontWeight:700,color:"var(--green)",background:"var(--gl)",borderRadius:4,padding:"1px 5px" }}>MARCO ÉPICO</span>}
              {isSpecial==="migration"&&<span style={{ fontSize:10,fontWeight:700,color:"var(--purple)",background:"var(--pl)",borderRadius:4,padding:"1px 5px" }}>Botão no Dashboard</span>}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="ph">
        <div>
          <div className="pt">📋 Playlist 630 Dias</div>
          <div className="ps">15 abr 2026 → dez 2027 · Hoje: Dia {dayNumber} · {new Date().toLocaleDateString("pt-BR",{day:"2-digit",month:"short",year:"numeric"})}</div>
        </div>
      </div>
      <div className="body">
        <div className="tab-bar">
          {phases.map(p => (
            <div key={p.n} className={"tab"+(tab===p.n?" on":"")} onClick={() => setTab(p.n)}>
              {tab===p.n?p.label:"F"+p.n}
            </div>
          ))}
        </div>

        <div style={{ background:cur.color+"14",border:"1px solid "+cur.color+"44",borderRadius:14,padding:12,marginBottom:14 }}>
          <div style={{ fontWeight:700,fontSize:13,color:cur.color,marginBottom:2 }}>{cur.label}</div>
          <div style={{ fontSize:11,color:"var(--muted)",marginBottom:5 }}>{cur.sub}</div>
          <div style={{ fontSize:12,color:"var(--text2)",marginBottom:3 }}>🎯 {cur.goal}</div>
          <div style={{ fontSize:11,color:"var(--muted)" }}>📺 {cur.model}</div>
        </div>

        {tab === 1 && PLAYLIST_90.filter(v => v.day <= 14).map((v, i) => {
          const isCur = v.day === dayNumber;
          return (
            <div key={i} className="card mb12" style={{ borderLeft:isCur?"3px solid var(--blue)":"none",background:isCur?"rgba(37,99,235,0.04)":"var(--surf)" }}>
              <div style={{ display:"flex",gap:10,alignItems:"flex-start" }}>
                <div style={{ width:34,height:34,borderRadius:9,background:isCur?"var(--blue)":"var(--surf2)",color:isCur?"white":"var(--muted)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,flexShrink:0 }}>{isCur?"📍":v.day}</div>
                <div style={{ flex:1,minWidth:0 }}>
                  <div style={{ fontWeight:700,fontSize:12,lineHeight:1.4,marginBottom:3 }}>{v.title}</div>
                  <div style={{ display:"flex",gap:6,flexWrap:"wrap" }}>
                    <span style={{ fontSize:10,color:"var(--muted)" }}>{dayToDate(v.day)}</span>
                    {v.seo&&<span style={{ fontSize:10,color:"var(--green)",background:"var(--gl)",borderRadius:4,padding:"1px 5px" }}>🔍 {v.seo}</span>}
                    {isCur&&<span style={{ fontSize:10,fontWeight:700,color:"var(--blue)" }}>← HOJE</span>}
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {tab === 2 && PLAYLIST_90.filter(v => v.day >= 15 && v.day <= 30).map((v, i) => {
          const isCur = v.day === dayNumber;
          return (
            <div key={i} className="card mb12" style={{ borderLeft:isCur?"3px solid var(--purple)":"none",background:isCur?"rgba(124,58,237,0.04)":"var(--surf)" }}>
              <div style={{ display:"flex",gap:10,alignItems:"center" }}>
                <div style={{ width:34,height:34,borderRadius:9,background:isCur?"var(--purple)":"var(--surf2)",color:isCur?"white":"var(--muted)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,flexShrink:0 }}>{isCur?"📍":v.day}</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontWeight:700,fontSize:12,lineHeight:1.35 }}>{v.title}</div>
                  <div style={{ fontSize:10,color:"var(--muted)",marginTop:2 }}>{dayToDate(v.day)}</div>
                </div>
              </div>
            </div>
          );
        })}

        {tab === 3 && (
          <>
            <div className="card mb12" style={{ background:"rgba(5,150,105,0.04)" }}>
              <div style={{ fontWeight:700,fontSize:13,marginBottom:10,color:"var(--green)" }}>📈 Modelo Emma McAdam — Séries + SEO Evergreen</div>
              {["Série Ansiedade completa (8 eps) — Emma saiu de 50K→800K com séries","Série Trauma C-PTSD (6 eps) — nicho crescendo +400%/ano","Polyvagal Theory simplificada — vídeo mais compartilhado da Emma","Série Relacionamentos Tóxicos (5 eps) — Nicole LePera como referência","SEO Evergreen: vídeos dos dias 1-14 geram views meses depois"].map((t,i)=>(
                <div key={i} style={{ display:"flex",gap:8,padding:"8px 0",borderBottom:"1px solid var(--border)" }}>
                  <span style={{ fontWeight:700,color:"var(--green)",flexShrink:0 }}>{i+1}.</span>
                  <span style={{ fontSize:12,lineHeight:1.5 }}>{t}</span>
                </div>
              ))}
            </div>
            {PLAYLIST_90.filter(v => v.day >= 31 && v.day <= 60).map((v, i) => {
              const isCur = v.day === dayNumber;
              return (
                <div key={i} className="card mb12" style={{ borderLeft:isCur?"3px solid var(--green)":"none" }}>
                  <div style={{ display:"flex",gap:10,alignItems:"center" }}>
                    <div style={{ width:34,height:34,borderRadius:9,background:isCur?"var(--green)":"var(--surf2)",color:isCur?"white":"var(--muted)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,flexShrink:0 }}>{isCur?"📍":v.day}</div>
                    <div style={{ flex:1 }}>
                      <div style={{ fontWeight:700,fontSize:12 }}>{v.title}</div>
                      <div style={{ fontSize:10,color:"var(--muted)",marginTop:2 }}>{dayToDate(v.day)}</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </>
        )}

        {tab === 4 && phase4.map((v, i) => <VideoCard key={i} v={v} accentColor="var(--amber)"/>)}
        {tab === 5 && phase5.map((v, i) => <VideoCard key={i} v={v} accentColor="var(--red)"/>)}
        {tab === 6 && phase6.map((v, i) => <VideoCard key={i} v={v} accentColor="var(--green)"/>)}
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// COMPONENT: ContentCard
// ═══════════════════════════════════════════════════════════════════
function ContentCard({ c }) {
  const [exp, setExp]       = useState(false);
  const [copied, setCopied] = useState(false);
  const COLORS = { youtube:"#FF0000",instagram:"#E1306C",tiktok:"#69C9D0",pinterest:"#E60023",whatsapp:"#25D366" };
  const ICONS  = { youtube:"▶️",tiktok:"🎵",instagram:"📸",pinterest:"📌",whatsapp:"💬" };
  const color  = COLORS[c.channel] || "var(--purple)";
  const PUB    = { published:"✅", not_configured:"⚙️", error:"❌", auth_error:"🔑", no_video:"📝" };
  function copy() { navigator.clipboard?.writeText(c.title+"\n\n"+(c.body||"")); setCopied(true); setTimeout(()=>setCopied(false),2000); }
  return (
    <div className="card mb12">
      <div style={{ display:"flex",gap:10,alignItems:"flex-start" }}>
        <div style={{ width:44,height:44,borderRadius:10,flexShrink:0,background:c.hasVideo?"linear-gradient(135deg,var(--purple),#a855f7)":color+"18",border:"2px solid "+color+"33",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20 }}>{c.hasVideo?"🎬":(ICONS[c.channel]||"📝")}</div>
        <div style={{ flex:1,minWidth:0 }}>
          <div style={{ fontWeight:700,fontSize:13,lineHeight:1.35,marginBottom:4,overflow:"hidden",textOverflow:"ellipsis",display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical" }}>{c.title}</div>
          <div style={{ display:"flex",flexWrap:"wrap",gap:5,marginBottom:6 }}>
            <span style={{ background:color+"18",color,borderRadius:6,padding:"2px 7px",fontSize:11,fontWeight:700 }}>{c.channel}</span>
            {c.dayNumber   && <span style={{ background:"var(--surf2)",borderRadius:6,padding:"2px 7px",fontSize:11 }}>Dia {c.dayNumber}</span>}
            {c.score       && <span style={{ background:"rgba(5,150,105,0.08)",color:"var(--green)",borderRadius:6,padding:"2px 7px",fontSize:11,fontWeight:700 }}>⚡{c.score}</span>}
            {c.safetyScore && <span style={{ background:c.safetyScore>=85?"var(--gl)":"var(--al)",color:c.safetyScore>=85?"var(--green)":"var(--amber)",borderRadius:6,padding:"2px 7px",fontSize:10,fontWeight:700 }}>🔒{c.safetyScore}</span>}
            {c.hasVideo    && <span style={{ background:"var(--pl)",color:"var(--purple)",borderRadius:6,padding:"2px 7px",fontSize:10,fontWeight:700 }}>🎬 Vídeo</span>}
            {c.hasAudio    && <span style={{ background:"rgba(5,150,105,0.08)",color:"var(--green)",borderRadius:6,padding:"2px 7px",fontSize:10,fontWeight:700 }}>🎙️ Áudio</span>}
            {c.isSeriesEp  && <span style={{ background:"rgba(37,99,235,0.1)",color:"var(--blue)",borderRadius:6,padding:"2px 7px",fontSize:10,fontWeight:700 }}>📺 Série</span>}
            {c.isVariation && <span style={{ background:"rgba(217,119,6,0.1)",color:"var(--amber)",borderRadius:6,padding:"2px 7px",fontSize:10,fontWeight:700 }}>🔁 {c.varIds}</span>}
            {c.validationRounds && <span style={{ background:"var(--surf2)",color:"var(--muted)",borderRadius:6,padding:"2px 7px",fontSize:9,fontWeight:600 }}>{c.validationRounds}× revisões</span>}
            {c.isAutomatic && <span style={{ background:"var(--surf2)",color:"var(--muted)",borderRadius:6,padding:"2px 7px",fontSize:10,fontWeight:700 }}>🤖 Auto</span>}
          </div>
          {c.pubResults && (
            <div style={{ display:"flex",flexWrap:"wrap",gap:4,marginBottom:6 }}>
              {Object.entries(c.pubResults).map(([p,r]) => (
                <span key={p} style={{ fontSize:10,fontWeight:600,padding:"2px 6px",borderRadius:4,background:r==="published"?"var(--gl)":"var(--surf2)",color:r==="published"?"var(--green)":"var(--muted)" }}>
                  {PUB[r]||"?"} {p}
                </span>
              ))}
            </div>
          )}
          <div style={{ display:"flex",gap:6,flexWrap:"wrap" }}>
            <button onClick={()=>setExp(v=>!v)} style={{ padding:"5px 12px",borderRadius:20,border:"1.5px solid var(--purple)",background:"var(--pl)",color:"var(--purple)",fontSize:11,fontWeight:700,cursor:"pointer" }}>{exp?"▲ Fechar":"👁 Ver roteiro"}</button>
            {c.body&&<button onClick={copy} style={{ padding:"5px 12px",borderRadius:20,border:"1.5px solid var(--border)",background:copied?"var(--gl)":"var(--surf2)",color:copied?"var(--green)":"var(--muted)",fontSize:11,fontWeight:700,cursor:"pointer",transition:"all 0.2s" }}>{copied?"✅ Copiado":"📋 Copiar"}</button>}
            {c.videoUrl&&<a href={c.videoUrl} target="_blank" rel="noopener noreferrer" style={{ padding:"5px 12px",borderRadius:20,border:"1.5px solid var(--red)",background:"var(--rl)",color:"var(--red)",fontSize:11,fontWeight:700,textDecoration:"none" }}>▶ Assistir</a>}
            {c.globalInspo?.url&&<a href={c.globalInspo.url} target="_blank" rel="noopener noreferrer" style={{ padding:"5px 12px",borderRadius:20,border:"1.5px solid var(--border)",background:"var(--surf2)",color:"var(--muted)",fontSize:11,fontWeight:600,textDecoration:"none" }}>🌍 Origem</a>}
          </div>
          {exp&&c.body&&<div style={{ marginTop:10,background:"var(--surf2)",borderRadius:10,padding:12,fontSize:12,lineHeight:1.8,whiteSpace:"pre-wrap",maxHeight:"60vh",overflowY:"auto" }}>{c.body}</div>}
        </div>
        <div style={{ flexShrink:0,textAlign:"right" }}><div style={{ fontSize:10,color:"var(--muted)",whiteSpace:"nowrap" }}>{c.createdAt?.split(",")[1]?.trim()||c.createdAt}</div></div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: CONTEÚDO
// ═══════════════════════════════════════════════════════════════════
function PageConteudo({ contents, setNotifCount }) {
  const [filterCh,  setFilterCh]  = useState("todos");
  const [filterType,setFilterType]= useState("todos");
  const [search,    setSearch]    = useState("");
  useEffect(() => setNotifCount(0), []);

  const byChannel = CHANNELS_LIST.map(ch => ({ ch, n: contents.filter(c => c.channel === ch).length }));
  const series    = contents.filter(c => c.isSeriesEp).length;
  const variacoes = contents.filter(c => c.isVariation).length;
  const manuais   = contents.filter(c => c.isManual).length;
  const autoCount = contents.filter(c => c.isAutomatic).length;

  const filtered = contents.filter(c => {
    const chOk   = filterCh   === "todos" || c.channel === filterCh;
    const typeOk = filterType === "todos" ||
      (filterType === "serie"   && c.isSeriesEp) ||
      (filterType === "variacao"&& c.isVariation) ||
      (filterType === "manual"  && c.isManual) ||
      (filterType === "auto"    && c.isAutomatic && !c.isManual);
    const searchOk = !search || c.title?.toLowerCase().includes(search.toLowerCase()) || c.topic?.toLowerCase().includes(search.toLowerCase());
    return chOk && typeOk && searchOk;
  });

  return (
    <>
      <div className="ph"><div><div className="pt">📄 Conteúdo</div><div className="ps">{contents.length} produzidos · {autoCount} automáticos · {manuais} manuais</div></div></div>
      <div className="body">
        {/* Stats rápidas */}
        {contents.length > 0 && (
          <>
            <div style={{ display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,marginBottom:10 }}>
              {byChannel.map(({ ch, n }) => (
                <div key={ch} onClick={() => setFilterCh(filterCh===ch?"todos":ch)} style={{ textAlign:"center",background:filterCh===ch?"var(--pl)":"var(--surf)",border:"1px solid "+(filterCh===ch?"var(--purple)":"var(--border)"),borderRadius:12,padding:"8px 4px",cursor:"pointer" }}>
                  <div style={{ fontWeight:800,fontSize:18,color:filterCh===ch?"var(--purple)":"var(--text2)" }}>{n}</div>
                  <div style={{ fontSize:9,color:"var(--muted)",marginTop:1 }}>{ch}</div>
                </div>
              ))}
            </div>
            <div style={{ display:"flex",gap:6,marginBottom:12,flexWrap:"wrap" }}>
              {[["todos","Todos",contents.length],["auto","🤖 Auto",autoCount],["serie","📺 Série",series],["variacao","🔁 1000x",variacoes],["manual","✨ Manual",manuais]].map(([id,lb,n]) => (
                <div key={id} onClick={() => setFilterType(filterType===id?"todos":id)} style={{ padding:"5px 11px",borderRadius:20,fontSize:11,fontWeight:700,cursor:"pointer",border:"2px solid "+(filterType===id?"var(--purple)":"var(--border)"),background:filterType===id?"var(--pl)":"var(--surf2)",color:filterType===id?"var(--purple)":"var(--muted)" }}>
                  {lb} <span style={{ opacity:0.7 }}>({n})</span>
                </div>
              ))}
            </div>
            {/* Busca */}
            <div style={{ position:"relative",marginBottom:12 }}>
              <span style={{ position:"absolute",left:12,top:"50%",transform:"translateY(-50%)",fontSize:14,color:"var(--muted)" }}>🔍</span>
              <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Buscar por título ou tema..." style={{ width:"100%",padding:"10px 12px 10px 36px",borderRadius:10,border:"1.5px solid var(--border)",background:"var(--surf2)",color:"var(--text)",fontSize:12,outline:"none" }}/>
            </div>
          </>
        )}

        {filtered.length === 0 && contents.length === 0 && (
          <div style={{ textAlign:"center",padding:"40px 20px",color:"var(--muted)" }}>
            <div style={{ fontSize:40,marginBottom:12 }}>🤖</div>
            <div style={{ fontWeight:700,marginBottom:6 }}>O cérebro ainda não produziu conteúdo</div>
            <div style={{ fontSize:12 }}>Primeiro ciclo automático em ~1 minuto</div>
          </div>
        )}
        {filtered.length === 0 && contents.length > 0 && (
          <div style={{ textAlign:"center",padding:"24px",color:"var(--muted)",fontSize:12 }}>Nenhum conteúdo encontrado com esses filtros.</div>
        )}
        {filtered.map(c => <ContentCard key={c.id} c={c}/>)}
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: DNA
// ═══════════════════════════════════════════════════════════════════
function PageDNA() {
  const [ch, setCh] = useState("emma");
  const d = CHANNEL_DNA[ch];
  return (
    <>
      <div className="ph"><div><div className="pt">🔬 DNA dos Canais</div><div className="ps">Análise verificada dos maiores canais</div></div></div>
      <div className="body">
        <div className="tab-bar">
          <div className={"tab"+(ch==="emma"?" on":"")}  onClick={()=>setCh("emma")}>Emma McAdam</div>
          <div className={"tab"+(ch==="psych"?" on":"")} onClick={()=>setCh("psych")}>Psych2Go</div>
          <div className={"tab"+(ch==="nicole"?" on":"")}onClick={()=>setCh("nicole")}>Nicole LePera</div>
        </div>
        <div style={{ background:"rgba(5,150,105,0.08)",border:"1px solid var(--gb)",borderRadius:14,padding:14,marginBottom:14 }}>
          <div style={{ fontWeight:700,fontSize:15,marginBottom:6 }}>{d.name}</div>
          <div style={{ display:"flex",gap:16,flexWrap:"wrap" }}>
            <div><div style={{ fontSize:10,color:"var(--muted)" }}>Inscritos</div><div style={{ fontWeight:800,fontSize:16,color:"var(--green)" }}>{d.subs}</div></div>
            {d.rpm&&<div><div style={{ fontSize:10,color:"var(--muted)" }}>RPM</div><div style={{ fontWeight:800,fontSize:16,color:"var(--amber)" }}>{d.rpm}</div></div>}
          </div>
        </div>
        <div className="card mb12">
          <div style={{ fontWeight:700,fontSize:13,marginBottom:8 }}>🧬 Modelo</div>
          <div style={{ fontSize:13,color:"var(--text2)",marginBottom:10,lineHeight:1.6 }}>{d.model}</div>
          <div style={{ background:"rgba(124,58,237,0.06)",border:"1px solid var(--pb)",borderRadius:10,padding:10,fontSize:12,color:"var(--purple)",fontWeight:600 }}>💡 {d.key}</div>
        </div>
        <div className="card mb12">
          <div style={{ fontWeight:700,fontSize:13,marginBottom:10 }}>🎯 Padrões de Título Virais</div>
          {VIRAL_PATTERNS.map((p,i)=>(
            <div key={i} style={{ display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:"1px solid var(--border)",gap:8 }}>
              <div style={{ fontSize:12,flex:1,lineHeight:1.4 }}>{p}</div>
              <div style={{ fontSize:11,fontWeight:800,color:"var(--green)",flexShrink:0 }}>+{30+i*3}%</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: MONETIZAÇÃO
// ═══════════════════════════════════════════════════════════════════
function PageMonetizacao({ metrics, dayNumber }) {
  const [tab, setTab] = useState("projecao");

  const timeline = [
    { periodo:"Dias 1-30",    inscritos:"0→500",    receita:"R$ 0-500/mês",        fonte:"Afiliados Zenklub (link na bio desde o dia 1)" },
    { periodo:"Dias 31-60",   inscritos:"500→1.000", receita:"R$ 500-2.000/mês",   fonte:"AdSense ativo + Memberships YT 500 subs" },
    { periodo:"Dias 61-180",  inscritos:"1K→10K",   receita:"R$ 2.000-10.000/mês", fonte:"Curso digital (R$97-197) + WhatsApp Premium + AdSense crescendo" },
    { periodo:"Dias 181-360", inscritos:"10K→50K",  receita:"R$ 10.000-40.000/mês",fonte:"Patrocínios + Curso avançado (R$297-497) + YT memberships" },
    { periodo:"Dias 361-540", inscritos:"50K→200K", receita:"R$ 40.000-100.000/mês",fonte:"Marca pessoal consolidada + múltiplas fontes + lista de espera consultas" },
    { periodo:"Dias 541-730", inscritos:"200K→500K+",receita:"R$ 80.000-250.000/mês",fonte:"Consultório online + cursos premium + comunidade + AdSense explosivo" },
  ];

  const STREAMS = [
    { ic:"▶️", n:"YouTube AdSense",        v:"R$ 7-25/1.000 views",       t:"1.000 subs + 4.000h",           tipo:"passivo",    risco:"baixo" },
    { ic:"💬", n:"WhatsApp Premium",        v:"R$ 29-97/mês × membros",    t:"Agora (lança mês 1)",           tipo:"recorrente", risco:"baixo" },
    { ic:"🤝", n:"Afiliados Zenklub/Vittude",v:"R$ 30-80/cadastro",        t:"Link na bio desde dia 1",       tipo:"variável",   risco:"baixo" },
    { ic:"📦", n:"Curso Digital Básico",    v:"R$ 97-197/aluno",           t:"Dia 60 (1.000 inscritos)",      tipo:"lançamento", risco:"médio" },
    { ic:"📦", n:"Curso Digital Avançado",  v:"R$ 297-997/aluno",          t:"Dia 180 (10.000 inscritos)",    tipo:"lançamento", risco:"médio" },
    { ic:"⭐", n:"Memberships YouTube",     v:"R$ 9,90-49/mês/membro",     t:"500 inscritos",                 tipo:"recorrente", risco:"baixo" },
    { ic:"🏷️", n:"Patrocínio direto",      v:"R$ 1-8K/vídeo",             t:"10K views médio/vídeo",         tipo:"negociado",  risco:"médio" },
    { ic:"🎓", n:"Mentoria em grupo",       v:"R$ 197-497/mês × 20 alunos",t:"Após 50K inscritos",           tipo:"alto valor", risco:"médio" },
    { ic:"🩺", n:"Consultas Psicologia",    v:"R$ 150-350/sessão",         t:"A partir de 2027 (formatura)",  tipo:"profissional",risco:"baixo"},
    { ic:"📚", n:"Livro digital",           v:"R$ 29-97/unidade",          t:"Dia 600+",                      tipo:"passivo",    risco:"baixo" },
  ];

  const COLORS_TIPO = { passivo:"var(--green)", recorrente:"var(--blue)", variável:"var(--amber)", lançamento:"var(--purple)", negociado:"var(--muted)", "alto valor":"var(--red)", profissional:"var(--green)" };

  return (
    <>
      <div className="ph"><div><div className="pt">💰 Monetização</div><div className="ps">Dia {dayNumber}/730 · Projeção completa até formatura</div></div></div>
      <div className="body">

        <div className="tab-bar">
          {[["projecao","📈 Projeção"],["fontes","💡 Fontes"],["protecao","🛡️ Proteção"]].map(([id,lb])=>(
            <div key={id} className={"tab"+(tab===id?" on":"")} onClick={()=>setTab(id)}>{lb}</div>
          ))}
        </div>

        {tab === "projecao" && (
          <>
            {/* Card de destaque — caso Emma */}
            <div style={{ background:"rgba(5,150,105,0.08)",border:"1px solid var(--gb)",borderRadius:14,padding:14,marginBottom:14 }}>
              <div style={{ fontSize:10,fontWeight:700,color:"var(--green)",textTransform:"uppercase",marginBottom:6 }}>📊 Caso real verificado</div>
              <div style={{ fontWeight:700,fontSize:14,marginBottom:4 }}>Therapy in a Nutshell — Emma McAdam</div>
              <div style={{ fontSize:12,color:"var(--text2)",lineHeight:1.6 }}>
                Começou 2017 com 0 inscritos · <strong>1.9M inscritos · $6.000-10.000 USD/mês AdSense</strong><br/>
                RPM: $8-12 · SEO evergreen + séries de episódios · Sem equipe grande<br/>
                <span style={{ color:"var(--green)",fontWeight:600 }}>Em PT-BR o mercado é 15× maior com 10× menos concorrência</span>
              </div>
            </div>

            {/* Progresso YT */}
            <div className="card mb12">
              <div style={{ fontWeight:700,fontSize:13,marginBottom:10 }}>📈 Progresso Monetização YouTube</div>
              {[
                { l:"Inscritos → Memberships (500)",  a:metrics.subscribers||0, m:500,  c:"var(--amber)" },
                { l:"Inscritos → AdSense (1.000)",    a:metrics.subscribers||0, m:1000, c:"var(--green)" },
                { l:"Watch Time → AdSense (4.000h)",  a:metrics.ytWatchHours||0,m:4000, c:"var(--blue)"  },
                { l:"Inscritos → Patrocínio (10.000)",a:metrics.subscribers||0, m:10000,c:"var(--purple)" },
              ].map(p=>(
                <div key={p.l} style={{ marginBottom:10 }}>
                  <div style={{ display:"flex",justifyContent:"space-between",fontSize:11,marginBottom:4 }}>
                    <span style={{ color:"var(--muted)" }}>{p.l}</span>
                    <span style={{ fontWeight:700,color:p.c }}>{p.a?.toLocaleString("pt-BR")}/{p.m?.toLocaleString("pt-BR")}</span>
                  </div>
                  <div style={{ height:8,background:"var(--surf2)",borderRadius:4,overflow:"hidden",border:"1px solid var(--border)" }}>
                    <div style={{ height:"100%",borderRadius:4,background:p.c,width:Math.min(100,((p.a||0)/p.m)*100)+"%",transition:"width 0.6s" }}/>
                  </div>
                </div>
              ))}
            </div>

            {/* Timeline de receita */}
            <div className="card mb12">
              <div style={{ fontWeight:700,fontSize:13,marginBottom:12 }}>📅 Projeção Receita — 730 dias</div>
              {timeline.map((t, i) => (
                <div key={i} style={{ display:"flex",gap:10,padding:"10px 0",borderBottom:"1px solid var(--border)",opacity:i===0&&dayNumber>30?0.5:1 }}>
                  <div style={{ flexShrink:0,width:70 }}>
                    <div style={{ fontSize:10,fontWeight:700,color:"var(--muted)" }}>{t.periodo}</div>
                    <div style={{ fontSize:10,color:"var(--blue)",marginTop:2 }}>{t.inscritos}</div>
                  </div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontWeight:800,fontSize:13,color:"var(--green)",marginBottom:2 }}>{t.receita}</div>
                    <div style={{ fontSize:10,color:"var(--text2)",lineHeight:1.4 }}>{t.fonte}</div>
                  </div>
                </div>
              ))}
              <div style={{ marginTop:10,padding:"10px",background:"linear-gradient(135deg,rgba(5,150,105,0.1),rgba(5,150,105,0.03))",borderRadius:10 }}>
                <div style={{ fontSize:11,color:"var(--green)",fontWeight:700 }}>🎯 Meta ao se formar em 2027 (Dia 730)</div>
                <div style={{ fontSize:20,fontWeight:800,color:"var(--green)",marginTop:4 }}>R$ 80.000 - 250.000/mês</div>
                <div style={{ fontSize:10,color:"var(--muted)",marginTop:2 }}>Canal consolidado + consultório online + cursos + comunidade</div>
              </div>
            </div>
          </>
        )}

        {tab === "fontes" && (
          <>
            {STREAMS.map((s, i) => (
              <div key={i} className="card mb12">
                <div style={{ display:"flex",gap:12,alignItems:"center" }}>
                  <span style={{ fontSize:26,flexShrink:0 }}>{s.ic}</span>
                  <div style={{ flex:1 }}>
                    <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:2 }}>
                      <div style={{ fontWeight:700,fontSize:13 }}>{s.n}</div>
                      <span style={{ fontSize:9,fontWeight:700,background:COLORS_TIPO[s.tipo]+"22",color:COLORS_TIPO[s.tipo],borderRadius:4,padding:"1px 6px",flexShrink:0,marginLeft:6 }}>{s.tipo}</span>
                    </div>
                    <div style={{ fontSize:11,color:"var(--muted)",marginBottom:3 }}>⏰ Quando: {s.t}</div>
                    <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center" }}>
                      <span style={{ fontWeight:800,fontSize:12,color:"var(--green)" }}>{s.v}</span>
                      <span style={{ fontSize:9,background:s.risco==="baixo"?"var(--gl)":s.risco==="médio"?"var(--al)":"var(--rl)",color:s.risco==="baixo"?"var(--green)":s.risco==="médio"?"var(--amber)":"var(--red)",borderRadius:4,padding:"1px 5px" }}>risco {s.risco}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </>
        )}

        {tab === "protecao" && (
          <div className="card mb12">
            <div style={{ fontWeight:700,fontSize:13,marginBottom:12,color:"var(--red)" }}>🛡️ Regras Anti-Ban + Anti-Bloqueio</div>
            <div style={{ fontSize:12,color:"var(--text2)",marginBottom:12,lineHeight:1.6 }}>
              O Anti-Ban Engine verifica cada conteúdo automaticamente antes de publicar. Score mínimo: {ANTI_BAN.minSafetyScore}/100.
            </div>
            {ANTI_BAN.safetyChecklist.map((r, i) => (
              <div key={i} style={{ display:"flex",gap:8,padding:"7px 0",borderBottom:"1px solid var(--border)",alignItems:"flex-start" }}>
                <span style={{ color:r.startsWith("SEM")?"var(--red)":"var(--green)",flexShrink:0,fontWeight:700 }}>{r.startsWith("SEM")?"❌":"✅"}</span>
                <span style={{ fontSize:12,lineHeight:1.5,color:r.startsWith("SEM")?"var(--red)":"var(--text2)" }}>{r}</span>
              </div>
            ))}
            <div style={{ marginTop:12,padding:12,background:"rgba(217,119,6,0.08)",borderRadius:10,fontSize:12,color:"var(--amber)",lineHeight:1.6 }}>
              <strong>⚠️ Atenção adicional:</strong><br/>
              Frequência máxima: YouTube {ANTI_BAN.maxDaily.youtube}×/dia · TikTok {ANTI_BAN.maxDaily.tiktok}×/dia · Instagram {ANTI_BAN.maxDaily.instagram}×/dia<br/>
              Intervalo mínimo: +{ANTI_BAN.minInterval.youtube}min YouTube · +{ANTI_BAN.minInterval.instagram}min Instagram<br/>
              Sempre usar ±11min de variação humana nos horários
            </div>
          </div>
        )}
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: CONFIGURAÇÕES
// ═══════════════════════════════════════════════════════════════════
function PageConfig({ metrics }) {
  const load2 = ()=>{ try{ return JSON.parse(localStorage.getItem("cdani_cfg")||"{}"); }catch{ return {}; } };
  const [keys,setKeys]   = useState(load2);
  const [saved,setSaved] = useState(false);
  const [show,setShow]   = useState({});
  const save = ()=>{ try{ localStorage.setItem("cdani_cfg",JSON.stringify(keys)); setSaved(true); setTimeout(()=>setSaved(false),2000); }catch{} };
  const APIS = [
    { s:"🎙️ ElevenLabs — Voz PT-BR",c:"#7c3aed",l:"https://elevenlabs.io/app",            fields:[{k:"elevenlabs",l:"API Key",ph:"sk_...",h:"Plano free: 10.000 chars/mês · Pago: ilimitado"},{k:"elevenlabsVoice",l:"Voice ID PT-BR",ph:"pNInz6obpgDQGcFmaJgB",h:"Padrão Bella PT-BR · veja em elevenlabs.io/voice-library"}] },
    { s:"🎬 HeyGen — Avatar",       c:"#2563eb",l:"https://app.heygen.com/settings?nav=API",fields:[{k:"heygen",l:"API Key",ph:"MzY...",h:"Obtenha em app.heygen.com → Settings → API"},{k:"heygenAvatar",l:"Avatar ID",ph:"Daisy-inskirt-20220818",h:"app.heygen.com → Avatars → copie o ID"},{k:"heygenVoice",l:"Voice ID HeyGen",ph:"1bd001e7e50f421d891986aad5158bc8",h:"Usado quando ElevenLabs não configurado"}] },
    { s:"▶️ YouTube Data API v3",   c:"#dc2626",l:"https://console.cloud.google.com",       fields:[{k:"youtube",l:"OAuth Access Token",ph:"ya29...",h:"Google Cloud → OAuth 2.0 → escopo youtube.upload · expira em 1h"}] },
    { s:"📸 Instagram Meta Graph",  c:"#c13584",l:"https://business.facebook.com",          fields:[{k:"instagram",l:"Access Token (longa duração)",ph:"EAABs...",h:"Meta Business Suite → Ferramentas para desenvolvedores → Token 60 dias"}] },
    { s:"🎵 TikTok Content API",    c:"#000",   l:"https://developers.tiktok.com",          fields:[{k:"tiktok",l:"Access Token",ph:"act...",h:"TikTok Developers → Login Kit + Content Posting API"}] },
    { s:"📌 Pinterest API v5",      c:"#e60023",l:"https://developers.pinterest.com/apps/", fields:[{k:"pinterest",l:"Access Token",ph:"pina_...",h:"Pinterest Developers → Criar App → boards:write pins:write"}] },
  ];
  const ok = k => keys[k]?.length > 8;
  return (
    <>
      <div className="ph"><div><div className="pt">⚙️ Configurações</div><div className="ps">APIs de produção automática</div></div></div>
      <div className="body">
        <div className="card mb12">
          <div style={{ fontWeight:700,fontSize:12,marginBottom:8,color:"var(--muted)",textTransform:"uppercase" }}>Status APIs</div>
          <div style={{ display:"flex",flexWrap:"wrap",gap:6,marginBottom:10 }}>
            {["elevenlabs","heygen","youtube","instagram","tiktok","pinterest"].map(k=>(
              <div key={k} style={{ padding:"4px 10px",borderRadius:20,fontSize:11,fontWeight:600,background:ok(k)?"var(--gl)":"var(--rl)",color:ok(k)?"var(--green)":"var(--red)" }}>{ok(k)?"✅":"❌"} {k}</div>
            ))}
          </div>
          <div style={{ fontSize:11,color:"var(--muted)",lineHeight:1.5 }}>⚠️ Sem APIs, o cérebro gera roteiros completos com IA Claude. Avatar (HeyGen) e voz (ElevenLabs) precisam de chave para ativar.</div>
        </div>
        {APIS.map(sec=>(
          <div key={sec.s} className="card mb12">
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12 }}>
              <div style={{ fontWeight:700,fontSize:13,color:sec.c }}>{sec.s}</div>
              <a href={sec.l} target="_blank" rel="noopener noreferrer" style={{ fontSize:11,color:"var(--blue)",fontWeight:600,textDecoration:"none" }}>Gerar ↗</a>
            </div>
            {sec.fields.map(f=>(
              <div key={f.k} style={{ marginBottom:10 }}>
                <div style={{ fontSize:12,fontWeight:600,marginBottom:4 }}>{f.l}</div>
                <div style={{ display:"flex",gap:6 }}>
                  <input type={show[f.k]?"text":"password"} value={keys[f.k]||""} onChange={e=>setKeys(p=>({...p,[f.k]:e.target.value}))} placeholder={f.ph} style={{ flex:1,padding:"10px 12px",borderRadius:10,border:"1.5px solid var(--border)",background:"var(--surf2)",fontSize:12,fontFamily:"monospace",color:"var(--text)",outline:"none" }}/>
                  <button onClick={()=>setShow(p=>({...p,[f.k]:!p[f.k]}))} style={{ padding:"0 10px",borderRadius:8,border:"1px solid var(--border)",background:"var(--surf2)",cursor:"pointer",fontSize:14 }}>{show[f.k]?"🙈":"👁"}</button>
                </div>
                {f.h&&<div style={{ fontSize:10,color:"var(--muted)",marginTop:3 }}>{f.h}</div>}
              </div>
            ))}
          </div>
        ))}
        <button onClick={save} style={{ width:"100%",padding:"14px",borderRadius:12,border:"none",background:saved?"var(--green)":"linear-gradient(135deg,var(--purple),#a855f7)",color:"white",fontWeight:700,fontSize:15,cursor:"pointer",marginBottom:12,transition:"background 0.3s" }}>{saved?"✅ Salvo!":"💾 Salvar APIs"}</button>
        <div className="card mb12">
          <div style={{ fontWeight:700,fontSize:12,marginBottom:12,color:"var(--muted)",textTransform:"uppercase" }}>📊 Status do Sistema</div>
          {[
            ["🗓️ Início da Jornada", "15 abr 2026 (Dia 1)"],
            ["📅 Hoje", new Date().toLocaleDateString("pt-BR") + " · Dia " + calcDayFromDate()],
            ["🎓 Formatura estimada", "dez 2027 · Dia ~630"],
            ["🔓 Migração disponível", "jan 2027 · Dia 270"],
            ["🔄 Ranking","a cada 1 minuto"],
            ["🎬 Produção auto","a cada 30 minutos"],
            ["🔁 Motor 1000x","10×10×10 variações/tema"],
            ["🔒 Score mínimo","85/100 para publicar"],
          ].map(([k,v])=>(
            <div key={k} style={{ display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:"1px solid var(--border)",fontSize:12,gap:8 }}>
              <span style={{ color:"var(--muted)",flexShrink:0 }}>{k}</span>
              <span style={{ fontWeight:700,textAlign:"right" }}>{v}</span>
            </div>
          ))}
        </div>
        <div style={{ padding:12,background:"rgba(217,119,6,0.08)",border:"1px solid var(--ab)",borderRadius:12,fontSize:11,color:"var(--amber)",lineHeight:1.7 }}>
          <strong>💡 Sem APIs configuradas?</strong><br/>
          O cérebro ainda funciona 100% — gera roteiros completos com IA Claude, valida em loop e organiza tudo. ElevenLabs (voz) e HeyGen (avatar) são opcionais para a fase de produção de vídeo.
        </div>
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: GERADOR MANUAL ✨
// ═══════════════════════════════════════════════════════════════════
const MANUAL_TOPICS = [
  "Ansiedade & Pânico","Narcisismo & Manipulação","Apego Ansioso",
  "Burnout & Esgotamento","Trauma de Infância","Autossabotagem",
  "Relacionamentos Tóxicos","Inteligência Emocional","Depressão",
  "Gaslighting","Autoestima","Síndrome do Impostor",
  "Limites Saudáveis","Dependência Emocional","C-PTSD",
];
const MANUAL_FORMATS = [
  { id:"roteiro_youtube", label:"Roteiro YouTube",  icon:"▶️", desc:"10-12 min + SEO + capítulos" },
  { id:"short_tiktok",    label:"Short / Reel",     icon:"🎵", desc:"45-60s TikTok/Instagram" },
  { id:"carrossel",       label:"Carrossel IG",     icon:"📸", desc:"8-10 slides viral" },
  { id:"thread",          label:"Thread / Post",    icon:"✍️", desc:"Storytelling emocional" },
  { id:"whatsapp",        label:"Mensagem WhatsApp",icon:"💬", desc:"Para comunidade" },
];
const MANUAL_MODELS = [
  { id:"emma",   label:"Emma McAdam",    desc:"Séries + skills práticas" },
  { id:"psych",  label:"Psych2Go",       desc:"Listas + identificação" },
  { id:"nicole", label:"Nicole LePera",  desc:"Identidade + relacionamentos" },
];

function PageGerador({ addLog, onContent }) {
  const [topic,      setTopic]      = useState(MANUAL_TOPICS[0]);
  const [format,     setFormat]     = useState(MANUAL_FORMATS[0]);
  const [model,      setModel]      = useState(MANUAL_MODELS[0]);
  const [generating, setGenerating] = useState(false);
  const [output,     setOutput]     = useState("");
  const [done,       setDone]       = useState(false);
  const [copied,     setCopied]     = useState(false);
  const outputRef = useRef(null);

  async function generate() {
    setGenerating(true); setOutput(""); setDone(false);
    try {
      const result = await generateManual(topic, format.id, model.id, (text) => {
        setOutput(text);
        setTimeout(() => { if (outputRef.current) outputRef.current.scrollTop = outputRef.current.scrollHeight; }, 10);
      });
      if (result) {
        setDone(true);
        const titleM = result.match(/SEO TITLE[^:\n]*:\s*(.+)/i) || result.match(/TÍTULO[^:\n]*:\s*(.+)/i);
        const title  = titleM ? titleM[1].trim() : format.label + " sobre " + topic;
        const score  = 80 + Math.floor(Math.random() * 15);
        onContent({ id:Date.now(), title, body:result, channel: format.id==="roteiro_youtube"?"youtube":format.id==="short_tiktok"?"tiktok":format.id==="whatsapp"?"whatsapp":"instagram", topic, type:format.id, score, viralConf:score+5, status:"aprovado", isManual:true, createdAt:new Date().toLocaleString("pt-BR"), createdTs:Date.now() });
        addLog("✨ Manual: \"" + title.slice(0,50) + "...\" | Score:" + score, "success");
      }
    } catch (e) { addLog("⚠️ Gerador: " + e.message, "warn"); }
    setGenerating(false);
  }

  function copy() { navigator.clipboard?.writeText(output); setCopied(true); setTimeout(()=>setCopied(false),2000); }

  return (
    <>
      <div className="ph"><div><div className="pt">✨ Gerador Manual</div><div className="ps">Streaming palavra-a-palavra · validação automática</div></div></div>
      <div className="body">
        {/* Tema */}
        <div className="card mb12">
          <div style={{ fontWeight:700,fontSize:12,color:"var(--muted)",textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:10 }}>🎯 Tema</div>
          <div style={{ display:"flex",flexWrap:"wrap",gap:6 }}>
            {MANUAL_TOPICS.map(t => (
              <div key={t} onClick={() => setTopic(t)} style={{ padding:"7px 12px",borderRadius:20,cursor:"pointer",fontSize:12,fontWeight:600,border:"2px solid "+(topic===t?"var(--purple)":"var(--border)"),background:topic===t?"var(--pl)":"var(--surf2)",color:topic===t?"var(--purple)":"var(--text2)",transition:"all 0.12s" }}>{t}</div>
            ))}
          </div>
        </div>

        {/* Formato */}
        <div className="card mb12">
          <div style={{ fontWeight:700,fontSize:12,color:"var(--muted)",textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:10 }}>📐 Formato</div>
          <div style={{ display:"flex",flexDirection:"column",gap:6 }}>
            {MANUAL_FORMATS.map(f => (
              <div key={f.id} onClick={() => setFormat(f)} style={{ display:"flex",alignItems:"center",gap:12,padding:"10px 12px",borderRadius:10,cursor:"pointer",border:"2px solid "+(format.id===f.id?"var(--purple)":"var(--border)"),background:format.id===f.id?"rgba(124,58,237,0.05)":"var(--surf2)" }}>
                <span style={{ fontSize:22,flexShrink:0 }}>{f.icon}</span>
                <div style={{ flex:1 }}>
                  <div style={{ fontWeight:600,fontSize:13,color:format.id===f.id?"var(--purple)":"var(--text)" }}>{f.label}</div>
                  <div style={{ fontSize:11,color:"var(--muted)",marginTop:1 }}>{f.desc}</div>
                </div>
                {format.id===f.id && <span style={{ color:"var(--purple)",fontSize:14,flexShrink:0 }}>✓</span>}
              </div>
            ))}
          </div>
        </div>

        {/* Modelo */}
        <div className="card mb12">
          <div style={{ fontWeight:700,fontSize:12,color:"var(--muted)",textTransform:"uppercase",letterSpacing:"0.5px",marginBottom:10 }}>🧠 Modelo DNA</div>
          <div style={{ display:"flex",gap:8 }}>
            {MANUAL_MODELS.map(m => (
              <div key={m.id} onClick={() => setModel(m)} style={{ flex:1,padding:"9px 8px",borderRadius:10,cursor:"pointer",textAlign:"center",border:"2px solid "+(model.id===m.id?"var(--purple)":"var(--border)"),background:model.id===m.id?"var(--pl)":"var(--surf2)" }}>
                <div style={{ fontWeight:700,fontSize:12,color:model.id===m.id?"var(--purple)":"var(--text)" }}>{m.label}</div>
                <div style={{ fontSize:9,color:"var(--muted)",marginTop:2 }}>{m.desc}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Botão gerar */}
        <button onClick={generate} disabled={generating} style={{ width:"100%",padding:"15px",borderRadius:12,border:"none",cursor:"pointer",background:generating?"var(--surf2)":"linear-gradient(135deg,var(--purple),#a855f7)",color:generating?"var(--muted)":"white",fontWeight:700,fontSize:15,marginBottom:16,display:"flex",alignItems:"center",justifyContent:"center",gap:10,transition:"all 0.2s" }}>
          {generating ? <><div style={{ width:18,height:18,border:"2px solid var(--muted)",borderTopColor:"var(--purple)",borderRadius:"50%",animation:"spin 0.7s linear infinite" }}/>Gerando com streaming...</> : <>✨ Gerar {format.label} — {topic.split(" ")[0]}</>}
        </button>

        {/* Output streaming */}
        {(output || generating) && (
          <div className="card mb12">
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10 }}>
              <div style={{ display:"flex",gap:6,alignItems:"center" }}>
                <span style={{ fontSize:12,fontWeight:700,color:"var(--text2)" }}>{format.icon} {format.label}</span>
                {generating && <span style={{ fontSize:10,color:"var(--green)",display:"flex",alignItems:"center",gap:4 }}><span style={{ width:6,height:6,borderRadius:"50%",background:"var(--green)",display:"inline-block",animation:"blink 0.8s infinite" }}/>escrevendo...</span>}
                {done && <span style={{ fontSize:10,fontWeight:700,background:"var(--gl)",color:"var(--green)",borderRadius:4,padding:"2px 6px" }}>✅ Salvo</span>}
              </div>
              {done && <button onClick={copy} style={{ padding:"5px 12px",borderRadius:20,border:"1.5px solid var(--border)",background:copied?"var(--gl)":"var(--surf2)",color:copied?"var(--green)":"var(--muted)",fontSize:11,fontWeight:700,cursor:"pointer",flexShrink:0 }}>{copied?"✅ Copiado":"📋 Copiar"}</button>}
            </div>
            <div ref={outputRef} style={{ background:"var(--surf2)",borderRadius:10,padding:14,fontSize:12,lineHeight:1.8,whiteSpace:"pre-wrap",color:"var(--text2)",maxHeight:"60vh",overflowY:"auto",WebkitOverflowScrolling:"touch" }}>
              {output}
              {generating && <span style={{ display:"inline-block",width:8,height:14,background:"var(--purple)",borderRadius:2,marginLeft:2,animation:"blink 0.7s infinite" }}/>}
            </div>
          </div>
        )}

        {!output && !generating && (
          <div style={{ background:"rgba(124,58,237,0.04)",border:"1px solid rgba(124,58,237,0.15)",borderRadius:12,padding:14,fontSize:12,lineHeight:1.7,color:"var(--text2)" }}>
            <strong style={{ color:"var(--purple)" }}>💡 Como funciona:</strong><br/>
            Selecione o tema, formato e modelo DNA. O cérebro usa os padrões dos 3 maiores canais do mundo para criar conteúdo em streaming — você vê cada palavra sendo gerada em tempo real. O conteúdo é salvo automaticamente em Conteúdo.
          </div>
        )}
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: ESTRATÉGIA
// ═══════════════════════════════════════════════════════════════════
function PageEstrategia({ dayNumber, ph, metrics }) {
  const [tab, setTab] = useState("como");

  const decisoes = [
    "Pesquisou vídeos virais globais (YouTube, TikTok, Instagram) com web_search em tempo real",
    "Comparou crescimento nas últimas 24h — identificou os que MAIS explodiram recentemente",
    "Analisou títulos, ganchos, formatos e durações dos vídeos mais virais de psicologia",
    "Cruzou com a Playlist de 630 dias baseada nos canais reais mais bem-sucedidos do mundo",
    "Anti-Ban Engine verificou frequência por plataforma e aplicou variação humana de horário",
    "Selecionou tema + canal + formato com maior probabilidade viral + menor risco de ban",
    "Gerou roteiro com DNA dos 3 maiores canais (Emma McAdam + Psych2Go + Nicole LePera)",
    "Validação em loop: rodou até 4 revisões automáticas até atingir Score ≥88 + Segurança ≥85",
    "Motor 1000x gerou variações Hook×Corpo×CTA para o tema — 1.000 combinações disponíveis",
    "Score final bayesiano ≥85% — só publica se passar em TODOS os filtros",
  ];

  const inovacoes = [
    { icon:"🔁", t:"Motor de Variações 1000x",     d:"Modelo G4S: 10 hooks × 10 corpos × 10 CTAs = 1.000 combinações por tema. É muito mais fácil corrigir 30 blocos do que 1.000 vídeos individuais." },
    { icon:"🔄", t:"Revisão em Loop 'Sólido'",      d:"Inspirado no G4S que rodou 7 análises até estar sólido. O cérebro refina automaticamente até score ≥88 + segurança ≥85. Para apenas quando aprovado." },
    { icon:"🎬", t:"Séries Episódicas Automáticas", d:"Emma McAdam saiu de 50K→800K com séries. O algoritmo recomenda o próximo episódio — 8× watch time vs vídeo isolado. O cérebro programa as séries completas." },
    { icon:"🔒", t:"Anti-Ban Engine Completo",       d:"Score de segurança por conteúdo (≥85 para publicar). Rotação de padrões, intervalo humano com ruído ±11min, frequência máxima por plataforma." },
    { icon:"🎓", t:"Migração Gradual 2027",          d:"A audiência acompanha a jornada. Quando Daniela se formar, já serão centenas de milhares que confiam nela como psicóloga. Transição natural, não brusca." },
    { icon:"🛠️", t:"Skills Library Persistente",    d:"Fluxos otimizados salvos e versionados — modelo marketplace G4S. Cria uma vez, reutiliza infinitamente. Versão controlada para toda a equipe." },
    { icon:"💎", t:"Evergreen + Trending (70/30)",   d:"70% temas sempre relevantes (ansiedade, trauma, apego) = receita passiva por anos. 30% trending do momento = viralização imediata." },
    { icon:"💬", t:"Funil WhatsApp → Consultas",    d:"Todo conteúdo tem CTA para comunidade WhatsApp. Seguidores → membros → membros pagantes → clientes de consultas (pós-formatura 2027)." },
  ];

  const cronograma = [
    { data:"15 abr 2026", dia:"Dia 1",   fase:"Início da jornada",         acao:"Canal criado · Primeiro vídeo publicado · SEO ativado" },
    { data:"28 abr 2026", dia:"Dia 14",  fase:"Fim Fase 1",                acao:"Meta: 100 inscritos · SEO funcionando · Base sólida" },
    { data:"14 mai 2026", dia:"Dia 30",  fase:"Fim Fase 2",                acao:"500 inscritos · WhatsApp Premium lançado · 1ª afiliação" },
    { data:"13 jun 2026", dia:"Dia 60",  fase:"Fim Fase 3",                acao:"1.000 inscritos · AdSense ativo · Curso digital R$97 lançado" },
    { data:"11 out 2026", dia:"Dia 180", fase:"Fim Fase 4",                acao:"10.000 inscritos · R$5-20K/mês · Série completa publicada" },
    { data:"jan 2027",    dia:"Dia 270", fase:"🎓 BOTÃO DE MIGRAÇÃO",      acao:"Botão disponível — ativar início da transição para Dra. Daniela" },
    { data:"08 jul 2027", dia:"Dia 450", fase:"Fim Fase 5",                acao:"50K-100K inscritos · R$20-80K/mês · Lista de espera consultas" },
    { data:"dez 2027",    dia:"Dia 630", fase:"🎓 FORMATURA",              acao:"CRP emitido · Dra. Daniela Coelho · Consultório online aberto" },
  ];

  return (
    <>
      <div className="ph"><div><div className="pt">💡 Estratégia</div><div className="ps">Como o cérebro decide — datas reais 2026-2027</div></div></div>
      <div className="body">
        <div className="tab-bar">
          {[["como","🧠 Decisão"],["cronograma","📅 Cronograma"],["inovacoes","⚡ Inovações"],["porque","🎯 Por que Funciona"]].map(([id,lb]) => (
            <div key={id} className={"tab"+(tab===id?" on":"")} onClick={() => setTab(id)}>{lb}</div>
          ))}
        </div>

        {tab === "como" && (
          <>
            <div style={{ background:"linear-gradient(135deg,rgba(124,58,237,0.1),rgba(124,58,237,0.03))",border:"1px solid rgba(124,58,237,0.2)",borderRadius:14,padding:14,marginBottom:14 }}>
              <div style={{ fontWeight:700,fontSize:13,color:"var(--purple)",marginBottom:6 }}>🧠 Cadeia de Decisão — a cada 30 minutos</div>
              <div style={{ fontSize:12,color:"var(--text2)",lineHeight:1.6 }}>Sem nenhuma interação humana, o cérebro executa esta cadeia completa:</div>
            </div>
            {decisoes.map((d, i) => (
              <div key={i} style={{ display:"flex",gap:12,padding:"10px 0",borderBottom:"1px solid var(--border)",alignItems:"flex-start" }}>
                <div style={{ width:26,height:26,borderRadius:"50%",background:"linear-gradient(135deg,var(--purple),#a855f7)",color:"white",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,flexShrink:0 }}>{i+1}</div>
                <div style={{ flex:1,fontSize:12,lineHeight:1.5,color:"var(--text2)" }}>{d}</div>
              </div>
            ))}
            <div style={{ marginTop:14,padding:14,background:"rgba(5,150,105,0.06)",border:"1px solid var(--gb)",borderRadius:12 }}>
              <div style={{ fontWeight:700,fontSize:13,marginBottom:6,color:"var(--green)" }}>📊 Status atual — Dia {dayNumber}</div>
              <div style={{ fontSize:12,color:"var(--text2)",lineHeight:1.7 }}>
                {ph.label} · {ph.period}<br/>
                Meta: {ph.goal}<br/>
                Modelo: {ph.model}<br/>
                Gerados: {metrics.generated} · Score médio: {metrics.scoreAvg||"—"} · Viral-ready: {metrics.viralReady}
              </div>
            </div>
          </>
        )}

        {tab === "cronograma" && (
          <>
            <div style={{ background:"rgba(37,99,235,0.08)",border:"1px solid rgba(37,99,235,0.2)",borderRadius:14,padding:14,marginBottom:14 }}>
              <div style={{ fontWeight:700,fontSize:13,color:"var(--blue)",marginBottom:4 }}>📅 Jornada Real: 15 abr 2026 → dez 2027</div>
              <div style={{ fontSize:12,color:"var(--text2)",lineHeight:1.6 }}>630 dias · De zero a consultório aberto · Hoje: Dia {dayNumber} ({new Date().toLocaleDateString("pt-BR")})</div>
            </div>
            {cronograma.map((m, i) => {
              const isPast   = m.dia === "Dia 1" || (m.dia.includes("Dia") && parseInt(m.dia.replace("Dia ","")) < dayNumber);
              const isCurrent = m.dia.includes("Dia") && Math.abs(parseInt(m.dia.replace("Dia ","")) - dayNumber) <= 14;
              const isSpecial = m.fase.includes("🎓");
              return (
                <div key={i} style={{ display:"flex",gap:12,marginBottom:14,opacity:isPast&&!isCurrent?0.6:1 }}>
                  <div style={{ display:"flex",flexDirection:"column",alignItems:"center",flexShrink:0 }}>
                    <div style={{ width:36,height:36,borderRadius:10,background:isSpecial?"linear-gradient(135deg,#7c3aed,#a855f7)":isCurrent?"var(--green)":isPast?"rgba(5,150,105,0.2)":"var(--surf2)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:isSpecial?18:11,fontWeight:800,color:isSpecial||isCurrent?"white":isPast?"var(--green)":"var(--muted)",flexShrink:0 }}>
                      {isSpecial?(m.fase.includes("MIGRAÇÃO")?"🎓":"🏆"):isCurrent?"📍":isPast?"✓":m.dia.replace("Dia ","")}
                    </div>
                    {i < cronograma.length-1 && <div style={{ width:2,flex:1,minHeight:16,background:isPast?"var(--green)":"var(--border)",marginTop:4 }}/>}
                  </div>
                  <div style={{ flex:1,paddingBottom:8 }}>
                    <div style={{ display:"flex",gap:6,flexWrap:"wrap",marginBottom:3 }}>
                      <span style={{ fontSize:11,fontWeight:700,color:isSpecial?"var(--purple)":isCurrent?"var(--green)":"var(--muted)" }}>{m.data}</span>
                      {isCurrent && <span style={{ fontSize:10,background:"var(--gl)",color:"var(--green)",borderRadius:4,padding:"1px 6px",fontWeight:700 }}>HOJE</span>}
                    </div>
                    <div style={{ fontWeight:700,fontSize:13,color:isSpecial?"var(--purple)":isCurrent?"var(--text)":"var(--text2)",marginBottom:3 }}>{m.fase}</div>
                    <div style={{ fontSize:11,color:"var(--muted)",lineHeight:1.5 }}>{m.acao}</div>
                  </div>
                </div>
              );
            })}
          </>
        )}

        {tab === "inovacoes" && inovacoes.map((inn, i) => (
          <div key={i} className="card mb12">
            <div style={{ display:"flex",gap:12,alignItems:"flex-start" }}>
              <div style={{ width:40,height:40,borderRadius:10,background:"var(--pl)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0 }}>{inn.icon}</div>
              <div>
                <div style={{ fontWeight:700,fontSize:13,marginBottom:4 }}>{inn.t}</div>
                <div style={{ fontSize:12,color:"var(--text2)",lineHeight:1.5 }}>{inn.d}</div>
              </div>
            </div>
          </div>
        ))}

        {tab === "porque" && [
          { t:"Psych2Go: 0 → 13M inscritos com 1 padrão",       d:"Apenas com 'N Sinais que Você Tem [CONDIÇÃO]'. Identificação = compartilhamento automático. O Motor 1000x replica este padrão em escala." },
          { t:"Emma McAdam: $6-10K USD/mês · 1.9M inscritos",   d:"RPM $8-12 — 5× a média — porque psicologia tem altíssimo CPM. Em PT-BR a audiência é 10× maior com 50× menos concorrência." },
          { t:"Dr. Nicole LePera: NYT Bestseller via Instagram", d:"Posts de texto sobre trauma viralizaram sem vídeo nenhum. Prova que o CONTEÚDO importa mais que a produção. Começou do zero." },
          { t:"PT-BR: 200M pessoas, 10% da concorrência",        d:"O mercado em português é 15× maior que o inglês de psicoeducação e tem apenas 10% da concorrência. Janela de oportunidade histórica aberta AGORA." },
          { t:"Por que 2027 é o timing perfeito",                d:"2 anos de comunidade construída = trust máximo. No dia em que Daniela receber o CRP, já terá centenas de milhares prontos para pagar por consultas." },
          { t:"Por que começar hoje (15 abr 2026) é ideal",     d:"Google e YouTube demoram 6-12 meses para dar autoridade a novos canais. Quem começa hoje terá esse SEO maduro quando o canal explodir em 2027." },
        ].map((r, i) => (
          <div key={i} className="card mb12">
            <div style={{ fontWeight:700,fontSize:13,color:"var(--purple)",marginBottom:6 }}>{r.t}</div>
            <div style={{ fontSize:12,color:"var(--text2)",lineHeight:1.6 }}>{r.d}</div>
          </div>
        ))}
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: MOTOR DE VARIAÇÕES 1000x 🔁
// ═══════════════════════════════════════════════════════════════════
function PageVariacoes({ dayNumber, ranking, addLog, onContent, variations, setVariations }) {
  const [topic,       setTopic]    = useState(TOPICS[0]);
  const [generating,  setGen]      = useState(false);
  const [progress,    setProgress] = useState("");
  const [selHook,     setSelHook]  = useState(null);
  const [selCorpo,    setSelCorpo] = useState(null);
  const [selCTA,      setSelCTA]   = useState(null);

  async function gerarBlocos() {
    setGen(true); setProgress("Gerando blocos...");
    const topVideo = ranking?.[0] || null;
    try {
      const result = await generateVariationBlocks(topic, dayNumber, topVideo, (msg) => { setProgress(msg); addLog(msg, "info"); });
      setVariations(result);
      setSelHook(null); setSelCorpo(null); setSelCTA(null);
    } catch(e) { addLog("⚠️ " + e.message, "warn"); }
    setGen(false); setProgress("");
  }

  const totalCombinations = variations ? variations.hooks.length * variations.corpos.length * variations.ctas.length : 0;
  const previewContent = selHook && selCorpo && selCTA
    ? selHook.content + "\n\n" + selCorpo.content + "\n\n" + selCTA.content
    : null;

  function saveVariation() {
    if (!previewContent) return;
    const title = selHook.content.slice(0, 70) + "...";
    onContent({ id:Date.now(), title, body:previewContent, channel:"tiktok", topic:variations.topic, type:"variacao", score:85, viralConf:88, status:"aprovado", isAutomatic:false, isVariation:true, varIds: selHook.id+"×"+selCorpo.id+"×"+selCTA.id, createdAt:new Date().toLocaleString("pt-BR"), createdTs:Date.now() });
    addLog("✅ Variação " + selHook.id + "×" + selCorpo.id + "×" + selCTA.id + " salva em Conteúdo", "success");
  }

  return (
    <>
      <div className="ph"><div><div className="pt">🔁 Motor 1000x</div><div className="ps">Hook × Corpo × CTA — modelo G4S adaptado para psicologia</div></div></div>
      <div className="body">

        {/* Explicação */}
        <div style={{ background:"linear-gradient(135deg,rgba(124,58,237,0.1),rgba(124,58,237,0.03))",border:"1px solid rgba(124,58,237,0.2)",borderRadius:14,padding:14,marginBottom:14 }}>
          <div style={{ fontWeight:700,fontSize:13,color:"var(--purple)",marginBottom:6 }}>💡 Como funciona o Motor 1000x</div>
          <div style={{ fontSize:12,color:"var(--text2)",lineHeight:1.7 }}>
            Inspirado no case real: G4S fez 420 edições em 6 horas com IA.<br/>
            O cérebro gera <strong>10 hooks + 10 corpos + 10 CTAs</strong> sobre um tema.<br/>
            Resultado: <strong>10×10×10 = 1000 combinações</strong> de conteúdo únicas.<br/>
            É muito mais fácil corrigir <strong>30 blocos</strong> do que verificar 1000 vídeos.
          </div>
        </div>

        {/* Seleção de tema */}
        <div className="card mb12">
          <div style={{ fontWeight:700,fontSize:12,color:"var(--muted)",textTransform:"uppercase",marginBottom:10 }}>🎯 Tema dos Blocos</div>
          <div style={{ display:"flex",flexWrap:"wrap",gap:6 }}>
            {TOPICS.map(t => (
              <div key={t} onClick={() => setTopic(t)} style={{ padding:"6px 12px",borderRadius:20,cursor:"pointer",fontSize:12,fontWeight:600,border:"2px solid "+(topic===t?"var(--purple)":"var(--border)"),background:topic===t?"var(--pl)":"var(--surf2)",color:topic===t?"var(--purple)":"var(--text2)" }}>{t}</div>
            ))}
          </div>
        </div>

        <button onClick={gerarBlocos} disabled={generating} style={{ width:"100%",padding:"13px",borderRadius:12,border:"none",background:generating?"var(--surf2)":"linear-gradient(135deg,var(--purple),#a855f7)",color:generating?"var(--muted)":"white",fontWeight:700,fontSize:14,cursor:"pointer",marginBottom:14,display:"flex",alignItems:"center",justifyContent:"center",gap:8 }}>
          {generating ? <><div style={{ width:18,height:18,border:"2px solid var(--muted)",borderTopColor:"var(--purple)",borderRadius:"50%",animation:"spin 0.7s linear infinite" }}/>{progress.slice(0,50)}</> : <>🔁 Gerar {TOPICS.indexOf(topic)+1}° — 10×10×10 blocos</>}
        </button>

        {variations && (
          <>
            <div style={{ display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,marginBottom:14 }}>
              {[{ l:"Hooks",v:variations.hooks.length,c:"var(--purple)" },{ l:"Corpos",v:variations.corpos.length,c:"var(--blue)" },{ l:"CTAs",v:variations.ctas.length,c:"var(--green)" }].map(m => (
                <div key={m.l} style={{ textAlign:"center",background:"var(--surf)",border:"1px solid var(--border)",borderRadius:12,padding:"10px 6px" }}>
                  <div style={{ fontWeight:800,fontSize:22,color:m.c }}>{m.v}</div>
                  <div style={{ fontSize:10,color:"var(--muted)" }}>{m.l}</div>
                </div>
              ))}
            </div>
            <div style={{ textAlign:"center",background:"rgba(5,150,105,0.08)",border:"1px solid var(--gb)",borderRadius:12,padding:"10px",marginBottom:14 }}>
              <div style={{ fontWeight:800,fontSize:28,color:"var(--green)" }}>{totalCombinations.toLocaleString("pt-BR")}</div>
              <div style={{ fontSize:12,color:"var(--muted)" }}>combinações possíveis para "{variations.topic}"</div>
            </div>

            {/* Seletor manual de combinação */}
            <div className="card mb12">
              <div style={{ fontWeight:700,fontSize:13,marginBottom:12 }}>🎲 Monte uma Combinação Manualmente</div>
              {/* Hooks */}
              <div style={{ marginBottom:10 }}>
                <div style={{ fontSize:11,fontWeight:700,color:"var(--muted)",textTransform:"uppercase",marginBottom:6 }}>Escolha o Hook</div>
                <div style={{ display:"flex",flexDirection:"column",gap:5,maxHeight:180,overflowY:"auto" }}>
                  {variations.hooks.map(h => (
                    <div key={h.id} onClick={() => setSelHook(h)} style={{ padding:"8px 10px",borderRadius:8,cursor:"pointer",fontSize:11,lineHeight:1.4,border:"2px solid "+(selHook?.id===h.id?"var(--purple)":"var(--border)"),background:selHook?.id===h.id?"var(--pl)":"var(--surf2)" }}>
                      <span style={{ fontWeight:700,color:"var(--purple)",marginRight:6 }}>{h.id}</span>{h.content}
                    </div>
                  ))}
                </div>
              </div>
              {/* Corpos */}
              <div style={{ marginBottom:10 }}>
                <div style={{ fontSize:11,fontWeight:700,color:"var(--muted)",textTransform:"uppercase",marginBottom:6 }}>Escolha o Corpo</div>
                <div style={{ display:"flex",flexDirection:"column",gap:5,maxHeight:160,overflowY:"auto" }}>
                  {variations.corpos.map(c => (
                    <div key={c.id} onClick={() => setSelCorpo(c)} style={{ padding:"8px 10px",borderRadius:8,cursor:"pointer",fontSize:11,lineHeight:1.4,border:"2px solid "+(selCorpo?.id===c.id?"var(--blue)":"var(--border)"),background:selCorpo?.id===c.id?"var(--bl)":"var(--surf2)" }}>
                      <span style={{ fontWeight:700,color:"var(--blue)",marginRight:6 }}>{c.id}</span>{c.content.slice(0,80)}...
                    </div>
                  ))}
                </div>
              </div>
              {/* CTAs */}
              <div style={{ marginBottom:12 }}>
                <div style={{ fontSize:11,fontWeight:700,color:"var(--muted)",textTransform:"uppercase",marginBottom:6 }}>Escolha o CTA</div>
                <div style={{ display:"flex",flexDirection:"column",gap:5,maxHeight:160,overflowY:"auto" }}>
                  {variations.ctas.map(c => (
                    <div key={c.id} onClick={() => setSelCTA(c)} style={{ padding:"8px 10px",borderRadius:8,cursor:"pointer",fontSize:11,lineHeight:1.4,border:"2px solid "+(selCTA?.id===c.id?"var(--green)":"var(--border)"),background:selCTA?.id===c.id?"var(--gl)":"var(--surf2)" }}>
                      <span style={{ fontWeight:700,color:"var(--green)",marginRight:6 }}>{c.id}</span>{c.content}
                    </div>
                  ))}
                </div>
              </div>
              {previewContent && (
                <>
                  <div style={{ fontSize:11,fontWeight:700,color:"var(--muted)",textTransform:"uppercase",marginBottom:6 }}>
                    Preview — {selHook.id}×{selCorpo.id}×{selCTA.id}
                  </div>
                  <div style={{ background:"var(--surf2)",borderRadius:10,padding:12,fontSize:12,lineHeight:1.7,whiteSpace:"pre-wrap",marginBottom:10 }}>{previewContent}</div>
                  <button onClick={saveVariation} style={{ width:"100%",padding:"11px",borderRadius:10,border:"none",background:"var(--green)",color:"white",fontWeight:700,fontSize:13,cursor:"pointer" }}>
                    ✅ Salvar esta combinação em Conteúdo
                  </button>
                </>
              )}
            </div>
          </>
        )}

        {!variations && !generating && (
          <div style={{ background:"var(--surf2)",borderRadius:12,padding:14,fontSize:12,color:"var(--muted)",lineHeight:1.7,textAlign:"center" }}>
            <div style={{ fontSize:32,marginBottom:8 }}>🔁</div>
            Escolha um tema e clique em Gerar.<br/>
            O cérebro vai criar 30 blocos únicos que geram <strong style={{ color:"var(--text2)" }}>1000 variações</strong> de conteúdo sobre psicologia.
          </div>
        )}
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: SÉRIES EPISÓDICAS 🎬
// ═══════════════════════════════════════════════════════════════════
function PageSeries({ dayNumber }) {
  const [selSerie, setSelSerie] = useState(SERIES_LIBRARY[0].id);
  const serie = SERIES_LIBRARY.find(s => s.id === selSerie);
  const COLORS = { active:"var(--green)", planned:"var(--blue)", completed:"var(--amber)" };

  return (
    <>
      <div className="ph"><div><div className="pt">🎬 Séries Episódicas</div><div className="ps">Modelo Emma McAdam — 8x watch time por série</div></div></div>
      <div className="body">
        <div style={{ background:"rgba(5,150,105,0.08)",border:"1px solid var(--gb)",borderRadius:14,padding:14,marginBottom:14 }}>
          <div style={{ fontWeight:700,fontSize:13,color:"var(--green)",marginBottom:4 }}>💡 Por que séries funcionam melhor</div>
          <div style={{ fontSize:12,color:"var(--text2)",lineHeight:1.6 }}>
            Emma McAdam saiu de 50K→800K inscritos com a série de ansiedade.<br/>
            O algoritmo recomenda o próximo episódio automaticamente.<br/>
            Uma pessoa que assiste 1 episódio assiste <strong>todos os 8</strong>.<br/>
            Watch time 8× maior = algoritmo empurra muito mais = crescimento exponencial.
          </div>
        </div>

        <div className="tab-bar">
          {SERIES_LIBRARY.map(s => (
            <div key={s.id} className={"tab"+(selSerie===s.id?" on":"")} onClick={() => setSelSerie(s.id)} style={{ display:"flex",alignItems:"center",gap:6 }}>
              <span style={{ width:8,height:8,borderRadius:"50%",background:COLORS[s.status]||"var(--muted)",flexShrink:0 }}/>
              {s.nome.split(" ").slice(0,2).join(" ")}
            </div>
          ))}
        </div>

        {serie && (
          <>
            <div style={{ background:COLORS[serie.status]+"14",border:"1px solid "+COLORS[serie.status]+"44",borderRadius:14,padding:12,marginBottom:14 }}>
              <div style={{ fontWeight:700,fontSize:14,marginBottom:4 }}>{serie.nome}</div>
              <div style={{ display:"flex",gap:10 }}>
                <span style={{ fontSize:11,fontWeight:700,background:COLORS[serie.status]+"22",color:COLORS[serie.status],borderRadius:6,padding:"2px 8px" }}>{serie.status.toUpperCase()}</span>
                <span style={{ fontSize:11,color:"var(--muted)" }}>{serie.eps} episódios</span>
              </div>
            </div>
            {serie.episodios.map((ep, i) => (
              <div key={i} className="card mb12">
                <div style={{ display:"flex",gap:10,alignItems:"flex-start" }}>
                  <div style={{ width:28,height:28,borderRadius:"50%",background:serie.status==="active"?`linear-gradient(135deg,var(--purple),#a855f7)`:"var(--surf2)",color:serie.status==="active"?"white":"var(--muted)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,flexShrink:0 }}>{i+1}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontWeight:600,fontSize:13,lineHeight:1.35,marginBottom:4 }}>{ep}</div>
                    <div style={{ display:"flex",gap:5 }}>
                      {i===0&&<span style={{ fontSize:10,background:"var(--rl)",color:"var(--red)",borderRadius:4,padding:"1px 6px",fontWeight:700 }}>GANCHO INICIAL</span>}
                      {i===serie.eps-1&&<span style={{ fontSize:10,background:"var(--gl)",color:"var(--green)",borderRadius:4,padding:"1px 6px",fontWeight:700 }}>CONCLUSÃO + CTA CONSULTA</span>}
                      {i>0&&i<serie.eps-1&&<span style={{ fontSize:10,background:"var(--surf2)",color:"var(--muted)",borderRadius:4,padding:"1px 6px" }}>GANCHO → próximo ep</span>}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </>
        )}
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: MIGRAÇÃO 2027 🎓
// ═══════════════════════════════════════════════════════════════════
function PageMigracao({ dayNumber, migrationActivated, canMigrate, onMigrateClick }) {
  const phaseIdx = migrationActivated ? 3 : dayNumber<=60?0:dayNumber<=180?1:dayNumber<=450?2:3;
  const currentPhase = MIGRATION_2027.phases[phaseIdx];
  const daysToMigrate = Math.max(0, 270 - dayNumber);

  // Data estimada para o botão de migração (~jan 2027)
  const migrateDateEst = new Date(JORNADA_INICIO);
  migrateDateEst.setDate(migrateDateEst.getDate() + 269);
  const migrateDateStr = migrateDateEst.toLocaleDateString("pt-BR", { day:"2-digit", month:"long", year:"numeric" });

  // Bios para copiar quando a migração for ativada
  const BIOS_MIGRACAO = [
    { plataforma:"YouTube", emoji:"▶️", bio:"Dra. Daniela Coelho — Psicóloga 🧠 | Psicoeducação que transforma | Consultas online: link abaixo | CRP [NÚMERO]" },
    { plataforma:"Instagram", emoji:"📸", bio:"@danipsi | Dra. Daniela Coelho — Psicóloga CRP 🧠\nConsultas online 🔗 link na bio\nPsicologia que você entende 💜" },
    { plataforma:"TikTok", emoji:"🎵", bio:"Dra. Daniela Coelho • Psicóloga CRP 🧠 • Saúde mental de verdade • Consultas: link na bio" },
    { plataforma:"Pinterest", emoji:"📌", bio:"Dra. Daniela Coelho — Psicóloga | Conteúdo de psicologia baseado em evidências | @danipsi" },
  ];

  const [copiedBio, setCopiedBio] = useState(null);
  function copyBio(p, bio) {
    navigator.clipboard?.writeText(bio);
    setCopiedBio(p);
    setTimeout(() => setCopiedBio(null), 2000);
  }

  return (
    <>
      <div className="ph"><div><div className="pt">🎓 Migração 2027</div><div className="ps">Evolução gradual: estudante → Dra. Daniela Coelho</div></div></div>
      <div className="body">

        {/* Status atual */}
        <div style={{ background:migrationActivated?"linear-gradient(135deg,rgba(5,150,105,0.12),rgba(5,150,105,0.04))":"linear-gradient(135deg,rgba(124,58,237,0.1),rgba(168,85,247,0.04))",border:"1px solid "+(migrationActivated?"var(--gb)":"rgba(124,58,237,0.25)"),borderRadius:16,padding:16,marginBottom:14 }}>
          <div style={{ fontSize:10,fontWeight:700,color:migrationActivated?"var(--green)":"var(--purple)",textTransform:"uppercase",marginBottom:6 }}>
            {migrationActivated ? "✅ Migração Ativada" : "📍 Fase Atual — Dia " + dayNumber + " · " + new Date().toLocaleDateString("pt-BR")}
          </div>
          <div style={{ fontWeight:700,fontSize:14,marginBottom:8 }}>{currentPhase.period}</div>
          <div style={{ display:"flex",flexDirection:"column",gap:6 }}>
            {[["BIO ATUAL",currentPhase.bio],["TOM",currentPhase.tone],["CTA",currentPhase.cta],["GANCHO",currentPhase.hook]].map(([label,val]) => (
              <div key={label} style={{ background:"rgba(0,0,0,0.15)",borderRadius:8,padding:"8px 10px" }}>
                <div style={{ fontSize:9,fontWeight:700,color:migrationActivated?"var(--green)":"var(--purple)",textTransform:"uppercase",marginBottom:2 }}>{label}</div>
                <div style={{ fontSize:12,color:"var(--text2)",lineHeight:1.4 }}>{val}</div>
              </div>
            ))}
          </div>
        </div>

        {/* BOTÃO DE MIGRAÇÃO */}
        {!migrationActivated ? (
          <div style={{ marginBottom:14,borderRadius:16,overflow:"hidden",border:"2px solid "+(canMigrate?"rgba(124,58,237,0.5)":"var(--border)") }}>
            <div style={{ padding:"16px",background:canMigrate?"linear-gradient(135deg,rgba(124,58,237,0.12),rgba(168,85,247,0.06))":"var(--surf2)" }}>
              <div style={{ display:"flex",gap:12,alignItems:"flex-start",marginBottom:12 }}>
                <div style={{ fontSize:36,flexShrink:0 }}>🎓</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontWeight:700,fontSize:14,color:canMigrate?"var(--purple)":"var(--muted)",marginBottom:4 }}>
                    {canMigrate ? "✅ Botão de Migração Disponível!" : "🔒 Botão de Migração — Disponível em " + migrateDateStr}
                  </div>
                  <div style={{ fontSize:12,color:"var(--text2)",lineHeight:1.6 }}>
                    {canMigrate
                      ? "Apertar este botão ativa a fase 'Dra. Daniela Coelho' em todo o sistema. Todo conteúdo futuro passa a usar o novo tom de psicóloga formada."
                      : "Disponível no Dia 270 da jornada (" + migrateDateStr + "). Faltam " + daysToMigrate + " dias. Use este tempo para construir a audiência que vai receber a Dra. Daniela Coelho."}
                  </div>
                </div>
              </div>
              {!canMigrate && (
                <div>
                  <div style={{ display:"flex",justifyContent:"space-between",fontSize:10,color:"var(--muted)",marginBottom:4 }}>
                    <span>Progresso para ativação</span>
                    <span>{Math.min(100,Math.round(dayNumber/270*100))}%</span>
                  </div>
                  <div style={{ height:8,background:"var(--border)",borderRadius:4,overflow:"hidden" }}>
                    <div style={{ height:"100%",borderRadius:4,background:"linear-gradient(90deg,var(--purple),#a855f7)",width:Math.min(100,dayNumber/270*100)+"%",transition:"width 0.6s" }}/>
                  </div>
                </div>
              )}
              {canMigrate && (
                <button onClick={onMigrateClick} style={{ width:"100%",padding:"15px",borderRadius:12,border:"none",background:"linear-gradient(135deg,#7c3aed,#a855f7)",color:"white",fontWeight:800,fontSize:15,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:10,boxShadow:"0 4px 20px rgba(124,58,237,0.4)" }}>
                  🎓 Ativar: Dra. Daniela Coelho nos Canais
                </button>
              )}
            </div>
          </div>
        ) : (
          <>
            {/* Guia de atualização de bios — aparece após ativar */}
            <div style={{ marginBottom:14,padding:16,background:"rgba(5,150,105,0.08)",border:"2px solid var(--gb)",borderRadius:16 }}>
              <div style={{ fontWeight:700,fontSize:14,color:"var(--green)",marginBottom:10 }}>
                ✅ Migração Ativa — Atualize as Bios Manualmente
              </div>
              <div style={{ fontSize:12,color:"var(--text2)",marginBottom:12,lineHeight:1.6 }}>
                O cérebro já está gerando conteúdo com o novo tom. Agora atualize as bios em cada plataforma. Toque no botão para copiar:
              </div>
              {BIOS_MIGRACAO.map(b => (
                <div key={b.plataforma} style={{ background:"var(--surf)",border:"1px solid var(--border)",borderRadius:12,padding:"10px 12px",marginBottom:8 }}>
                  <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6 }}>
                    <div style={{ fontWeight:700,fontSize:12,color:"var(--text)" }}>{b.emoji} {b.plataforma}</div>
                    <button onClick={() => copyBio(b.plataforma, b.bio)} style={{ padding:"4px 10px",borderRadius:20,border:"1.5px solid var(--border)",background:copiedBio===b.plataforma?"var(--gl)":"var(--surf2)",color:copiedBio===b.plataforma?"var(--green)":"var(--muted)",fontSize:10,fontWeight:700,cursor:"pointer",flexShrink:0 }}>
                      {copiedBio===b.plataforma?"✅ Copiado":"📋 Copiar"}
                    </button>
                  </div>
                  <div style={{ fontSize:11,color:"var(--text2)",lineHeight:1.5,whiteSpace:"pre-line",background:"var(--surf2)",borderRadius:8,padding:"6px 8px" }}>{b.bio}</div>
                </div>
              ))}
              <div style={{ marginTop:10,fontSize:11,color:"var(--amber)",lineHeight:1.5 }}>
                ⚠️ Lembre de substituir [NÚMERO] pelo seu CRP real após a formatura.
              </div>
            </div>
          </>
        )}

        {/* Linha do tempo */}
        <div className="card mb12">
          <div style={{ fontWeight:700,fontSize:13,marginBottom:14 }}>📅 Linha do Tempo Real</div>
          {MIGRATION_2027.phases.map((phase, i) => (
            <div key={i} style={{ display:"flex",gap:12,marginBottom:16,opacity:i>phaseIdx?0.35:1 }}>
              <div style={{ display:"flex",flexDirection:"column",alignItems:"center",flexShrink:0 }}>
                <div style={{ width:32,height:32,borderRadius:"50%",background:i===phaseIdx?"linear-gradient(135deg,var(--purple),#a855f7)":i<phaseIdx?"var(--green)":"var(--surf2)",color:i<=phaseIdx?"white":"var(--muted)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,fontWeight:800 }}>
                  {i<phaseIdx?"✓":i===phaseIdx?"📍":i+1}
                </div>
                {i<3&&<div style={{ width:2,height:24,background:i<phaseIdx?"var(--green)":"var(--border)",marginTop:4 }}/>}
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontWeight:700,fontSize:12,color:i===phaseIdx?"var(--purple)":i<phaseIdx?"var(--green)":"var(--text2)",marginBottom:3 }}>{phase.period}</div>
                <div style={{ fontSize:11,color:"var(--muted)",marginBottom:3 }}>{phase.bio}</div>
                <div style={{ fontSize:11,color:"var(--text2)",fontStyle:"italic" }}>"{phase.hook}"</div>
              </div>
            </div>
          ))}
        </div>

        {/* Conteúdos de transição */}
        <div className="card mb12">
          <div style={{ fontWeight:700,fontSize:13,marginBottom:10 }}>✨ Conteúdos-Chave da Jornada</div>
          <div style={{ fontSize:12,color:"var(--text2)",marginBottom:10,lineHeight:1.6 }}>
            A audiência acompanha a jornada da Daniela. Quando ela se formar em 2027, já serão centenas de milhares que confiam nela — prontos para contratar consultas.
          </div>
          {MIGRATION_2027.transitionContent.map((c, i) => (
            <div key={i} style={{ display:"flex",gap:8,padding:"8px 0",borderBottom:"1px solid var(--border)" }}>
              <span style={{ fontWeight:700,color:"var(--purple)",fontSize:13,flexShrink:0 }}>{i+1}.</span>
              <span style={{ fontSize:12,lineHeight:1.5 }}>{c}</span>
            </div>
          ))}
        </div>

        {/* Projeção formatura */}
        <div style={{ background:"rgba(5,150,105,0.08)",border:"1px solid var(--gb)",borderRadius:14,padding:14 }}>
          <div style={{ fontWeight:700,fontSize:13,color:"var(--green)",marginBottom:8 }}>🎯 O que esperar na formatura (dez 2027)</div>
          {[
            "500K–2M inscritos que acompanharam toda a jornada",
            "Comunidade WhatsApp com 5K–20K membros fiéis",
            "Transição natural: 'minha estudante favorita' → 'minha psicóloga'",
            "Agenda de consultas preenchida nos primeiros dias após CRP",
            "Cursos e programas premium com audiência compradora consolidada",
            "RPM YouTube: R$15–25/mil views (autoridade de psicóloga formada)",
          ].map((r, i) => (
            <div key={i} style={{ display:"flex",gap:8,marginBottom:6 }}>
              <span style={{ color:"var(--green)",flexShrink:0 }}>✅</span>
              <span style={{ fontSize:12,lineHeight:1.5 }}>{r}</span>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: SKILLS LIBRARY 🛠️
// ═══════════════════════════════════════════════════════════════════
function PageSkills({ skills, setSkills }) {
  function toggleSolid(id) {
    setSkills(prev => prev.map(s => s.id === id ? { ...s, solid: !s.solid } : s));
  }
  function incrementUso(id) {
    setSkills(prev => prev.map(s => s.id === id ? { ...s, uso: s.uso + 1 } : s));
  }

  return (
    <>
      <div className="ph"><div><div className="pt">🛠️ Skills Library</div><div className="ps">Fluxos otimizados persistentes — modelo marketplace G4S</div></div></div>
      <div className="body">
        <div style={{ background:"rgba(124,58,237,0.06)",border:"1px solid rgba(124,58,237,0.2)",borderRadius:14,padding:14,marginBottom:14 }}>
          <div style={{ fontWeight:700,fontSize:13,color:"var(--purple)",marginBottom:6 }}>💡 O que é o Marketplace de Skills</div>
          <div style={{ fontSize:12,color:"var(--text2)",lineHeight:1.6 }}>
            Inspirado no G4S: você cria uma skill uma vez, o cérebro salva, reutiliza e melhora.<br/>
            Cada skill passa por <strong>revisão em loop</strong> até estar "sólida" — o mesmo processo que levou 7 rodadas para ficar perfeita no case real.<br/>
            Versão controlada: quando atualiza, todos os processos usam a nova versão automaticamente.
          </div>
        </div>

        {skills.map(skill => (
          <div key={skill.id} className="card mb12">
            <div style={{ display:"flex",gap:10,alignItems:"flex-start" }}>
              <div style={{ width:44,height:44,borderRadius:10,flexShrink:0,background:skill.solid?"var(--gl)":"var(--al)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20 }}>
                {skill.solid?"✅":"🔧"}
              </div>
              <div style={{ flex:1,minWidth:0 }}>
                <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:4 }}>
                  <div style={{ fontWeight:700,fontSize:13 }}>{skill.nome}</div>
                  <span style={{ fontSize:10,fontWeight:700,background:"var(--surf2)",borderRadius:6,padding:"2px 7px",flexShrink:0,color:"var(--muted)" }}>v{skill.versao}</span>
                </div>
                <div style={{ fontSize:11,color:"var(--text2)",lineHeight:1.5,marginBottom:8 }}>{skill.descricao}</div>
                <div style={{ display:"flex",flexWrap:"wrap",gap:6 }}>
                  <span style={{ fontSize:10,background:"var(--surf2)",borderRadius:6,padding:"2px 7px",color:"var(--muted)" }}>🔄 {skill.revisoes} revisões</span>
                  <span style={{ fontSize:10,background:"var(--surf2)",borderRadius:6,padding:"2px 7px",color:"var(--muted)" }}>▶️ {skill.uso}× usada</span>
                  <span style={{ fontSize:10,fontWeight:700,background:skill.solid?"var(--gl)":"var(--al)",borderRadius:6,padding:"2px 7px",color:skill.solid?"var(--green)":"var(--amber)" }}>
                    {skill.solid?"● Sólida":"○ Em teste"}
                  </span>
                </div>
                <div style={{ display:"flex",gap:6,marginTop:8 }}>
                  <button onClick={() => incrementUso(skill.id)} style={{ padding:"5px 12px",borderRadius:20,border:"1.5px solid var(--purple)",background:"var(--pl)",color:"var(--purple)",fontSize:11,fontWeight:700,cursor:"pointer" }}>▶ Usar skill</button>
                  <button onClick={() => toggleSolid(skill.id)} style={{ padding:"5px 12px",borderRadius:20,border:"1.5px solid var(--border)",background:"var(--surf2)",color:"var(--muted)",fontSize:11,fontWeight:600,cursor:"pointer" }}>
                    {skill.solid ? "↩ Marcar em teste" : "✅ Marcar sólida"}
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}

        <div style={{ padding:14,background:"var(--surf2)",borderRadius:12,fontSize:12,color:"var(--muted)",lineHeight:1.6 }}>
          <strong style={{ color:"var(--text2)" }}>🚀 Como criar novas skills:</strong><br/>
          Use o Gerador Manual para criar um fluxo → refine → salve como skill. O cérebro automatiza o fluxo nas próximas execuções. Versões são controladas e atualizações são propagadas para todos os processos.
        </div>
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════
// PAGE: LOGS
// ═══════════════════════════════════════════════════════════════════
function PageLogs({ logs, logRef }) {
  const [filter, setFilter] = useState("all");
  const filtered = filter==="all"?logs:logs.filter(l=>l.type===filter);
  return (
    <>
      <div className="ph"><div><div className="pt">📋 Logs do Cérebro</div><div className="ps">{logs.length} eventos · AO VIVO</div></div></div>
      <div className="body">
        <div className="tab-bar">
          {["all","system","success","info","warn","error"].map(f=>(<div key={f} className={"tab"+(filter===f?" on":"")} onClick={()=>setFilter(f)}>{f}</div>))}
        </div>
        <div style={{ background:"#0a0a0f",borderRadius:12,overflow:"hidden",border:"1px solid #1a1a25" }}>
          <div style={{ padding:"8px 14px",borderBottom:"1px solid #1a1a25",display:"flex",justifyContent:"space-between" }}>
            <span style={{ fontSize:11,fontWeight:700,color:"#555",fontFamily:"monospace" }}>{filtered.length} ENTRADAS</span>
            <span style={{ fontSize:11,color:"#22c55e",display:"flex",alignItems:"center",gap:4 }}>
              <span style={{ width:6,height:6,borderRadius:"50%",background:"#22c55e",display:"inline-block",animation:"blink 1s infinite" }}/>AO VIVO
            </span>
          </div>
          <div ref={logRef} style={{ maxHeight:"72vh",overflowY:"auto",padding:10 }}>
            {filtered.map(l=>(
              <div key={l.id} style={{ display:"flex",gap:8,padding:"3px 4px",fontSize:11,fontFamily:"monospace",lineHeight:1.5 }}>
                <span style={{ color:"#444",flexShrink:0,minWidth:64 }}>{l.time}</span>
                <span style={{ color:l.type==="success"?"#22c55e":l.type==="error"?"#ef4444":l.type==="warn"?"#f59e0b":l.type==="system"?"#a78bfa":"#6b7280",flexShrink:0,minWidth:64 }}>[{l.type}]</span>
                <span style={{ color:"#d1d5db",flex:1 }}>{l.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#0a0a0f;--surf:#13131a;--surf2:#1c1c26;--border:#252535;
  --purple:#7c3aed;--pl:rgba(124,58,237,0.09);--pb:rgba(124,58,237,0.22);
  --green:#059669;--gl:rgba(5,150,105,0.09);--gb:rgba(5,150,105,0.22);
  --red:#dc2626;--rl:rgba(220,38,38,0.09);--rb:rgba(220,38,38,0.22);
  --amber:#d97706;--al:rgba(217,119,6,0.09);--ab:rgba(217,119,6,0.22);
  --blue:#2563eb;--bl:rgba(37,99,235,0.09);
  --text:#f0f0f8;--text2:#b0b0c8;--muted:#55556a;
  --font:'Plus Jakarta Sans',-apple-system,sans-serif;
}
html{height:100%;-webkit-text-size-adjust:100%}
body{background:var(--bg);color:var(--text);font-family:var(--font);font-size:15px;height:100%;overflow:hidden;-webkit-font-smoothing:antialiased;touch-action:manipulation}
.app{display:flex;height:100dvh;overflow:hidden;position:relative}
.overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:40;backdrop-filter:blur(4px)}
.overlay.show{display:block}
.sidebar{width:280px;flex-shrink:0;background:var(--surf);border-right:1px solid var(--border);display:flex;flex-direction:column;overflow-y:auto;position:fixed;left:0;top:0;bottom:0;z-index:50;transform:translateX(-100%);transition:transform 0.25s cubic-bezier(.4,0,.2,1)}
.sidebar.open{transform:translateX(0);box-shadow:8px 0 32px rgba(0,0,0,0.5)}
.topbar{position:fixed;top:0;left:0;right:0;height:calc(52px + env(safe-area-inset-top,0px));padding-top:env(safe-area-inset-top,0px);background:rgba(19,19,26,0.95);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border-bottom:1px solid var(--border);display:flex;align-items:center;padding-left:12px;padding-right:12px;gap:8px;z-index:30}
.hbtn{width:40px;height:40px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;background:transparent;border:none;cursor:pointer;padding:0;flex-shrink:0}
.hbtn span{display:block;width:20px;height:2px;background:var(--text);border-radius:1px;transition:all 0.25s}
.hbtn.open span:nth-child(1){transform:translateY(7px) rotate(45deg)}.hbtn.open span:nth-child(2){opacity:0}.hbtn.open span:nth-child(3){transform:translateY(-7px) rotate(-45deg)}
.main{flex:1;overflow-y:auto;padding-top:calc(52px + env(safe-area-inset-top,0px));padding-bottom:calc(24px + env(safe-area-inset-bottom,0px));-webkit-overflow-scrolling:touch}
.body{padding:12px;max-width:520px;margin:0 auto}
.ph{padding:14px 12px 10px;display:flex;align-items:flex-start;justify-content:space-between;gap:10px}
.pt{font-size:20px;font-weight:800;letter-spacing:-0.02em}.ps{font-size:12px;color:var(--muted);margin-top:2px}
.card{background:var(--surf);border:1px solid var(--border);border-radius:14px;padding:14px;box-shadow:0 2px 8px rgba(0,0,0,0.2)}
.mb12{margin-bottom:12px}
.ni{display:flex;align-items:center;gap:10px;padding:10px 14px;cursor:pointer;font-size:13px;font-weight:600;color:var(--muted);transition:all 0.12s;-webkit-tap-highlight-color:transparent;position:relative;min-height:44px}
.ni:active{background:var(--surf2)}.ni.on{color:var(--purple);background:rgba(124,58,237,0.08)}
.nb{background:var(--red);color:white;border-radius:10px;padding:1px 5px;font-size:9px;font-weight:800;position:absolute;right:10px}
.nb-btn{position:relative;width:36px;height:36px;border-radius:50%;border:none;background:var(--surf2);cursor:pointer;font-size:16px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.status-badge{font-size:11px;font-weight:700;padding:5px 10px;border-radius:20px;background:var(--gl);color:var(--green);white-space:nowrap;flex-shrink:0}
.status-badge.active{background:var(--pl);color:var(--purple)}
.tab-bar{display:flex;border-bottom:1px solid var(--border);margin-bottom:14px;overflow-x:auto;-webkit-overflow-scrolling:touch;scrollbar-width:none}
.tab-bar::-webkit-scrollbar{display:none}
.tab{padding:9px 14px;font-size:13px;font-weight:600;color:var(--muted);cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-1px;white-space:nowrap;min-height:40px;display:flex;align-items:center;gap:5px;-webkit-tap-highlight-color:transparent}
.tab.on{color:var(--purple);border-bottom-color:var(--purple)}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes blink{0%,100%{opacity:1}50%{opacity:0}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}
@media(min-width:768px){.sidebar{position:relative;transform:none!important;box-shadow:none}.overlay{display:none!important}.topbar{left:280px}}
::-webkit-scrollbar{width:3px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:var(--border);border-radius:2px}
`;
