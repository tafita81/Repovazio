import { supabase } from "@/lib/supabaseServer";

export async function GET() {
  const { data, error } = await supabase.from("registros").select("*");
  if (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
  return Response.json(data || []);
}